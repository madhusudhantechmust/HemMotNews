//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MemoryUtils.h $
//  
//  Owner: pmessmer
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Memory utilities
//  
//========================================================================================

#pragma once
#ifndef __MEMORYUTILS__
#define __MEMORYUTILS__


namespace K2Memory
{

/**	Allocates a block of memory compatible with the runtime's operator new, except that
	the block is tracked for the purposes of finding leaks and the call may trigger
	a purge operation.  You normally never need to call this directly; it is called 
	by our operator new overload, which simply delegates to this function.
	@param size is the number of bytes to allocate
	@return the address of the new memory block.
*/
RUNTIME_DECL void *RTLCompatibleNewDelegate (size_t size);

/**	Allocates a block of memory compatible with the runtime's operator new[], except that
	the block is tracked for the purposes of finding leaks and the call may trigger
	a purge operation.  You normally never need to call this directly; it is called 
	by our operator new[] overload, which simply delegates to this function.
	@param size is the number of bytes to allocate
	@return the address of the new memory block.
*/
RUNTIME_DECL void *RTLCompatibleNewArrayDelegate (size_t size);

/** Deletes a block of memory allocated by operator new, or RTLCompatibleNewDelegate.
	You normally never need to call this directly, it is called by our operator delete
	overload, which simply delegates to this function.
	@param p is the block to delete.
*/
RUNTIME_DECL void RTLCompatibleDeleteDelegate (void *p);

/** Deletes a block of memory allocated by operator new[], or RTLCompatibleNewArrayDelegate.
	You normally never need to call this directly, it is called by our operator delete[]
	overload, which simply delegates to this function.
	@param p is the block to delete.
*/
RUNTIME_DECL void RTLCompatibleDeleteArrayDelegate (void *p);

/** Tells the memory tracking system to stop tracking an allocation that was performed
	by RTLCompatibleNewDelegate, RTLCompatibleNewArrayDelegate, or RTLCompatibleMalloc.
	This function is useful if the block in question must be passed to some outside code
	and will be deleted by the runtime library, trigger a spurrious memory leak assert.
	If you call this function to supress a leak, make SURE there really is no leak.
	@param p is the block to not report a leak about.
*/
RUNTIME_DECL void StopTrackingRTLCompatibleAllocation (void *p);

/** Interchangable and compatible with C's malloc(), except that the block is tracked for the purposes 
	of finding leaks and the call may trigger a purge operation.  You should call this
	in preference to malloc() so that we can find memory errors.
	@param size is the number of bytes to allocate
	@return the address of the new memory block.
*/
RUNTIME_DECL void *RTLCompatibleMalloc (size_t size);

/** Interchangable and compatible with C's free(), except that the block is removed from
	tracking by our memory debugging system.  You should call this in preference to free()
	so that we can find memory errors.
	@param p is the block to delete.
*/
RUNTIME_DECL void RTLCompatibleFree (void *p);

/** Interchangable and compatible with C's realloc(), except that the block is tracked for the purposes 
	of finding leaks and the call may trigger a purge operation.  You should call this
	in preference to realloc() so that we can find memory errors.
	@param p is the block to reallocate, or 0 to allocate a new block.
	@param size is the number of bytes to reallocate the block to, or 0 to delete the block p.
	@return the address of the new memory block.
*/
RUNTIME_DECL void *RTLCompatibleRealloc (void *p, size_t size);

/** Compatible with C's mallocsize() (see also _msize on Windows).  It will give you
	information about the size of a block allocated through RTLCompatibleMalloc, RTLCompatibleRealloc,
	malloc, realloc, or calloc.  Note that the return value is NOT necessarily the exact allocation
	size you originally requested, but rather is an upper bound on the size of the block.
	@param p is the block to discover the size of.
	@return an upper bound on the size of the memory block p.
*/
RUNTIME_DECL size_t RTLCompatibleMallocSize (void *p);

};


#endif  // __MEMORYUTILS__
