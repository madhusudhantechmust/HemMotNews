//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/RealTimeMark.h $
//  
//  Owner: Steve Flenniken
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __REALTIMEMARK__
#define __REALTIMEMARK__

#include "stdio.h"

#ifndef REALTIMEMARKS
#define REALTIMEMARKS BENCHMARK_ONLY
#endif

class RUNTIME_DECL RealTimeMark
{
public:
	static void Initialize();
	static void DisplayTime(const char *string);
	static void Shutdown();

private:
#if WINDOWS
	static double gRtmFrequency;
	static uint64 gRtmStartTime;
	static uint64 gRtmLastTime;
	static FILE *gRtmFile;
#elif MACINTOSH
	static UnsignedWide gRtmStartTime;
	static UnsignedWide gRtmLastTime;
//		static AbsoluteTime gRtmStartTime;
//		static AbsoluteTime gRtmLastTime;
	static short gRtmFile; // vRefNum

	static double MicrosecondDifferenceToSeconds(UnsignedWide newTime, UnsignedWide oldTime);
//		static double AbsoluteDifferenceToSeconds(AbsoluteTime newTime, AbsoluteTime oldTime);
#endif
};
#define RealTimeMarkInitialize() RealTimeMark::Initialize()

// Add this line to your code, when it executes the current
// time is written to the file RealTimeMark.csv which is
// in same folder as the exe.
#define RealTimeMark(string) RealTimeMark::DisplayTime(string)

#define RealTimeMarkShutdown() RealTimeMark::Shutdown()

#endif
