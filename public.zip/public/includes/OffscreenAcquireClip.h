//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/OffscreenAcquireClip.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __OffscreenAcquireClip__
#define __OffscreenAcquireClip__

#ifdef WIDGET_BUILD
#pragma export on
#endif

class IViewPort;
class IControlView;

/**
 An object that sets up the clip for a view or viewport.
 
 This implementation is effectively empty. The various methods are either
 empty (no-ops) or return default values. The intended use of the class is
 unclear and the class itself may be obsolete (it is unused in the current
 codebase).
 
 @see AGMAcquireClip
 */
class WIDGET_DECL OffscreenAcquireClip
{
	public:
		/**
		 Constructs a clipping acquisition object based on a viewport, a control 
		 view, and an optional sys region. None are owned (AddRef'd).
		 
		 @param viewPort	The viewport to base the clipping on
		 @param view		The control view to base the clipping on
		 @param clipRgn		The clipping region to use
		 */
		OffscreenAcquireClip(IViewPort* viewPort, IControlView* view, SysRgn clipRgn = nil);
		/**
		 Constructs a clipping acquisition object based on a viewport and a 
		 control view. Neither is owned (AddRef'd).
		 
		 @param viewPort	The viewport to base the clipping on
		 @param view		The control view to base the clipping on
		 */
		OffscreenAcquireClip(IViewPort* viewPort, SysRgn clipRgn);
		
		/**
		 Destructor
		 */
		~OffscreenAcquireClip();
		
		/**
		 Gets the clipping region for this context

		 @return The clip region. Always nil for this implementation.
		*/
		SysRgn			GetClip() const;

		/**
		 Gets the clipping region for this context, adjusted for the origin

		 @return The origin-adjusted clip region. Always nil for this implementation.
		*/
		SysRgn			GetOriginAdjustedClip() const;
		
		/**
		 Gets the system port for this graphics context

		 @return The system port. Always nil for this implementation.
		*/
		SysPort			GetSysPort() const;
		
		/**
		 Sets up the platform clipping. Does nothing in this implementation.
		 */
		void			SetupPlatformClip();
		
		/**
		 Tears down the platform clipping. Does nothing in this implementation.
		 */
		void			TearDownPlatformClip();

	private:
		IViewPort*		fVP;
};

#pragma export off

#endif
