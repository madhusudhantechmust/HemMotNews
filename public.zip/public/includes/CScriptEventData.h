//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/CScriptEventData.h $
//  
//  Owner: Jonathan W. Brown
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __CScriptEventData__
#define __CScriptEventData__

#include "IScriptEventData.h"

class IScript ;

using namespace ScriptInfo ;

typedef KeyValuePair< ScriptList, ScriptReturnDataList > ScriptTargetReturnDataPair ;
typedef K2Vector<ScriptTargetReturnDataPair> ScriptTargetReturnDataList ;

#pragma export on

class PUBLIC_DECL CScriptEventData : public CPMUnknown<IScriptEventData>
{
public:
	CScriptEventData(IPMUnknown *boss);
	virtual ~CScriptEventData();

	virtual ErrorCode InsertEventData( const ScriptID dataLocation, const ScriptData& data ) ;
	virtual ErrorCode InsertEventData( const ScriptRecordData& record ) ;
	virtual ErrorCode ExtractEventData( const ScriptID dataLocation, ScriptData& data ) const ;
	virtual bool16 HasEventData( const ScriptID dataLocation ) const ;
	virtual ScriptRecordData GetEventData() const ;

	virtual void ClearReturnData( const IScript* target ) ;
	virtual void ClearReturnData( const ScriptList& targets ) ;
	virtual void AppendReturnData( const IScript* target, const ScriptID requestID, const ErrorCode errorCode ) ;
	virtual void AppendReturnData( const ScriptList& targets, const ScriptID requestID, const ErrorCode errorCode ) ;
	virtual void AppendReturnData( const IScript* target, const ScriptID requestID, const ScriptData& returnValue ) ;
	virtual void AppendReturnData( const ScriptList& targets, const ScriptID requestID, const ScriptData& returnValue ) ;
	virtual void AppendReturnData( const IScript* target, const ScriptReturnData& data ) ;
	virtual void AppendReturnData( const ScriptList& targets, const ScriptReturnData& data ) ;
	virtual void ReplaceReturnData( const IScript* target, const ScriptReturnDataList& data ) ;
	virtual void ReplaceReturnData( const ScriptList& targets, const ScriptReturnDataList& data ) ;
	virtual void AppendReturnData( const IScript* target, const ScriptReturnDataList& data ) ;
	virtual void AppendReturnData( const ScriptList& targets, const ScriptReturnDataList& data ) ;
	virtual uint32 GetNumReturnData( const IScript* target ) const ;		
	virtual uint32 GetNumReturnData( const ScriptList& targets ) const ;		
	virtual ScriptReturnData GetNthReturnData( const IScript* target, uint32 n ) const ;		
	virtual ScriptReturnData GetNthReturnData( const ScriptList& targets, uint32 n ) const ;		
	virtual ScriptReturnDataList GetAllReturnData( const IScript* target ) const ;		
	virtual ScriptReturnDataList GetAllReturnData( const ScriptList& targets ) const ;		

	virtual void SetErrorPolicy( ErrorPolicy policy ) ;
	virtual ErrorPolicy GetErrorPolicy() const ;

	virtual void SetSetPropertiesOrderPolicy( SetPropertiesOrderPolicy policy ) ;
	virtual SetPropertiesOrderPolicy GetSetPropertiesOrderPolicy() const ;

	virtual void SetTargetInfo( const ScriptElementID objectID ) ;
	virtual void SetTargetInfo( const ObjectScriptElement* pObject ) ;
	virtual const ObjectScriptElement* GetTargetInfo() const ;

	virtual const ScriptID GetDesiredType() const ;

	virtual RequestType GetRequestType() const ;
	virtual const ScriptElement* GetRequestInfo() const ;

	virtual void SetEvent( const ScriptElementID eventID ) ;
	virtual void SetEvent( const EventScriptElement* pEvent ) ;
	virtual bool16 IsEvent() const ;
	virtual void SetEventWithProperties( bool16 withProperties ) ;
	virtual bool16 IsEventWithProperties() const ;

	virtual void SetPropertyGet( const ScriptElementID propID ) ;
	virtual void SetPropertyGet( const PropertyScriptElement* pProp ) ;
	virtual bool16 IsPropertyGet() const ;

	virtual void SetPropertyPut( const ScriptElementID propID ) ;
	virtual void SetPropertyPut( const PropertyScriptElement* pProp ) ;
	virtual bool16 IsPropertyPut() const ;

	virtual void SetFindCollection( const ScriptElementID objID ) ;
	virtual void SetFindCollection( const ObjectScriptElement* pObj ) ;
	virtual bool16 IsFindCollection() const ;

	virtual void SetGetObject( const ScriptElementID objID, SpecifierForm accessorForm, const ScriptData& accessorData ) ;
	virtual void SetGetObject( const ObjectScriptElement* pObj, SpecifierForm accessorForm, const ScriptData& accessorData ) ;
	virtual bool16 IsGetObject() const ;
	virtual SpecifierForm GetAccessorForm() const ;
	virtual ScriptData GetAccessorData() const ;

	virtual void SetTargetHandlingPolicy( TargetHandlingPolicy policy ) ;
	virtual TargetHandlingPolicy GetTargetHandlingPolicy() const ;

	virtual void SetRequestedDataType( const ScriptID requestedType ) ;
	virtual const ScriptID GetRequestedDataType() const ;

	virtual void SetFormTestCaseSensitive( bool16 caseSensitive ) ;
	virtual bool16 GetFormTestCaseSensitive() const ;

	// Access to the request context for this event
	virtual const EngineContext& GetRequestContext() const ;
	virtual void SetRequestContext( const EngineContext& context ) ;

	virtual void CloneEventData( IScriptEventData* other ) const ;
	virtual void Reset() ;
	virtual void Release() const ;

protected:
	/** Override in subclass if you need to translate client-specific event data before event data is accessed.
		Return const& internally for performance.
	*/
	virtual const ScriptRecordData& InternalGetEventData() const ;

private:
	ScriptRecordData			fEventData ;
	ScriptTargetReturnDataList	fReturnData ;
	ErrorPolicy					fErrorPolicy ;
	SetPropertiesOrderPolicy	fSetPropertiesOrderPolicy ;
	const ObjectScriptElement*	fTargetInfo ;
	const ScriptElement*		fRequestInfo ;
	RequestType					fRequestType ;
	bool16						fIsEventWithProperties ;
	SpecifierForm				fAccessorForm ;
	ScriptData					fAccessorData ;
	TargetHandlingPolicy		fHandlingPolicy ;
	ScriptID					fRequestedDataType ;
	bool16						fFormTestCaseSensitive ;
	EngineContext				fRequestContext ;
};

#pragma export off

#endif
