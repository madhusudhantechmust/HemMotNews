//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MQDGlobals.h $
//  
//  Owner: Lonnie Millett
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MQDGLOBALS__
#define __MQDGLOBALS__

#if 0
// This file is obsolete

//========================================================================================
// struct PM_QDGlobals
//========================================================================================
#pragma options align=mac68k
/* Structured access to the Mac QuickDraw globals -- OBSOLETE as far as I can tell.
		Use modern accessors that have replaced these constants.
*/
typedef struct
{
	char		privates[76];
	long		randSeed;
	BitMap		screenBits;
	Cursor		arrow;
	Pattern		dkGray;
	Pattern		ltGray;
	Pattern		gray;
	Pattern		black;
	Pattern		white;
	GrafPtr		thePort;
} PM_QDGlobalRec;


#pragma options align=reset
//========================================================================================
// class MSavePort
/** Utility class to save and restore the current QuickDraw port. 
		Constructor saves the port, destructor restores the saved port.
		@see MSetPort
*/
//========================================================================================
class MSavePort
{
public:
	/**  */
	MSavePort() :
		fSavedPort(nil)
	{
		::GetPort(&fSavedPort);
	}
	
	/**  */
	~MSavePort()
	{
		::SetPort(fSavedPort);
	}
	
private:
	GrafPtr		fSavedPort;
};


// ===================================================================================
//	class MSetPort
/** Utility class to save the current port, switch to a new port, and restore the original port.
		Constructor saves current port before switching to the new port, destructor restores the saved port. 
*/
// ===================================================================================
class MSetPort {

public:
	/**  */
						~MSetPort();
							
#if !TARGET_CARBON
						MSetPort(GrafPtr port, GDHandle device = GetMainDevice());
						// If the port is actually a GWorld, device is ignored.
#endif

	/**  */
						MSetPort(CGrafPtr port, GDHandle device = GetMainDevice());
						
#if TARGET_CARBON
	/**  */
						MSetPort(WindowRef window);
					
	/**  */
						MSetPort(DialogRef dialog);
#endif

private:
	CGrafPtr	mOldPort;		
	GDHandle	mOldDevice;
};


// ===================================================================================
//	Inlined Methods
// ===================================================================================

inline MSetPort::~MSetPort()
{
	SetGWorld(mOldPort, mOldDevice);		
}


#if !TARGET_CARBON
inline MSetPort::MSetPort(GrafPtr port, GDHandle device)
{
	ASSERT(port != nil);
	ASSERT(device != nil);
	
	GetGWorld(&mOldPort, &mOldDevice);
	SetGWorld((CGrafPtr) port, device);
}
#endif


inline MSetPort::MSetPort(CGrafPtr port, GDHandle device)
{
	ASSERT(port != nil);
	ASSERT(device != nil);
	
	GetGWorld(&mOldPort, &mOldDevice);
	SetGWorld(port, device);
}


#if TARGET_CARBON
inline MSetPort:: MSetPort(WindowRef window)
{
	ASSERT(window != nil);

	GetGWorld(&mOldPort, &mOldDevice);
	SetPortWindowPort(window);
}
#endif


#if TARGET_CARBON
inline MSetPort:: MSetPort(DialogRef dialog)
{
	ASSERT(dialog != nil);

	GetGWorld(&mOldPort, &mOldDevice);
	SetPortDialogPort(dialog);
}
#endif

#endif

#endif	// __MQDGLOBALS__
