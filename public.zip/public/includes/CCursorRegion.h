//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/CCursorRegion.h $
//  
//  Owner: Dave Burnard
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __CCursorRegion__
#define __CCursorRegion__

#include "ICursorRegion.h"
#include "HelperInterface.h"

#pragma export on

/** Basic implementation of the ICursorRegion interface used for simple widgets.
		Implementors of ICursorRegion should either derive from either this or PanelCursorRegion.

		@see ICursorRegion, PanelCursorRegion
 */
class WIDGET_DECL CCursorRegion : public ICursorRegion
{
	public:
		CCursorRegion(IPMUnknown *boss);
		virtual ~CCursorRegion();

		/** Default implementation to remember the provider passed in. */
		virtual void SetCursorProvider(ICursorProvider* p);
		
		/** Default implementation to assign the assiciated widget's bounds with the stored provider.
				There is a slight implementation difference between Mac and Win - due to the MDI windowing scheme
				we must clip to the appframe those regions from child windows of the app frame. 
				If we stop using MDI, this will no longer be necessary.
		*/
		virtual void GenerateCursorRgn(); 

	protected:
		ICursorProvider*	fCursorProvider;

	DECLARE_HELPER_METHODS()
};

#pragma export off

#endif
