//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/ApplDefs.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __ApplDefs__
#define __ApplDefs__

#include "IconRsrcDefs.h"



#define kAppInfoDialogRsrcID 					100  
#define kSavePaletteWorkspacePanelRsrcID 		150
#define kDeletePaletteWorkspacePanelRsrcID	 	200

#define kPlaceDialogRsrcID						400	// has matching entry in AppUI.rc
#define kUICustMenusDialogRsrcID 				500
#define kUICustMenuNodeRsrcID 					600
#define kUICustomizationHiddenEyeballIcon 			650
#define kApplErrorStringTableRsrcID				698
#define kPlatformErrorStringTableRsrcID			699	//must be identical to definition in ErrorTableTypes.h
#define kUICustomizationSaveAsDialogRsrcID		700

#define kInterfaceEquivalentsRsrcID				750


// ----- String resources
#define kApplStringsRsrcID					10000
#define kBootStrapStringsRsrcID				10100
#define kApplStringsNoTransRsrcID			10200
#define kApplStringsLocalizedRsrcID			10300
#define kBootStrapStringsNoTransRsrcID		10400
#define kBootStrapStringsLocalizedRsrcID		10500
#define kAppUIStringsRsrcID					10600
#define kAppUIStringsNoTransRsrcID			10700


#define kDocErrorStringTableRsrcID			10800
#define kDBErrorStringTableRsrcID			10900
#define kAppUIErrorStringTableRsrcID			11000

//========================================================================================
// ----- Action/Menu IDs -----
//========================================================================================

#define kApplActionResID							1400
#define kApplFileActionResID						1450
#define kApplMenusRsrcID							1500
#define kUserInterfacePrefsDialogCreatorRsrcID		1600
#define kUserInterfacePrefsDialogRsrcID				1700


// menu background resources
#define kUICustMenuBackground_UR_Yellow_S_RsrcID 1600
#define kUICustMenuBackground_UR_Yellow_N_RsrcID 1601
#define kUICustMenuBackground_UR_Violet_S_RsrcID 1602
#define kUICustMenuBackground_UR_Violet_N_RsrcID 1603
#define kUICustMenuBackground_UR_Red_S_RsrcID 1604
#define kUICustMenuBackground_UR_Red_N_RsrcID 1605
#define kUICustMenuBackground_UR_Orange_S_RsrcID 1606
#define kUICustMenuBackground_UR_Orange_N_RsrcID 1607
#define kUICustMenuBackground_UR_Green_S_RsrcID 1608
#define kUICustMenuBackground_UR_Green_N_RsrcID 1609
#define kUICustMenuBackground_UR_Gray_S_RsrcID 1610
#define kUICustMenuBackground_UR_Gray_N_RsrcID 1611
#define kUICustMenuBackground_UR_Blue_S_RsrcID 1612
#define kUICustMenuBackground_UR_Blue_N_RsrcID 1613
#define kUICustMenuBackground_UM_Yellow_S_RsrcID 1614
#define kUICustMenuBackground_UM_Yellow_N_RsrcID 1615
#define kUICustMenuBackground_UM_Violet_S_RsrcID 1616
#define kUICustMenuBackground_UM_Violet_N_RsrcID 1617
#define kUICustMenuBackground_UM_Red_S_RsrcID 1618
#define kUICustMenuBackground_UM_Red_N_RsrcID 1619
#define kUICustMenuBackground_UM_Orange_S_RsrcID 1620
#define kUICustMenuBackground_UM_Blue_S_RsrcID 1621
#define kUICustMenuBackground_UM_Blue_N_RsrcID 1622
#define kUICustMenuBackground_UL_Yellow_S_RsrcID 1623
#define kUICustMenuBackground_UL_Yellow_N_RsrcID 1624
#define kUICustMenuBackground_UL_Violet_S_RsrcID 1625
#define kUICustMenuBackground_UL_Violet_N_RsrcID 1626
#define kUICustMenuBackground_UL_Red_S_RsrcID 1627
#define kUICustMenuBackground_UL_Red_N_RsrcID 1628
#define kUICustMenuBackground_UL_Orange_S_RsrcID 1629
#define kUICustMenuBackground_UL_Orange_N_RsrcID 1630
#define kUICustMenuBackground_UL_Green_S_RsrcID 1631
#define kUICustMenuBackground_UL_Green_N_RsrcID 1632
#define kUICustMenuBackground_UL_Gray_S_RsrcID 1633
#define kUICustMenuBackground_UL_Gray_N_RsrcID 1634
#define kUICustMenuBackground_UL_Blue_S_RsrcID 1635
#define kUICustMenuBackground_UL_Blue_N_RsrcID 1636
#define kUICustMenuBackground_MR_Yellow_S_RsrcID 1637
#define kUICustMenuBackground_MR_Yellow_N_RsrcID 1638
#define kUICustMenuBackground_MR_Violet_S_RsrcID 1639
#define kUICustMenuBackground_MR_Violet_N_RsrcID 1640
#define kUICustMenuBackground_MR_Red_S_RsrcID 1641
#define kUICustMenuBackground_MR_Red_N_RsrcID 1642
#define kUICustMenuBackground_MR_Orange_S_RsrcID 1643
#define kUICustMenuBackground_MR_Orange_N_RsrcID 1644
#define kUICustMenuBackground_MR_Green_S_RsrcID 1645
#define kUICustMenuBackground_MR_Green_N_RsrcID 1646
#define kUICustMenuBackground_MR_Gray_S_RsrcID 1647
#define kUICustMenuBackground_MR_Gray_N_RsrcID 1648
#define kUICustMenuBackground_MR_Blue_S_RsrcID 1649
#define kUICustMenuBackground_MR_Blue_N_RsrcID 1650
#define kUICustMenuBackground_MM_Yellow_S_RsrcID 1651
#define kUICustMenuBackground_MM_Yellow_N_RsrcID 1652
#define kUICustMenuBackground_MM_Violet_S_RsrcID 1653
#define kUICustMenuBackground_MM_Violet_N_RsrcID 1654
#define kUICustMenuBackground_MM_Red_S_RsrcID 1655
#define kUICustMenuBackground_MM_Orange_S_RsrcID 1656
#define kUICustMenuBackground_MM_Orange_N_RsrcID 1657
#define kUICustMenuBackground_MM_Green_S_RsrcID 1658
#define kUICustMenuBackground_MM_Green_N_RsrcID 1659
#define kUICustMenuBackground_MM_Gray_S_RsrcID 1660
#define kUICustMenuBackground_MM_Gray_N_RsrcID 1661
#define kUICustMenuBackground_MM_Blue_S_RsrcID 1662
#define kUICustMenuBackground_MM_Blue_N_RsrcID 1663
#define kUICustMenuBackground_ML_Yellow_S_RsrcID 1664
#define kUICustMenuBackground_ML_Yellow_N_RsrcID 1665
#define kUICustMenuBackground_ML_Violet_S_RsrcID 1666
#define kUICustMenuBackground_ML_Violet_N_RsrcID 1667
#define kUICustMenuBackground_ML_Red_S_RsrcID 1668
#define kUICustMenuBackground_ML_Red_N_RsrcID 1669
#define kUICustMenuBackground_ML_Orange_S_RsrcID 1670
#define kUICustMenuBackground_ML_Orange_N_RsrcID 1671
#define kUICustMenuBackground_ML_Green_S_RsrcID 1672
#define kUICustMenuBackground_ML_Green_N_RsrcID 1673
#define kUICustMenuBackground_ML_Gray_S_RsrcID 1674
#define kUICustMenuBackground_ML_Gray_N_RsrcID 1675
#define kUICustMenuBackground_ML_Blue_S_RsrcID 1676
#define kUICustMenuBackground_ML_Blue_N_RsrcID 1677
#define kUICustMenuBackground_BR_Yellow_S_RsrcID 1678
#define kUICustMenuBackground_BR_Yellow_N_RsrcID 1679
#define kUICustMenuBackground_BR_Violet_S_RsrcID 1680
#define kUICustMenuBackground_BR_Violet_N_RsrcID 1681
#define kUICustMenuBackground_BR_Red_S_RsrcID 1682
#define kUICustMenuBackground_BR_Red_N_RsrcID 1683
#define kUICustMenuBackground_BR_Orange_S_RsrcID 1684
#define kUICustMenuBackground_BR_Orange_N_RsrcID 1685
#define kUICustMenuBackground_BR_Green_S_RsrcID 1686
#define kUICustMenuBackground_BR_Green_N_RsrcID 1687
#define kUICustMenuBackground_MM_Red_N_RsrcID 1688
#define kUICustMenuBackground_BR_Gray_S_RsrcID 1689
#define kUICustMenuBackground_BR_Gray_N_RsrcID 1690
#define kUICustMenuBackground_BR_Blue_S_RsrcID 1691
#define kUICustMenuBackground_BR_Blue_N_RsrcID 1692
#define kUICustMenuBackground_BM_Yellow_S_RsrcID 1693
#define kUICustMenuBackground_BM_Yellow_N_RsrcID 1694
#define kUICustMenuBackground_BM_Violet_S_RsrcID 1695
#define kUICustMenuBackground_BM_Violet_N_RsrcID 1696
#define kUICustMenuBackground_BM_Red_S_RsrcID 1697
#define kUICustMenuBackground_BM_Orange_S_RsrcID 1698
#define kUICustMenuBackground_BM_Green_S_RsrcID 1699
#define kUICustMenuBackground_BM_Green_N_RsrcID 1700
#define kUICustMenuBackground_BM_Gray_S_RsrcID 1701
#define kUICustMenuBackground_BM_Gray_N_RsrcID 1702
#define kUICustMenuBackground_BM_Blue_S_RsrcID 1703
#define kUICustMenuBackground_BM_Blue_N_RsrcID 1704
#define kUICustMenuBackground_BL_Yellow_S_RsrcID 1705
#define kUICustMenuBackground_BL_Yellow_N_RsrcID 1706
#define kUICustMenuBackground_BL_Violet_S_RsrcID 1707
#define kUICustMenuBackground_BL_Violet_N_RsrcID 1708
#define kUICustMenuBackground_BL_Red_S_RsrcID 1709
#define kUICustMenuBackground_BL_Red_N_RsrcID 1710
#define kUICustMenuBackground_BL_Orange_S_RsrcID 1711
#define kUICustMenuBackground_BL_Orange_N_RsrcID 1712
#define kUICustMenuBackground_BL_Green_S_RsrcID 1713
#define kUICustMenuBackground_BL_Green_N_RsrcID 1714
#define kUICustMenuBackground_BL_Gray_S_RsrcID 1715
#define kUICustMenuBackground_BM_Orange_N_RsrcID 1716
#define kUICustMenuBackground_UM_Orange_N_RsrcID 1717
#define kUICustMenuBackground_UM_Green_S_RsrcID 1718
#define kUICustMenuBackground_UM_Gray_S_RsrcID 1719
#define kUICustMenuBackground_UM_Gray_N_RsrcID 1720
#define kUICustMenuBackground_BM_Red_N_RsrcID 1721
#define kUICustMenuBackground_UM_Green_N_RsrcID 1722
#define kUICustMenuBackground_BL_Gray_N_RsrcID 1723
#define kUICustMenuBackground_BL_Blue_S_RsrcID 1724
#define kUICustMenuBackground_BL_Blue_N_RsrcID 1725

// ----- Application icon resources

#define kMediumWarningSignRsrcID		kWarningMediumIcon
#define kLargeWarningSignRsrcID			kWarningBigIcon

#define kLargeStopSignRsrcID			kStopSignBigIcon

// pict/bitmap rsrc ids
#ifndef TRIAL
#define kStartupScreenRsrcID 1800  // ditl/dialog id
#else
#define kStartupScreenRsrcID 1850  // ditl/dialog id - trial version
#endif

#define kMenuDashBitmapRsrcID 200 // bitmap for dash on windows for mixed state menus

// OWL App Bar resources
#define kAppBarADAMRsrcID							8000

#define kAppBarEVERsrcID							8100
#define kAppBarLayoutViewOptionsEVERsrcID			8110
#define kAppBarStoryViewOptionsEVERsrcID			8120
#define kAppBarScreenModeEVERsrcID					8130
#define kAppBarLayoutWidgetEVERsrcID				8140

#endif // __ApplDefs__

