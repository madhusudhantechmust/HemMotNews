//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MKeyboardDefs.h $
//  
//  Owner: Tom Taylor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  This file lists a number of helpful defines for typical keyboard character codes.
//  
//========================================================================================

#pragma once
#ifndef __MKEYBOARDDEFS__
#define __MKEYBOARDDEFS__

// Macintosh Only Definition
const SysChar kExtendedChar	= 0x10;	// when this character is found as the character in the
									// Macintosh event record, the key code holds the key
									// we're interested in.

// ***these are char codes***

// Special Keys
const SysChar kBackspaceKey			= 0x08;
const SysChar kDeleteKey			= 0x7f;
const SysChar kTabKey				= 0x09;
const SysChar kReturnKey			= 0x0d;
const SysChar kEscapeKey			= 0x1b;
const SysChar kEnterKey				= 0x03;
const SysChar kHelpKey				= 0x05;
const SysChar kSpaceKey				= 0x20;

// Page Keys
const SysChar kPageUpKey			= 0x0b;
const SysChar kPageDownKey			= 0x0c;
const SysChar kHomeKey				= 0x01;
const SysChar kEndKey				= 0x04;

// Arrow Keys
const SysChar kUpArrowKey			= 0x1e;
const SysChar kDownArrowKey			= 0x1f;
const SysChar kRightArrowKey		= 0x1d;
const SysChar kLeftArrowKey			= 0x1c;

// these are virtual key codes.
// these keys have char codes, but we also define virtual keys for them:
extern const PUBLIC_DECL VirtualKey kVirtualBackspaceKey;
extern const PUBLIC_DECL VirtualKey kVirtualDeleteKey;
extern const PUBLIC_DECL VirtualKey kVirtualTabKey;
extern const PUBLIC_DECL VirtualKey kVirtualReturnKey;
extern const PUBLIC_DECL VirtualKey kVirtualEnterKey;
extern const PUBLIC_DECL VirtualKey kVirtualHelpKey;
extern const PUBLIC_DECL VirtualKey kVirtualPageUpKey;
extern const PUBLIC_DECL VirtualKey kVirtualPageDownKey;
extern const PUBLIC_DECL VirtualKey kVirtualHomeKey;
extern const PUBLIC_DECL VirtualKey kVirtualEndKey;
extern const PUBLIC_DECL VirtualKey kVirtualUpArrowKey;
extern const PUBLIC_DECL VirtualKey kVirtualDownArrowKey;
extern const PUBLIC_DECL VirtualKey kVirtualRightArrowKey;
extern const PUBLIC_DECL VirtualKey kVirtualLeftArrowKey;
extern const PUBLIC_DECL VirtualKey kVirtualSpaceKey;

// these keys do not have unique char codes. their virtual keys rely on keycodes.
// these keys have the same key char, but different key codes.
extern const PUBLIC_DECL VirtualKey kVirtualEscapeKey;
extern const PUBLIC_DECL VirtualKey kVirtualClearKey;

extern const PUBLIC_DECL VirtualKey kFunctionKey1;
extern const PUBLIC_DECL VirtualKey kFunctionKey2;
extern const PUBLIC_DECL VirtualKey kFunctionKey3;
extern const PUBLIC_DECL VirtualKey kFunctionKey4;
extern const PUBLIC_DECL VirtualKey kFunctionKey5;
extern const PUBLIC_DECL VirtualKey kFunctionKey6;
extern const PUBLIC_DECL VirtualKey kFunctionKey7;
extern const PUBLIC_DECL VirtualKey kFunctionKey8;
extern const PUBLIC_DECL VirtualKey kFunctionKey9;
extern const PUBLIC_DECL VirtualKey kFunctionKey10;
extern const PUBLIC_DECL VirtualKey kFunctionKey11;
extern const PUBLIC_DECL VirtualKey kFunctionKey12;
extern const PUBLIC_DECL VirtualKey kFunctionKey13;
extern const PUBLIC_DECL VirtualKey kFunctionKey14;
extern const PUBLIC_DECL VirtualKey kFunctionKey15;
extern const PUBLIC_DECL VirtualKey kFunctionKey16;
extern const PUBLIC_DECL VirtualKey kFunctionKey17;
extern const PUBLIC_DECL VirtualKey kFunctionKey18;
extern const PUBLIC_DECL VirtualKey kFunctionKey19;
extern const PUBLIC_DECL VirtualKey kNumericPad0;
extern const PUBLIC_DECL VirtualKey kNumericPad1;
extern const PUBLIC_DECL VirtualKey kNumericPad2;
extern const PUBLIC_DECL VirtualKey kNumericPad3;
extern const PUBLIC_DECL VirtualKey kNumericPad4;
extern const PUBLIC_DECL VirtualKey kNumericPad5;
extern const PUBLIC_DECL VirtualKey kNumericPad6;
extern const PUBLIC_DECL VirtualKey kNumericPad7;
extern const PUBLIC_DECL VirtualKey kNumericPad8;
extern const PUBLIC_DECL VirtualKey kNumericPad9;
extern const PUBLIC_DECL VirtualKey kNumericPadPeriod;
extern const PUBLIC_DECL VirtualKey kNumericPadSubtract;
extern const PUBLIC_DECL VirtualKey kNumericPadAdd;
extern const PUBLIC_DECL VirtualKey kNumericPadMultiply;
extern const PUBLIC_DECL VirtualKey kNumericPadDivide;


// Modifiers Keys -- These are only valid when calling IEvent::GetVirtualKey()
// (I had to add "Virtual" prefix because ICursorMgr already defines kControlKey, etc.)
extern const PUBLIC_DECL VirtualKey kVirtualControlKey;
extern const PUBLIC_DECL VirtualKey kVirtualShiftKey;
extern const PUBLIC_DECL VirtualKey kVirtualOptionAltKey;
extern const PUBLIC_DECL VirtualKey kVirtualCapsLockKey;
extern const PUBLIC_DECL VirtualKey kVirtualCmdKey;

#endif	// __MKEYBOARDDEFS__
