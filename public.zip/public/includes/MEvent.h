//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MEvent.h $
//  
//  Owner: ?
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MEVENT__
#define __MEVENT__

#ifndef __IEVENT__
#include "IEvent.h"
#endif

#include <Events.h>

/** Custom event class */
enum { kEventClassCustom = 'cust' };

/** Custom event kind */
enum { kEventWakeupEventLoop = 1 };

/** The actual AppleMenu const is defined in Mac's Types.r file. Re-define it here for use in Shuksan */
#define kAppleMenuConst 0x14

/** Support for two-axis wheel event (kEventMouseScroll, e.g. Mighty Mouse). Not yet in available in public headers.
	See http://developer.apple.com/qa/qa2005/qa1453.html for more details.
*/
enum
{
	kEventParamMouseWheelSmoothVerticalDelta       = 'saxy', // typeSInt32
	kEventParamMouseWheelSmoothHorizontalDelta     = 'saxx', // typeSInt32
};

enum {
  kEventMouseScroll             = 11
};

/** Support for gestures.  Not yet available in public headers.
	See http://pct.corp.adobe.com/Apple/gestures.html for more details.
*/

/*��������������������������������������������������������������������������������������*/
/*  Gesture Events                                                                      */
/*��������������������������������������������������������������������������������������*/
/*
 kEventClassGesture quick reference:
 
 kEventGestureStarted                = 1,
 kEventGestureEnded                  = 2,
 
 kEventGestureMagnify                = 4,
 kEventGestureSwipe                  = 5,
 kEventGestureRotate                 = 6,
 */

enum {
	kEventClassGesture            = 'gest'
};

enum {
	kEventParamMagnificationAmount = 'magn', /* typeCGFloat*/
	kEventParamRotationAmount     = 'rota', /* typeCGFloat*/
	kEventParamSwipeDirection     = 'swip', /* typeHIPoint*/
};

/*
 *  kEventClassGesture / kEventGestureStarted
 *  
 *  Discussion:
 *    Sent when a gesture has started.
 *  
 *  Parameters:
 *    
 *    --> kEventParamMouseLocation (in, typeHIPoint)
 *          The mouse location, in global coordinates.
 *    
 *    --> kEventParamKeyModifiers (in, typeUInt32)
 *          The keyboard modifiers that were pressed when the event was
 *          generated.
 *  
 */
enum {
	kEventGestureStarted          = 1
};

/*
 *  kEventClassGesture / kEventGestureEnded
 *  
 *  Discussion:
 *    Sent when a gesture has ended.
 *  
 *  Parameters:
 *    
 *    --> kEventParamMouseLocation (in, typeHIPoint)
 *          The mouse location, in global coordinates.
 *    
 *    --> kEventParamKeyModifiers (in, typeUInt32)
 *          The keyboard modifiers that were pressed when the event was
 *          generated.
 *  
 */
enum {
	kEventGestureEnded            = 2
};

/*
 *  kEventClassGesture / kEventGestureMagnify
 *  
 *  Discussion:
 *    Sent when the user performs a magnify gesture, otherwise known as
 *    a zoom gesture, or a pinch.
 *  
 *  Parameters:
 *    
 *    --> kEventParamMouseLocation (in, typeHIPoint)
 *          The mouse location, in global coordinates.
 *    
 *    --> kEventParamKeyModifiers (in, typeUInt32)
 *          The keyboard modifiers that were pressed when the event was
 *          generated.
 *    
 *    --> kEventParamMagnificationAmount (in, typeCGFloat)
 *          The desired magnification percentage based on the user's
 *          gesture.
 *  
 */
enum {
	kEventGestureMagnify          = 4
};

/*
 *  kEventClassGesture / kEventGestureSwipe
 *  
 *  Discussion:
 *    Sent when the user performs a swipe gesture.
 *  
 *  Parameters:
 *    
 *    --> kEventParamMouseLocation (in, typeHIPoint)
 *          The mouse location, in global coordinates.
 *    
 *    --> kEventParamKeyModifiers (in, typeUInt32)
 *          The keyboard modifiers that were pressed when the event was
 *          generated.
 *    
 *    --> kEventParamSwipeDirection (in, typeHIPoint)
 *          A point describing the direction to move the content in
 *          respond to the user's gesture. If the y coordinate is -1,
 *          move the content up. If the y coordinate is 1, move the
 *          content down. If the x coordinate is -1, move the content
 *          to the left. If the x coordinate is 1, move the content to
 *          the right.
 *  
 */
enum {
	kEventGestureSwipe            = 5
};

/*
 *  kEventClassGesture / kEventGestureRotate
 *  
 *  Discussion:
 *    Sent when the user performs a rotate gesture.
 *  
 *  Parameters:
 *    
 *    --> kEventParamMouseLocation (in, typeHIPoint)
 *          The mouse location, in global coordinates.
 *    
 *    --> kEventParamKeyModifiers (in, typeUInt32)
 *          The keyboard modifiers that were pressed when the event was
 *          generated.
 *    
 *    --> kEventParamRotationAmount (in, typeCGFloat)
 *          The desired rotation amount, in degrees in polar
 *          coordinates.
 *  
 */
enum {
	kEventGestureRotate           = 6
};

/** End private excerpt for two-axis wheel events. This block can go away once the API is published. */

/**	This is the macintosh implementation of an Event. The only clients who need to use this class are those who need to create an event to pass around. This is fairly rare.
	Usually you can declare a PlatformEvent on the stack, set the sys event into it, run it through the event converter, and then pass it to the event dispatcher.
	<pre>
		InterfacePtr<const IApplication> app( GetExecutionContextSession()->QueryApplication() );
		InterfacePtr<IEventDispatcher> dispatcher(app, IID_IEVENTDISPATCHER);

		PlatformEvent myEvent;
		myEvent.SetSysEvent(osLevelEvent);

		GetExecutionContextSession()->GetEventConverter()->ConvertIEvent(myEvent);

		dispatcher->DispatchEvent(&myEvent);
	</pre>

	@see PlatformEvent.h
	@see IEvent
	@see IEventConverter
	@see IEventDispatcher
*/
class PUBLIC_DECL MEvent : public IEvent
{
	public:
		MEvent();


		virtual bool16		LButtonDn() const;

		virtual bool16		OptionAltKeyDown() const;

		virtual bool16		CmdKeyDown() const;

		virtual bool16		ShiftKeyDown() const;

		virtual bool16		ShiftLockKeyDown() const;

		virtual bool16 		MacCtrlDown() const;

		virtual bool16	LeftAltDown() const;

		virtual bool16	RightAltDown() const;

		virtual bool16	LeftControlDown() const;

		virtual bool16	RightControlDown() const;

		virtual VirtualKey		GetVirtualKey() const;

		virtual SysChar 	GetChar() const;

		virtual void  SetChar( SysChar theChar );


		virtual SysKeyCode  GetKeyCode() const;

		virtual bool16		IsAltGrChar() const;

		virtual	SysEvent  		GetSysEvent();

		virtual	EventRecord*	GetEventRecord();

		virtual	void			SetSysEvent(SysEvent theEvent);

		virtual GSysPoint 	GlobalWhere() const;
		virtual PMPoint GetMouseScrollDelta(ScrollUnits units = kLines) const;
		virtual PMReal	GetTime() const;

		virtual SysWindow 			GetSysWindow() const;

		virtual void 		SetSysWindow(const SysWindow targetWindow);


		virtual IEventHandler *GetTarget() const;
		virtual void 		SetTarget(const IEventHandler *target);

		virtual void SetReturnValue(uintptr_t value);
		virtual uintptr_t GetReturnValue() const;

		virtual void SetSystemHandledState(SystemHandledState state);
		virtual SystemHandledState GetSystemHandledState() const;

		virtual EventType GetType() const;
		virtual void SetType(const EventType theType);

		virtual int16				GetPartCode() const;

		virtual void		SetPartCode( const int16 pCode );

		virtual IPMUnknown* QueryTargetWindowInterface(const PMIID&) const;


		const MEvent& 		operator=(const MEvent& e)
										{
											fMacEvent = ((MEvent&)e).GetSysEvent();
											fThePartCode = e.GetPartCode();
											fTheWindow = e.GetSysWindow();
											fTarget = e.GetTarget();
											fType = e.GetType();
											return *this;
										}

	virtual void SetEventHandlerRef(EventHandlerCallRef ref);
	virtual EventHandlerCallRef GetEventHandlerRef() const;

	private:
		EventRef			fMacEvent;
		EventHandlerCallRef	fEventHandlerRef;
		EventRecord			fConvertedEventRecord;
		int16				fThePartCode;
		SysWindow			fTheWindow;
		IEventHandler*		fTarget;
		SystemHandledState	fSystemHandledState;
		IEvent::EventType	fType;
#ifdef DEBUG
		bool16				fEventValid;
#endif

};

#endif // __MEVENT__
