//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/HitTestDragConstants.h $
//  
//  Owner: jargast
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __HitTestDragConstants__
#define __HitTestDragConstants__

// Changing these will globally affect how we hit test and what distance the user must
// move before an item is edited or created.

const int32 kHitTestTolerance	= 2;
const int32 kMinDragDistance	= 3;
const uint32 kMinConstrainedDragDistance = 5;
const int32 kHitTestMoreGenerousTolerance = 6;
const int32 kHitTestFreeTransformTolerance = 10;
const uint32 kAutoScrollDelay  = 10;		// Number of 60ths of a second between drop target autoscrolls. Prevents scrolling too fast.
const uint32 kFastAutoScrollDelay  = 7;		// Number of 60ths of a second between drop target autoscrolls. Used for views that want to scroll a little faster.
const uint32 kMinAutoScrollDelay  = 3;		// Number of 60ths of a second between drop target autoscrolls. Used for views that want to scroll even faster. This is the limit!
const PMReal kDragMotionIsSlowThreshhold = 8.0;	// Minimum distance between mouse moves to avoid extra calls to ISnapTo

#endif
