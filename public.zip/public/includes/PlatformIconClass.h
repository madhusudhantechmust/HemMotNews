//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/PlatformIconClass.h $
//  
//  Owner: lance bushore
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  An icon class that draws itself without a widget
//  
//  This is a class that will draw an icon family with the specified resource id. 
//  
//========================================================================================

#pragma once
#ifndef __PlatformIconClass__
#define __PlatformIconClass__

#ifdef WIDGET_BUILD
#pragma export on
#endif

#include "PNGArt.h"
class IViewPort;

/** This class encapsulates loading & drawing an icon. The icon may be either a traditional OS icon resource,
	or a PNG.
*/
class WIDGET_DECL PlatformIconClass{
public:
	PlatformIconClass();
 	~PlatformIconClass();
	
	/** Read or write this object to the given stream.
		@param s the stream to read or write from/to
		@param prop ignored
	*/
	void 		ReadWrite(IPMStream* s, ImplementationID prop);

	/** Load an icon into this object for later drawing.
		@param pid the plugin the icon is coming from
		@param iconRsrcID the icon/PNG resource id within the plugin
	*/
	void		LoadIcon(const PluginID & pid, const RsrcID& iconRsrcID);

	/** Draw the icon previously loaded into this object
		@param viewPort the port to draw into
		@param bbox the rect to draw into
		@param drawDisabled a boolean indicating if the icon should be drawn with a disabled look
	*/
	void		Draw(IViewPort* viewPort, const SysRect& bbox,bool16 drawDisabled);
			
protected:
#ifdef MACINTOSH
	SysHandle		fTheIcon;
#else
	HICON			fTheIcon;
#endif
	PluginID		fPid;
	RsrcID			fIconRsrcID;
	int16			fIconSize;
	PNGArt			fPNGArt;
};

#pragma export off

#endif // __PlatformIconClass__




