//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/PMLocaleIds.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __PMLocaleIds_h__
#define __PMLocaleIds_h__

#ifdef MACINTOSH
#include "MLocaleIds.h"
#elif defined WINDOWS
#include "WLocaleIds.h"
#endif

#include "FeatureSets.h"
// ----- Feature Set

/*
#define k_FeatureSet_enUS		k_enUS
#define k_FeatureSet_enGB		k_enGB
#define k_FeatureSet_deDE		k_deDE
#define k_FeatureSet_frFR		k_frFR
#define k_FeatureSet_jaJP		k_jaJP
#define k_FeatureSet_esES		k_esES
#define k_FeatureSet_ptBR		k_ptBR
#define k_FeatureSet_svSE		k_svSE
#define k_FeatureSet_daDK		k_daDK
#define k_FeatureSet_nlNL		k_nlNL
#define k_FeatureSet_itIT		k_itIT
#define k_FeatureSet_noNO		k_noNO
#define k_FeatureSet_fiFI		k_fiFI
#define k_FeatureSet_Wild		k_Wild
*/
// ----- Locale offsets
// These signify resource IDs that must be unique to a given featureset and locale combination.

#define index_enUS				0x0001
#define index_enGB				0x0002
#define index_deDE				0x0003
#define index_frFR				0x0004
#define index_jaJP				0x0005	// Japanese featureset, Japanese locale
#define index_esES				0x0006
#define index_ptBR				0x0007
#define index_svSE				0x0008
#define index_daDK				0x0009
#define index_nlNL				0x000a
#define index_itIT				0x000b
#define index_noNO				0x000c
#define index_fiFI				0x000d
#define index_jaJP_enUS			0x000e	// Japanese featureset, English locale
#define index_koKR				0x000f	// Japanese featureset, Korean locale
#define index_zhCN				0x0010	// Japanese featureset, Simplified Chinese locale
#define index_zhTW				0x0011	// Japanese featureset, Traditional Chinese locale

#define index_elGR		        0x0012 // was - 0x000e
#define index_csCZ				0x0013 // was - 0x000f
#define index_plPL				0x0014 // was - 0x0010
#define index_hrHR				0x0015 // was - 0x0011
#define index_huHU				0x0016 // was - 0x0012
#define index_ruRU				0x0017 // was - 0x0013
#define index_skSK				0x0018 // was - 0x0014
//#define index_k_el            0x0019 // was - 0x0015
#define index_trTR				0x001a // was - 0x0016
#define index_roRO				0x001b // was - 0x0017
#define index_bgBG				0x001c // was - 0x0018
#define index_beBY				0x001d // was - 0x0019
#define index_etEE				0x001e // was - 0x001a
#define index_lvLV				0x001f // was - 0x001b
#define index_ltLT				0x0020 // was - 0x001c
#define index_slSL				0x0021 // was - 0x001d
#define index_ukUA				0x0022 // was - 0x001e
#define index_heIL				0x0023 // was - 0x001f
#define index_arAE				0x0024 // was - 0x0020

// ----- Product based offsets for feature set interface combinations.  Note that using
//		 none of these is the same as specifying AllProducts (which is the normal situation).
//		 [jon 6/20/02]

#define index_AllProductsFS		0x0000
#define index_InDesignFS		0x0050
#define index_InCopyFS			0x0100
#define index_InDesignServerFS	0x0150


// ----- Character encoding converters are specified in the string table resources

//MAC is #define kEuropeanWinToMacEncodingConverter kEuropeanEncodingWinToMacBoss
//WIN is #define kEuropeanMacToWinEncodingConverter kEuropeanEncodingMacToWinBoss
#define kResourceUTF8Encoded 8

#endif // __PMLocaleIds_h__

