//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/DOMAttributeValue.h $
//  
//  Owner: Steve Pellegrin
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __DOMAttributeValue_h__
#define __DOMAttributeValue_h__

// Adobe Patent or Adobe Patent Pending Invention Included Within this File
// Adobe patent application tracking B234, entitled Method and apparatus for formatting portion of content, inventors: Craig Rainwater, Steve Pellegrin,  Robin Briggs 

#include "ScriptData.h"

class IPMStream;


/** Extends ScriptData to provide additional functionality for working with INX.
    An instance of this class represents the value of a single DOM attribute.
	@author Steve Pellegrin
	@see IDOMElement
*/
class PUBLIC_DECL DOMAttributeValue : public ScriptData
{
public:
	typedef object_type data_type;

public:
	typedef ScriptData::ScriptDataType		AttributeType;

public:
	/** Constructs an empty value
	*/
	DOMAttributeValue();

	/** Constructs a WideString value.
	    @param value IN The string value.
	*/
	DOMAttributeValue(const WideString &value);

	/** Constructs an int32 value.
	    @param value IN The int32 value.
	*/
   	DOMAttributeValue(int32 value);

	/** Constructs a stream value.
	    @param value IN The stream value.
	*/
   	DOMAttributeValue(IPMStream *value);
 
	/** Constructs a value that is a copy of another
		@param other IN the value to copy.
	*/
	DOMAttributeValue(const DOMAttributeValue &other);

	/** Constructs a value that is a copy of a ScriptData.
	    @param readOnly IN Whether the value is read-only.
		@param sd IN The ScriptData to copy.
		@see ScriptData
	*/
	DOMAttributeValue(bool16 readOnly, const ScriptData &sd);
  
	/** Destructor
	*/
	virtual ~DOMAttributeValue() {}
 
	/** Determine whether the value is read-only.
	    @return kTrue if this value is read-only, kFalse otherwise.
	*/
	bool16 IsReadOnly() const { return fReadOnly ; }

	/** Sets the value's read-only attribute.
	    @param readOnly IN Whether the value is read-only or not.
	*/
	void SetReadOnly(bool16 readOnly) { fReadOnly = readOnly ; }

	/** Determines whether the value is empty or not.
	    @return kTrue if the value is empty, kFalse otherwise.
	*/
	bool16 IsEmpty() const;

	/** Tests the value for equality with another.
		@param other IN Another value.
	*/
	bool16 operator==(const DOMAttributeValue &other) const;

	/** Tests the value for inequality with another.
		@param other IN Another value.
	*/
	bool16 operator!=(const DOMAttributeValue &other) const
		{return !(*this == other);}

	/** Assign another value to this one.
		@param other IN Another value.
	*/
	DOMAttributeValue &operator=(const DOMAttributeValue &other);

	/** Assign ScriptData to this one.
		@param other IN ScriptData value.
	*/
	DOMAttributeValue &operator=(const ScriptData &other);

private:
	void Copy(const DOMAttributeValue &other);
	
private:
	bool16		fReadOnly;
};

#endif	// __DOMAttributeValue_h__
