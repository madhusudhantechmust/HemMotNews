//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/keyboarddefs.h $
//  
//  Owner: Frits Habermann
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  This file lists a number of helpful defines for typical keyboard character codes.
//  
//========================================================================================

#pragma once
#ifndef __KEYBOARDDEFS__
#define __KEYBOARDDEFS__

#include "VirtualKey.h"

// Special Characters
const int16 kPlainCharKeyCode = -1;
const int16 kNullChar				= 0x0;

// special virtual key
const VirtualKey kVirtualNullKey(0,0);

#ifdef MACINTOSH
#include "MKeyboardDefs.h"
#endif
#ifdef WINDOWS
#include "WKeyboardDefs.h"
#endif

#endif
