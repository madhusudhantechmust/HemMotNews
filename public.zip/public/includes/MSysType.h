//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MSysType.h $
//  
//  Owner: ?
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MSYSTYPE__
#define __MSYSTYPE__

#define ON_MAC_USE_HIVIEW_COORDS	1

#include "K2TypeTraits.h"
//======================================================================
// Isolate windowing system (Mac OS QuickDraw or Core Graphics) vs. Windows GDI)
//======================================================================

#ifdef ON_MAC_USE_HIVIEW_COORDS
	typedef int16 QDCoord;				// 16 bit coordinate system (from Quickdraw)

	// Quickdraw coordinate space (16 bit integer)
	typedef Rect QDRect;
	typedef Rect GQDRect;					// SysRect in "Global" screen or device coordinates
	typedef Rect WQDRect;					// SysRect in "Window" coordinates
	typedef Point QDPoint;
	typedef Point GQDPoint;				// "Global" SysPoint
	typedef Point WQDPoint;				// "Window" SysPoint  (result of GlobalToLocal)
	typedef RgnHandle QDRgn;


	// 32-bit integer coordinate space
	struct Int32Rect {						// Use in cases where coords must be integral (but not QD specific). Bitmap bounds, image internal (pixel) bounds, etc.
  		int32               top;
  		int32               left;
  		int32               bottom;
  		int32               right;
  		
  		Int32Rect(const QDRect& r) {top = r.top; left = r.left; bottom = r.bottom; right = r.right;}
  		Int32Rect() {top = 0; left = 0; bottom = 0; right = 0;}
  		Int32Rect& operator=(const Int32Rect& r)  {top = r.top; left = r.left; bottom = r.bottom; right = r.right; return *this;}
  		operator QDRect() const {QDRect foo; foo.top = top, foo.left = left, foo.bottom = bottom, foo.right = right; return foo;}
  	};							

	// Default coordinate space - based on HIView/Core Graphics
	typedef float SysCoord;				// Floating point coordinate system (from Core graphics)
														// 	origin is at top left, coordinates grow down and right as in Quickdraw and Win GDI
	
	//typedef HIPoint SysPoint;
	struct SysPoint : HIPoint {
  		SysPoint(SysCoord h, SysCoord v ) {x = h; y = v;}
  		SysPoint(const QDPoint& pt) {x = pt.h; y = pt.v;}
  		SysPoint(const HIPoint& pt) {x = pt.x; y = pt.y;}
  		SysPoint() {x = 0; y = 0;}
  		SysPoint& operator=(const SysPoint& pt)  {x = pt.x; y = pt.y; return *this;}
  		SysPoint& operator=(const HIPoint& pt)  {x = pt.x; y = pt.y; return *this;}

		operator const HIPoint & () const { return *this; }
  		operator QDPoint() const
  		{
  			QDPoint foo; 
  			foo.h = (int16) x; foo.v = (int16) y;
  			return foo;
  		}
	};

	typedef SysPoint GSysPoint;		// "Global" SysPoint
	typedef SysPoint WSysPoint;		// "Window" SysPoint

	//typedef HISize SysSize;			// Size
	struct SysSize : HISize {
  		SysSize(SysCoord h, SysCoord w ) {width = h; height = w;}
  		SysSize(const QDPoint& pt) {width = pt.h; height = pt.v;}
  		SysSize(const HIPoint& pt) {width = pt.x; height = pt.y;}
  		SysSize(const HISize& sz)  {width = sz.width; height = sz.height;}
  		SysSize() {width = 0; height = 0;}
  		SysSize& operator=(const SysPoint& pt)  {width = pt.x; height = pt.y; return *this;}
  		SysSize& operator=(const HISize& sz)		 {width = sz.width; height = sz.height; return *this;}

			operator const HISize & () const { return *this; }
  		operator QDPoint() const
  		{
  			QDPoint foo; 
  			foo.h = (int16) width; foo.v = (int16) height;
  			return foo;
  		}
	};

	//typedef HIRect SysRect;
	struct SysRect : HIRect {
  		SysRect(SysCoord left, SysCoord top, SysCoord right, SysCoord bottom ) {origin.x = left; origin.y = top; size.width = right - left; size.height = bottom - top;}
  		SysRect(const SysPoint& theOrigin, const SysSize& theSize ) {origin = theOrigin; size = theSize;}
  		SysRect(const QDRect& r) {origin.x = r.left; origin.y = r.top; size.width = r.right - r.left; size.height = r.bottom - r.top;}
  		SysRect(const Int32Rect& r) {origin.x = r.left; origin.y = r.top; size.width = r.right - r.left; size.height = r.bottom - r.top;}
  		SysRect() {origin.x =0; origin.y = 0; size.width = 0; size.height = 0;}
  		SysRect& operator=(const SysRect& r)  {origin = r.origin; size = r.size; return *this;}
  		SysRect& operator=(const HIRect& r)  {origin = r.origin; size = r.size; return *this;}
//  		bool16 operator==(const SysRect& r) const  {return (origin.x == r.origin.x) && (origin.y == r.origin.y) && (size.width == r.size.width) && (size.height == r.size.height);}
  //		bool16 operator!=(const SysRect& r) const  {return !(*this == r);}
  		
		operator const HIRect & () const { return *this; }
  		operator Int32Rect() const 
  		{
  			Int32Rect foo; 
  			CGRect temp = CGRectIntegral(*this);
  			foo.left = (int32) temp.origin.x; foo.top = (int32) temp.origin.y; foo.right = foo.left + (int32) temp.size.width; foo.bottom = foo.top +(int32) temp.size.height;
  			return foo;
  		}
  		operator QDRect() const
  		{
  			QDRect foo; 
  			CGRect temp = CGRectIntegral(*this);
  			foo.left = (int16) temp.origin.x; foo.top = (int16) temp.origin.y; foo.right = foo.left + (int16) temp.size.width; foo.bottom = foo.top +(int16) temp.size.height;
  			return foo;
  		}
	};
	
	typedef SysRect GSysRect;			// SysRect in "Global" screen or device coordinates
	typedef SysRect WSysRect;			// SysRect in "Window" coordinates

	typedef HIMutableShapeRef SysRgn;		
	typedef HIShapeRef ConstSysRgn;		// Ref counted, const version.

	typedef QDRgn SysWireframe;		// Implementation of wireframe feedback  (still using QD Regions at present)
	
#else
	typedef Fixed SysFixed;
	typedef Rect SysRect;
	typedef Rect GSysRect;				// SysRect in "Global" screen or device coordinates
	typedef Rect WSysRect;				// SysRect in "Window" coordinates
	typedef Point SysPoint;
	typedef Point GSysPoint;			// "Global" SysPoint
	typedef Point WSysPoint;			// "Window" SysPoint  (result of GlobalToLocal)
	typedef int16 SysCoord;

	typedef RgnHandle SysRgn;
	typedef RgnHandle ConstSysRgn;		// Same as SysRgn under Quickdraw.

	typedef int16 QDCoord;				// 16 bit coordinate system (from Quickdraw)

	typedef Rect QDRect;
	typedef Rect GQDRect;					// SysRect in "Global" screen or device coordinates
	typedef Rect WQDRect;					// SysRect in "Window" coordinates
	typedef Point QDPoint;
	typedef Point GQDPoint;				// "Global" SysPoint
	typedef Point WQDPoint;				// "Window" SysPoint  (result of GlobalToLocal)
	typedef RgnHandle QDRgn;

	typedef QDRgn SysWireframe;		// Implementation of wireframe feedback  (still using QD Regions at present)

	struct Int32Rect {						// Use in cases where coords must be integral (but not QD specific). Bitmap bounds, image internal (pixel) bounds, etc.
  		int32               top;
  		int32               left;
  		int32               bottom;
  		int32               right;
  		
  		Int32Rect(const QDRect& r) {top = r.top; left = r.left; bottom = r.bottom; right = r.right;}
  		Int32Rect() {top = 0; left = 0; bottom = 0; right = 0;}
  		Int32Rect& operator=(const Int32Rect& r)  {top = r.top; left = r.left; bottom = r.bottom; right = r.right; return *this;}
  		operator QDRect() const {QDRect foo; foo.top = top, foo.left = left, foo.bottom = bottom, foo.right = right; return foo;}
  	};							

#endif

typedef SysCoord GSysCoord;	// "Global" coordinate
typedef SysCoord WSysCoord;	// "Window" coordinate
typedef unsigned char SysChar;	// character code used by platform (ASCII+)
typedef uint16 SysKeyCode;	// code for key on keyboard
typedef WindowPtr SysWindow;
DECLARE_BASE_TYPE(SysWindow);
typedef ControlHandle SysControl;
typedef DialogPtr SysDialog;
DECLARE_BASE_TYPE(SysRgn);

typedef GrafPtr SysPort;
//DECLARE_BASE_TYPE(SysPort); // GrafPtr == WindowPtr
typedef CGContextRef SysPort_NEW;
DECLARE_BASE_TYPE(SysPort_NEW);

typedef GWorldPtr SysBitmap;				// This will become a CGContextRef
typedef CGContextRef SysBitmap_NEW;

typedef int16 SysFileRef;	// open file reference
typedef EventRef SysEvent;
typedef Handle SysHandle;
// Rather than remove calls to HLock and HUnlock we will simply define them as a no-op. 
#define HLOCK
#define HUNLOCK

typedef MenuHandle SysMenu;
DECLARE_BASE_TYPE(SysMenu);

typedef int16 MenuID;
typedef int32 PlatformError;
typedef uint32 UserError;
typedef int16 CursorID;
typedef CursHandle SysCursor;

typedef EndpointRef SysSocket;

typedef struct FInfo SysFileInfo;

typedef ResType RsrcType;
typedef char *RsrcName;
typedef uint32 RsrcID;

typedef bool16			(*PlatformDlgEventProc)(short, SysDialog);

// Connection information for loading & unloading DLLs

	typedef CFBundleRef SysConnection;	//BundleRef is nil if plugin bundle/dylib is not loaded
	DECLARE_BASE_TYPE(SysConnection);

#endif // __SYSTYPE__
