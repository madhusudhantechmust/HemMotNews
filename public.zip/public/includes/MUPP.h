//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MUPP.h $
//  
//  Owner: Robin Briggs
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MUPP__
#define __MUPP__

/** Utility class for creating Mac Universal Proc Pointers.
		Constructor creates the UPP, as in NewControlActionUPP.
		Destructor deletes the UPP, as in DisposeControlActionUPP.
		Usually used as a static instance that gets cleaned upat shutdown time.
*/
class PUBLIC_DECL MUPP
{
public:
	/** types of UPP that are supported */
	enum MUPPKind {
		/** */
		kListDefProc, 
		/** */
		kUserItemProc, 
		/** */
		kGrowZoneProc,
		/** */
		kDragGrayRgnProc,
		/** */
		kControlActionProc
//	kIndicatorActionProc
	};

	/** Constructor to create a Universal Proc Pointer
		@param procType IN one of the supported UPP types.
		@param proc IN the function to be called.
	*/
	MUPP(MUPPKind procType, void *proc);
	/** Destructor */
	~MUPP();
	
	/** Get the UPP */
	UniversalProcPtr GetProcPtr()	{ return fProcPtr; }
private:
	UniversalProcPtr	fProcPtr;
	MUPPKind			fUPPKind;
};

// These are not used in the Firedrake code base - DJB 4/11/2005
//typedef	pascal void (*IndicatorActionProc)(void);
//
//typedef UniversalProcPtr IndicatorActionUPP;
//
//enum
//{
//	uppIndicatorActionProcInfo = kPascalStackBased
//};
//
// These are not used in the Firedrake code base - DJB 4/11/2005
//#define NewIndicatorActionProc(userRoutine)		\
//			(IndicatorActionUPP) NewRoutineDescriptor((ProcPtr)(userRoutine), uppIndicatorActionProcInfo, GetCurrentArchitecture())
//
//#define CallIndicatorActionProc(userRoutine)	\
//			CallUniversalProc((UniversalProcPtr)(userRoutine), uppIndicatorActionProcInfo)

#endif	// __MUPP__
