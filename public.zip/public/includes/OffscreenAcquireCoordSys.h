//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/OffscreenAcquireCoordSys.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __OffscreenAcquireCoordSys__
#define __COffscreenAcquireCoordSys__

#include "CAcquireCoordSys.h"
#include "PMMatrix.h"


class IControlView;
class IViewPort;
class ITransform;

#ifdef WIDGET_BUILD
#pragma export on
#endif


/**
 An object that sets up the coordinate system for a view or viewport. This is
 a minimal implementation of CAcquireCoordSys. In particular, its Resume and
 Suspend implementations are no-ops.
 
 The intended use of this class is unclear. It is unused in the current 
 codebase and may be obsolete.
 
 @see AGMAcquireCoordSys
 */
class WIDGET_DECL OffscreenAcquireCoordSys : public CAcquireCoordSys
{
public:

	/**
	 Constructs a coordinate system acquisition object based on a viewport 
	 and a control view

	 @param viewPort	The viewport to base the coordinate system on
	 @param controlView	The control view to base the coordinate system on
	 */
	OffscreenAcquireCoordSys(IViewPort* viewPort, IControlView *controlView);

	/**
	 Constructs a coordinate system acquisition object based on a viewport 
	 and an optional transform

	 @param viewPort	The viewport to base the coordinate system on
	 @param xform		The transform to base the coordinate system on
	 */
	OffscreenAcquireCoordSys(IViewPort* viewPort, ITransform* xform = nil);

	/**
	 Constructs a coordinate system acquisition object based on a viewport 
	 and a matrix

	 @param viewPort	The viewport to base the coordinate system on
	 @param theMatrix	The matrix to base the coordinate system on
	 */
	OffscreenAcquireCoordSys(IViewPort* viewPort, const PMMatrix& theMatrix);

	/**
	 Constructs a coordinate system acquisition object based on a viewport, 
	 a matrix, and a control view

	 @param viewPort	The viewport to base the coordinate system on
	 @param theMatrix	The matrix to base the coordinate system on
	 @param controlView	The control view to base the coordinate system on
	 */
	OffscreenAcquireCoordSys(IViewPort* viewPort, const PMMatrix& theMatrix, IControlView* controlView);

	/**
	 Constructs a coordinate system acquisition object based on a viewport, 
	 a transform, and a control view

	 @param viewPort	The viewport to base the coordinate system on
	 @param xform		The transform to base the coordinate system on
	 @param controlView	The control view to base the coordinate system on
	 */
	OffscreenAcquireCoordSys(IViewPort* viewPort, ITransform* xform, IControlView* controlView);

	/**
	 Destructor
	 */
	~OffscreenAcquireCoordSys();
		
	/**
	 Gets the viewport for this object.
	 
	 @return the viewport on which this object is based
	 */
	virtual IViewPort*		GetViewPort() const;
	
	/**
	 Gets the transform matrix for this object.
	 
	 @return the transform matrix for this object
	 */
	virtual const PMMatrix&	GetTransform() const;
	
	/**
	 Gets the inverse of the transform matrix for this object.
	 
	 @return the inverse of the transform matrix for this object
	 */
	virtual const PMMatrix&	GetInverseTransform() const;
	
	/**
	 Gets the control view for this object.
	 
	 @return the control view on which this object is based. Always nil in this implementation.
	 */
	virtual IControlView*	GetView() const;

protected:

	virtual void			Resume();
	virtual void			Suspend();

	// ----- Data fields -----
	
	IViewPort* 			fVP;
	PMMatrix			fXForm;
	PMMatrix			fInvXForm;
	bool16				fInverseValid;
};

#pragma export off

inline IViewPort* OffscreenAcquireCoordSys::GetViewPort() const
{
	return fVP;
}

inline const PMMatrix& OffscreenAcquireCoordSys::GetTransform() const
{
	return fXForm;
}

inline IControlView* OffscreenAcquireCoordSys::GetView() const
{
	return nil;
}

#endif
