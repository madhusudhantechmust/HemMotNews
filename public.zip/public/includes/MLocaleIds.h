//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MLocaleIds.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MLocaleIds_h__
#define __MLocaleIds_h__

// ----- The following values are from Script.h which can't be included here because
//		 ODFRC won't compile it.
// #include <Script.h>

#define pm_verUS						0
#define pm_verFrance					1
#define pm_verBritain					2
#define pm_verGermany					3
#define pm_verItaly						4
#define pm_verNetherlands				5
#define pm_verSweden					7
#define pm_verSpain						8
#define pm_verDenmark					9
//#define pm_verBrazil					71 // brazil doesn't appear in the resedit 'vers' country popup, so we'll use portugal.
#define pm_verPortugal					10
#define pm_verNorway					12
#define pm_verIsrael					13
#define pm_verJapan						14
#define pm_verArabic					16
#define pm_verFinland					17
#define pm_verGreece					20
#define pm_verTurkey					24
#define pm_verRomania				39
#define pm_verLithuania				41
#define pm_verPoland					42
#define pm_verHungary					43
#define pm_verEstonia					44
#define pm_verLatvia					45
#define pm_verRussia					49
#define pm_verCzech					56
#define pm_verSlovak					57
#define pm_verByeloRussian 			61
#define pm_verUkraine					62
#define pm_verSlovenian				66
#define pm_verCroatia					68
#define pm_verBulgaria					72

#define pm_verKorea						51	// Korean
#define pm_verChina						52	// Chinese Simplified
#define pm_verTaiwan					53	// Chinese Traditional
#define pm_verThailand					54	// Thai
#define pm_verTamil						38	// Tamil -- not defined in apple script.h
#define pm_verVietnam					97	// Vietnamese

#define k_enUS				0 //pm_verUS
#define k_enGB				pm_verBritain
#define k_deDE				pm_verGermany
#define k_frFR				pm_verFrance
#define k_jaJP				pm_verJapan
#define k_esES				pm_verSpain
//#define k_ptBR				pm_verBrazil
#define k_ptBR				pm_verPortugal
#define k_svSE				pm_verSweden
#define k_daDK				pm_verDenmark
#define k_nlNL				pm_verNetherlands
#define k_itIT				pm_verItaly
#define k_noNO				pm_verNorway
#define k_fiFI				pm_verFinland
#define k_elGR				pm_verGreece	//Greek
#define k_csCZ				pm_verCzech	//Czech
#define k_plPL				pm_verPoland	//Polish
#define k_hrHR				pm_verCroatia	//Croatian
#define k_huHU				pm_verHungary	//Hungarian
#define k_ruRU				pm_verRussia	//Russian
#define k_skSK				pm_verSlovak	//Slovak
#define k_trTR				pm_verTurkey	//Turkish
#define k_roRO				pm_verRomania	//Romanian
#define k_bgBG				pm_verBulgaria	//Bulgarian
#define k_beBY				pm_verByeloRussian	//Belarussian
#define k_etEE				pm_verEstonia	//Estonian
#define k_lvLV				pm_verLatvia	//Latvian
#define k_ltLT					pm_verLithuania	//Lithuanian
#define k_slSL					pm_verSlovenian	//Slovenian
#define k_ukUA				pm_verUkraine	//Ukrainian
#define k_heIL				pm_verIsrael	//Hebrew
#define k_arAE				pm_verArabic	//Arabic
#define k_koKR				pm_verKorea	
#define k_zhCN				pm_verChina	
#define k_zhTW				pm_verTaiwan
#define k_taIN				pm_verTamil
#define k_thTH				pm_verThailand
#define k_viVN				pm_verVietnam

#define k_Wild				0x00FE	// move so that we can more easily identify locales vs. feature sets

// NOTE: If you add more locales here, make sure and also add them to the following places:
// InstallLanguagesCmd::Do() in LanguageCmd.cpp,
// DictEditorMenuComponent::QueryCurrentLanguage() in DictEditorMenuComponent.cpp,
// DictPrefsMenuComponent::QueryCurrentLanguage() in DictPrefsMenuComponent.cpp,
// and possibly XFLT_TEXT_IMP_SSFLT::SendLangID() in ssflt.cpp.

// ----- Character encoding converters are specified in the string table resources and
//		 are usually just the class ID of the service that provides the converter. But here
//		 we want to conditionally provide different converters depending on the platform.

#define kEuropeanWinToMacEncodingConverter kEuropeanEncodingWinToMacBoss
#define kEuropeanMacToWinEncodingConverter 0

#endif // __MLocaleIds_h__

