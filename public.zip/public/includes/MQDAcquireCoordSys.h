//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MQDAcquireCoordSys.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MQDAcquireCoordSys__
#define __MQDAcquireCoordSys__

#include "CAcquireCoordSys.h"
#include "PMMatrix.h"

#ifdef WIDGET_BUILD
#pragma export on
#endif

class IControlView;
class IViewPort;
class ITransform;

/** MQDAcquireCoordSys - An object that sets up the coordinate system for a given view or port.
	This is usually not used standalone but as a template parameter to AGMGraphicsContextWith.
	@see SysGraphicsContext.h
*/
class WIDGET_DECL MQDAcquireCoordSys : public CAcquireCoordSys
{
public:

	// ----- Initialization -----
	
	MQDAcquireCoordSys(IViewPort* viewPort, IControlView *controlView);
	MQDAcquireCoordSys(IViewPort* viewPort, ITransform* xform = nil);
	MQDAcquireCoordSys(IViewPort* viewPort, ITransform* xform, IControlView* controlView);
	MQDAcquireCoordSys(IViewPort* viewPort, const PMMatrix& theMatrix);
	MQDAcquireCoordSys(IViewPort* viewPort, const PMMatrix& theMatrix, IControlView* controlView);
	~MQDAcquireCoordSys();
		

	// ----- Accessors -----
	
	IViewPort*		GetViewPort() const;
	const PMMatrix&	GetTransform() const;
	const PMMatrix&	GetInverseTransform() const;
	IControlView*	GetView() const;

protected:
	void					CommonInit();
	
	virtual void			Resume();
	virtual void			Suspend();
	
	void					Setup();
	void					TearDown();

	// ----- Data fields -----
	
	IViewPort* 			fVP;
	PMMatrix			fXForm;
	PMMatrix			fInvXForm;
	bool16				fInverseValid;
	IControlView*		fView;
	QDPoint			fOrigin;
	QDPoint			fPrevOrigin;
#ifdef DEBUG
		SysPort fDebugPort;
#endif
};

#pragma export off

inline IViewPort* MQDAcquireCoordSys::GetViewPort() const
{
	return fVP;
}

inline const PMMatrix& MQDAcquireCoordSys::GetTransform() const
{
	return fXForm;
}

inline IControlView* MQDAcquireCoordSys::GetView() const
{
	return fView;
}

#endif
