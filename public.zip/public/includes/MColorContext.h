//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MColorContext.h $
//  
//  Owner: Mouhammad Fakhoury
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MColorContext__
#define __MColorContext__

#include "CColorContext.h"

#pragma export on

//
// MColorContext
//

/**
 Simple class wrapper around IInterfaceColors. Also acts as a stack-based 
 utility for ensuring that the foreground and background colors and the pen 
 state in effect at construction are restored at destruction.
 
 @see IInterfaceColors
 @see CColorContext
 @see WColorContext
 */
class PUBLIC_DECL MColorContext : public CColorContext{
public:
	/**
	 Default constructor. Takes a snapshot of foreground and background color
	 and the pen state so that each can be restored in the destructor.
	 */
	MColorContext();
	
	/**
	 Destructor. Restores foreground and background color and the pen state to 
	 their former values.
	 */
	~MColorContext();

	/**
	 Returns whether the monitor's color depth is > 1.
	 
	 @return kTrue if monitor's color depth is > 1
	 */
	bool16 IsMonitorColor()const;

private:
	RGBColor fPreviousBackColor;
	RGBColor fPreviousForeColor;
	PenState fPreviousPenState;
};

#pragma export off



#endif //__MColorContext__
