//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/FormatNumber.h $
//  
//  Owner: Robin Briggs
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __FormatNumber__
#define __FormatNumber__

#include "CrossPlatformTypes.h"

// Major format number.

#define kK2MajorFormatNumber				RezLong(0)
#define kSherpaMajorFormatNumber			RezLong(1)
#define kHotakaMajorFormatNumber			RezLong(2)
#define kKeystoneMajorFormatNumber			RezLong(3)
#define kAnnaMajorFormatNumber				RezLong(4)
#define kDragontailMajorFormatNumber		RezLong(5)
#define kFiredrakeMajorFormatNumber		RezLong(6)
#define kCobaltMajorFormatNumber			RezLong(7)
#define kBasilMajorFormatNumber			RezLong(8)

#define kCurrentMajorFormatNumber			kBasilMajorFormatNumber


// The final K2 minor format version.
#define kLastK2MinorVersionNumber			RezLong(307)


// Initial minor format numbers for each release
#define kHotakaInitialMinorFormatNumber		RezLong(1)
#define kAnnaInitialMinorFormatNumber		RezLong(1)
#define kDragontailInitialMinorFormatNumber	RezLong(1)
#define kFiredrakeInitialMinorFormatNumber	RezLong(1)
#define kCobaltInitialMinorFormatNumber	RezLong(1)
#define kBasilInitialMinorFormatNumber	RezLong(1)

#endif  // __FormatNumber__
