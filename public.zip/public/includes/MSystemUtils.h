//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MSystemUtils.h $
//  
//  Owner: ?
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MSystemUtils__
#define __MSystemUtils__

#include "MSysType.h"
#include "ISession.h"
#include "WorkspaceID.h"

#define MTOOLBOX
#define QUICKDRAW
#define QUARTZ
#define HITOOLBOX

inline bool _CheckResultFunc(char* caller, intptr_t result, intptr_t okResult, char* codeString, char* fileStr, int32 lineNo)
{
#pragma unused (caller, codeString, fileStr, lineNo)
	ASSERT_MSG(result == okResult, FORMAT_ARGS("%s: %s returned error: %p, called from file: %s at line %d \n", caller, codeString, result, fileStr, lineNo));
	return result == okResult;
}

#define MAC_CHECKERROR(err, routinename) ASSERT_MSG(err == noErr, FORMAT_ARGS("%s returned error: %d\n", #routinename, err))
//#define MAC_CHECKRESULT(code) {OSStatus err = code; ASSERT_MSG(err == noErr, FORMAT_ARGS("%s returned error: %d\n", #code, err));}
#define MAC_CHECKRESULT(code) _CheckResultFunc("MAC_CHECKRESULT", (int32) code, (int32) noErr, #code,__FILE__,__LINE__)

#ifdef ON_MAC_USE_HIVIEW_COORDS

	// The following macros allow use as l-values
	#define	SysPointH( point ) (point).x
	#define	SysPointV( point ) (point).y

	inline SysCoord SysRectLeft(const SysRect& sysRect)
		{ return sysRect.origin.x; }
	inline SysCoord SysRectTop(const SysRect& sysRect)
		{ return sysRect.origin.y; }
	inline SysCoord SysRectRight(const SysRect& sysRect)
		{ return (sysRect.origin.x + sysRect.size.width); }
	inline SysCoord SysRectBottom(const SysRect& sysRect)
		{ return (sysRect.origin.y + sysRect.size.height); }
	inline SysCoord SysRectWidth(const SysRect& sysRect)
		{ return sysRect.size.width; }
	inline SysCoord SysRectHeight(const SysRect& sysRect )
		{ return sysRect.size.height; }
	inline SysCoord SysRectCenterH(const SysRect& sysRect)
		{ return int32(sysRect.origin.x + sysRect.size.width/2.); }		
	inline SysCoord SysRectCenterV(const SysRect& sysRect )
		{ return int32(sysRect.origin.y + sysRect.size.height/2.); }
 		
	// These should not be inlined, since, the new coordinate(s) often contains some combination of existing coordinates.
	//	Also note that thes functions are design for compatibility with rectangles that based on (top,left,bottom,right)
	//	Thus SetSysRectLeft changes both origin.x and size.width of the underlying HIRect...(Beware)
#ifdef PUBLIC_BUILD
#pragma export on
#endif
	PUBLIC_DECL void SetSysRectLeft(SysRect& sysRect, SysCoord left);
	PUBLIC_DECL void SetSysRectTop(SysRect& sysRect, SysCoord top);
	PUBLIC_DECL void SetSysRectRight(SysRect& sysRect, SysCoord right);
	PUBLIC_DECL void SetSysRectBottom(SysRect& sysRect, SysCoord bottom);
	PUBLIC_DECL void SetSysRectWidth(SysRect& sysRect, SysCoord width);
	PUBLIC_DECL void SetSysRectHeight(SysRect& sysRect, SysCoord height);
	PUBLIC_DECL void SetSysRect(SysRect& rect, SysCoord left, SysCoord top, SysCoord right, SysCoord bottom);
	PUBLIC_DECL void SetSysRectLTRB(SysRect& rect, SysCoord left, SysCoord top, SysCoord right, SysCoord bottom);
	PUBLIC_DECL void SetSysRectLTWH(SysRect& rect, SysCoord left, SysCoord top, SysCoord width, SysCoord height);
#ifdef PUBLIC_BUILD
#pragma export off
#endif

	inline void SetSysPoint(SysPoint& pt, SysCoord x, SysCoord y)
	{
		pt.x = x; pt.y = y;
	}
	
	inline SysPoint HIPointFromQDPoint(const QDPoint& qdPt)
	{
		return SysPoint(MTOOLBOX::CGPointMake(qdPt.h, qdPt.v));
	}

	inline QDPoint QDPointFromHIPoint(const HIPoint& cgPt)
	{
		QDPoint	qdPt;
		
		qdPt.v = (SInt16) cgPt.y;
		qdPt.h = (SInt16) cgPt.x;

		return qdPt;
	}

	inline HIRect HIRectFromQDRect(const QDRect& qdRect)
	{
		return CGRectMake(qdRect.left, qdRect.top, qdRect.right - qdRect.left, qdRect.bottom - qdRect.top);
	}

	inline HIRect HIRectFromInt32Rect(const Int32Rect& intRect)
	{
		return CGRectMake(intRect.left, intRect.top, intRect.right - intRect.left, intRect.bottom - intRect.top);
	}

	inline QDRect QDRectFromHIRect(const HIRect& cgRect)
	{
		QDRect	qdRect;
		
		qdRect.top = (int16) (CGRectGetMinY(cgRect));
		qdRect.left = (int16) (CGRectGetMinX(cgRect));
		qdRect.bottom = (int16) (CGRectGetMaxY(cgRect));
		qdRect.right = (int16) (CGRectGetMaxX(cgRect));

		return qdRect;
	}

	
	#define SysRgnBBOX( rgn ) GetRegionRect(rgn)
	inline SysRect GetRegionRect( ConstSysRgn rgn )
	{
		SysRect aRect;
		MTOOLBOX::HIShapeGetBounds(rgn,&aRect);
		return aRect;
	}
	
	inline bool16 QDPointInQDRect( const QDPoint& p, const QDRect& r )
		{ return MTOOLBOX::PtInRect( p, &r ); }

	inline bool16 SysPointInSysRect( const SysPoint& p, const SysRect& r )
		{ return (MTOOLBOX::CGRectContainsPoint( r, p ) == true); }

	inline bool16 EmptySysRect( const SysRect& r )
		{ return (MTOOLBOX::CGRectIsEmpty( r ) == true); }

	inline bool16 IntersectSysRect(const SysRect& src1, const SysRect& src2, SysRect& dst)
	{	
		dst = MTOOLBOX::CGRectIntersection(src1, src2); 
		if(MTOOLBOX::CGRectIsNull(dst))
			dst = MTOOLBOX::CGRectMake(0,0,0,0);
		
		return (MTOOLBOX::CGRectIsEmpty(dst) != true);
	}

	inline void UnionSysRect(const SysRect& src1, const SysRect& src2, SysRect& dst)
		{ dst = MTOOLBOX::CGRectUnion(src1, src2); }

	inline void InsetSysRect(SysRect& rt, SysCoord deltaX, SysCoord deltaY)
		{ rt = MTOOLBOX::CGRectInset(rt, deltaX, deltaY); }

	inline void OffsetSysRect(SysRect& rt, SysCoord deltaX, SysCoord deltaY)
		{ rt = MTOOLBOX::CGRectOffset(rt, deltaX, deltaY); }

	inline void SysRectMakeZeroOrigin(SysRect& rt)
		{ rt = MTOOLBOX::CGRectOffset(rt, -rt.origin.x, -rt.origin.y); }


//===    SysWireframe     ========================

	inline SysRect GetRegionRect( SysWireframe rgn )
	{
		QDRect rect;
		MTOOLBOX::GetRegionBounds(rgn,&rect);
		return rect;
	}
	inline SysWireframe CreateSysWireframe()
		{ return MTOOLBOX::NewRgn(); }

	inline SysWireframe CreateRectSysWireframe (SysRect sysRect)
	{
		SysWireframe newRgn = MTOOLBOX::NewRgn();
		QDRect qdRect = sysRect;
		MTOOLBOX::RectRgn (newRgn, &qdRect);
		return newRgn;
	}

	inline void DeleteSysWireframe(SysWireframe sysRgn)
		{ MTOOLBOX::DisposeRgn (sysRgn); }
	
	inline SysWireframe CopySysWireframe(SysWireframe sysRgn)
	{ 
		SysWireframe copy = ::NewRgn();
	  	MTOOLBOX::CopyRgn(sysRgn, copy); 
	  	return copy; 
	}
	
	inline void CopySysWireframe(SysWireframe srcRgn, SysWireframe dstRgn)
	 { MTOOLBOX::CopyRgn(srcRgn, dstRgn); }

	inline void OffsetSysWireframe(SysWireframe rgn, int32 deltaX, int32 deltaY)
		{ MTOOLBOX::OffsetRgn (rgn, deltaX, deltaY); }

	inline void InsetSysWireframe(SysWireframe rgn, int32 deltaX, int32 deltaY)
		{ MTOOLBOX::InsetRgn (rgn, deltaX, deltaY); }

	inline void UnionSysWireframe(SysWireframe srcRgn1, SysWireframe srcRgn2, SysWireframe destRgn)
		{ MTOOLBOX::UnionRgn(srcRgn1, srcRgn2, destRgn); }
		
	inline void DiffSysWireframe(SysWireframe srcRgn, SysWireframe removeRgn, SysWireframe destRgn)
		{ MTOOLBOX::DiffRgn(srcRgn, removeRgn, destRgn); }
		
	inline void IntersectSysWireframe(SysWireframe srcRgn1, SysWireframe srcRgn2, SysWireframe destRgn)
		{ MTOOLBOX::SectRgn (srcRgn1, srcRgn2, destRgn); }
		
	inline void XorSysWireframe(SysWireframe srcRgn1, SysWireframe srcRgn2, SysWireframe destRgn)
		{ MTOOLBOX::XorRgn (srcRgn1, srcRgn2, destRgn); }

//===    SysRgn     ========================

	inline SysRgn CreateSysRgn()
		{ return MTOOLBOX::HIShapeCreateMutable(); }

	inline void DeleteSysRgn(ConstSysRgn sysRgn)
		{ MTOOLBOX::CFRelease (sysRgn); }
		
	inline SysRgn CopySysRgn(ConstSysRgn sysRgn)
	{ 
	  	return MTOOLBOX::HIShapeCreateMutableCopy(sysRgn); 
	}
	
#ifdef PUBLIC_BUILD
#pragma export on
#endif
	PUBLIC_DECL void CopySysRgn(ConstSysRgn srcRgn, SysRgn dstRgn);
#ifdef PUBLIC_BUILD
#pragma export off
#endif

	inline SysRgn CreateRectSysRgn (const SysRect& sysRect)
	{
		HIShapeRef hiShape = MTOOLBOX::HIShapeCreateWithRect(&sysRect);
		SysRgn result = ::CopySysRgn(hiShape);
		MTOOLBOX::CFRelease(hiShape);
		return result;
	}

	inline QDRgn NewQDRgnFromSysRgn( ConstSysRgn rgn )
	{
		if (rgn == nil)
			return nil;
			
		QDRgn qdRgn = MTOOLBOX::NewRgn();
		MTOOLBOX::HIShapeGetAsQDRgn(rgn, qdRgn);
		return qdRgn;
	}

	inline SysRgn NewSysRgnFromQDRgn( QDRgn qdRgn )
	{ 
		if (qdRgn == nil)
			return nil;
			
		HIShapeRef hiShape = MTOOLBOX::HIShapeCreateWithQDRgn(qdRgn);
		SysRgn result = ::CopySysRgn(hiShape);
		MTOOLBOX::CFRelease(hiShape);
		return result;
	}

	inline bool16 QDPointInQDRgn( const QDPoint& qdPt, QDRgn qdRgn )
	{ 
		if(qdRgn)
			return MTOOLBOX::PtInRgn(qdPt, qdRgn); 
		else
			return kFalse;
	}

	inline bool16 QDRectInQDRgn(QDRgn qdRgn, const QDRect *qdRect)
	{
		return MTOOLBOX::RectInRgn(qdRect,qdRgn); 
	}

	inline bool16 SysPointInSysRgn( const SysPoint& p, ConstSysRgn rgn)
	{ 
		if(rgn)
			return MTOOLBOX::HIShapeContainsPoint(rgn, &p);
		else
			return kFalse;
	}

	inline bool16 SysRectIntersectsSysRgn(ConstSysRgn rgn, const SysRect *rect)
	{
		if(rgn)
		{
		#ifdef TARGET_MAC_OS_X_VERSION_10_4_AND_LATER
			return MTOOLBOX::HIShapeIntersectsRect(rgn, rect);
		#else
			QDRect qdRect = (*rect);
			QDRgn qdRgn = MTOOLBOX::NewRgn();
			MTOOLBOX::HIShapeGetAsQDRgn(rgn, qdRgn);
			bool16 result = QDRectInQDRgn(qdRgn, &qdRect);
			MTOOLBOX::DisposeRgn(qdRgn);
			return result;
		#endif
		}
		else
			return kFalse;
	}
	#define RectInSysRgn(rgn, rect)		SysRectIntersectsSysRgn(rgn, rect)

	inline bool16 EqualSysRgn(ConstSysRgn rgn1, ConstSysRgn rgn2)
	{
		QDRgn qdRgn1 = NewQDRgnFromSysRgn(rgn1);
		QDRgn qdRgn2 = NewQDRgnFromSysRgn(rgn2);
		bool16 result = MTOOLBOX::EqualRgn(qdRgn1, qdRgn2);
		MTOOLBOX::DisposeRgn(qdRgn1);
		MTOOLBOX::DisposeRgn(qdRgn2);
		return result;
		
		//MTOOLBOX::HIShapeSetEmpty(dstRgn);
	  	//HIShapeRef diffShape = MTOOLBOX::HIShapeCreateDifference(rgn1, rgn2);
	  	//bool16 result = MTOOLBOX::HIShapeIsEmpty(diffShape);
	  	//MTOOLBOX::CFRelease(diffShape);  	 
	}

#ifdef PUBLIC_BUILD
#pragma export on
#endif
	PUBLIC_DECL void UnionSysRgn(ConstSysRgn srcRgn1, ConstSysRgn srcRgn2, SysRgn destRgn);
#ifdef PUBLIC_BUILD
#pragma export off
#endif
		
	inline void DiffSysRgn(ConstSysRgn srcRgn, ConstSysRgn removeRgn, SysRgn destRgn)
		{ MTOOLBOX::HIShapeDifference(srcRgn, removeRgn, destRgn); }
		
	inline void IntersectSysRgn(ConstSysRgn srcRgn1, ConstSysRgn srcRgn2, SysRgn destRgn)
		{ MTOOLBOX::HIShapeIntersect (srcRgn1, srcRgn2, destRgn); }
		
	inline bool16 EmptySysRgn(ConstSysRgn theRgn)
		{ return (MTOOLBOX::HIShapeIsEmpty(theRgn) == true); }

	inline void XorSysRgn(ConstSysRgn srcRgn1, ConstSysRgn srcRgn2, SysRgn destRgn)
	{ 
		// HIShape does not support XOR - to have to do this in using QD regions
		//	There are only 5 callers of XorSysRgn in the Firedrake codebase.
		// *** In Leopard (10.5) we can use HIShapeCreateXor or HIShapeXor
		QDRgn srcQDRgn1 = MTOOLBOX::NewRgn();
		QDRgn srcQDRgn2 = MTOOLBOX::NewRgn();
		
		MTOOLBOX::HIShapeGetAsQDRgn(srcRgn1, srcQDRgn1);
		MTOOLBOX::HIShapeGetAsQDRgn(srcRgn2, srcQDRgn2);
		
		::XorRgn (srcQDRgn1, srcQDRgn2, srcQDRgn2);
		HIShapeRef destShape = MTOOLBOX::HIShapeCreateWithQDRgn(srcQDRgn2);
		
		MTOOLBOX::DisposeRgn(srcQDRgn1);
		MTOOLBOX::DisposeRgn(srcQDRgn2);
		
		::CopySysRgn(destShape, destRgn);
	}
		
	inline void OffsetSysRgn(SysRgn rgn, SysCoord deltaX, SysCoord deltaY)
		{ MTOOLBOX::HIShapeOffset (rgn, deltaX, deltaY); }
		
	inline SysPoint GetMousePosition()
	{
		// ----- Returns mouse position in screen/global coordinates 
		QDPoint pt;
		GetGlobalMouse(&pt);
		return SysPoint(pt);
	}

	inline void InvertSysRgn(SysPort /*port*/, ConstSysRgn theRgn)
	{
		QDRgn qdRgn = MTOOLBOX::NewRgn();
		MTOOLBOX::HIShapeGetAsQDRgn(theRgn, qdRgn);
		MTOOLBOX::InvertRgn(qdRgn);  // YIKES, A QUICKDRAW CALL!
		MTOOLBOX::DisposeRgn(qdRgn);
	}

	inline SysRect operator-(const SysRect& rt1, const SysRect& rt2)
	{
		SysRect result;
		
		result.origin.x = rt1.origin.x - rt2.origin.x;
		result.origin.y = rt1.origin.y - rt2.origin.y;
		result.size.width = rt1.size.width - rt2.size.width;
		result.size.height = rt1.size.height - rt2.size.height;
		
		return result;
	}

	inline SysRect operator+(const SysRect& rt1, const SysRect& rt2)
	{
		SysRect result;
		
		result.origin.x = rt1.origin.x + rt2.origin.x;
		result.origin.y = rt1.origin.y + rt2.origin.y;
		result.size.width = rt1.size.width + rt2.size.width;
		result.size.height = rt1.size.height + rt2.size.height;
		
		return result;
	}

#else

#define	SysPointH( point ) (point).h
#define	SysPointV( point ) (point).v
#define SysRgnBBOX( rgn ) GetRegionRect(rgn)

	inline SysCoord SysRectLeft(const SysRect& sysRect)
		{ return sysRect.left; }
	inline SysCoord SysRectTop(const SysRect& sysRect)
		{ return sysRect.top; }
	inline SysCoord SysRectRight(const SysRect& sysRect)
		{ return sysRect.right; }
	inline SysCoord SysRectBottom(const SysRect& sysRect)
		{ return sysRect.bottom; }
	inline SysCoord SysRectWidth(const SysRect& sysRect)
		{ return sysRect.right - sysRect.left; }		
	inline SysCoord SysRectHeight(const SysRect& sysRect )
		{ return sysRect.bottom - sysRect.top; }
	inline SysCoord SysRectCenterH(const SysRect& sysRect)
		{ return (sysRect.right + sysRect.left)/2; }		
	inline SysCoord SysRectCenterV(const SysRect& sysRect )
		{ return (sysRect.bottom + sysRect.top)/2; }

	inline void SetSysRectLeft(SysRect& sysRect, SysCoord left)
		{ sysRect.left = left; }
	inline void SetSysRectTop(SysRect& sysRect, SysCoord top)
		{ sysRect.top = top; } 		
	inline void SetSysRectRight(SysRect& sysRect, SysCoord right)
		{ sysRect.right = right; } 		
	inline void SetSysRectBottom(SysRect& sysRect, SysCoord bottom)
		{ sysRect.bottom = bottom; }
	PUBLIC_DECL void  SetSysRectWidth(SysRect& sysRect, SysCoord width);
	PUBLIC_DECL void  SetSysRectHeight(SysRect& sysRect, SysCoord height);
	inline void SetSysRect(SysRect& rt, SysCoord left, SysCoord top, SysCoord right, SysCoord bottom)
		{ MTOOLBOX::SetRect(&rt, left, top, right, bottom); }
	PUBLIC_DECL void SetSysRectLTRB(SysRect& rect, SysCoord left, SysCoord top, SysCoord right, SysCoord bottom);
	PUBLIC_DECL void SetSysRectLTWH(SysRect& rect, SysCoord left, SysCoord top, SysCoord width, SysCoord height);

 		
	inline void SetSysPoint(SysPoint& pt, SysCoord x, SysCoord y)
	{
		pt.h = x; pt.v = y;
	}
	// 
	// just a better duplicate of SysRgnBBOX
	//
	inline SysRect GetRegionRect( RgnHandle rgn )
	{
		SysRect rect;
			MTOOLBOX::GetRegionBounds(rgn,&rect);
		return rect;
	}

	inline bool16 SysPointInSysRect( const SysPoint& p, const SysRect& r )
			{ return MTOOLBOX::PtInRect( p, &r ); }

		inline bool16 EmptySysRect( const SysRect& r )
			{ return MTOOLBOX::EmptyRect( &r ); }

	inline bool16 IntersectSysRect(const SysRect& src1, const SysRect& src2, SysRect& dst)
			{ return MTOOLBOX::SectRect(&src1, &src2, &dst); }

	inline void UnionSysRect(const SysRect& src1, const SysRect& src2, SysRect& dst)
			{ MTOOLBOX::UnionRect(&src1, &src2, &dst); }

	inline void InsetSysRect(SysRect& rt, int32 deltaX, int32 deltaY)
			{ MTOOLBOX::InsetRect(&rt, deltaX, deltaY); }

	inline void OffsetSysRect(SysRect& rt, int32 deltaX, int32 deltaY)
			{ MTOOLBOX::OffsetRect(&rt, deltaX, deltaY); }


	inline SysPoint GetMousePosition()
	{
		// ----- Returns mouse position in screen/global coordinates 
		SysPoint pt;
		GetGlobalMouse(&pt);
		return pt;
	}

//===    SysRgn     ========================

	inline SysRgn CreateSysRgn()
	{ return MTOOLBOX::NewRgn(); }

	inline SysRgn CreateRectSysRgn (SysRect sysRect)
	{
		SysRgn newRgn = MTOOLBOX::NewRgn();
		MTOOLBOX::RectRgn (newRgn, &sysRect);
		return newRgn;
	}

	inline void DeleteSysRgn(SysRgn sysRgn)
	{ MTOOLBOX::DisposeRgn (sysRgn); }
	
	inline SysRgn CopySysRgn(SysRgn sysRgn)
	{ 
		SysRgn copy = MTOOLBOX::NewRgn();
	  	MTOOLBOX::CopyRgn(sysRgn, copy); 
	  	return copy; 
	}
	
	inline void CopySysRgn(SysRgn srcRgn, SysRgn dstRgn)
	{ 
	  	MTOOLBOX::CopyRgn(srcRgn, dstRgn); 
	}

	inline QDRgn NewQDRgnFromSysRgn( ConstSysRgn rgn )
	{ 
		if (rgn == nil)
			return nil;
			
  		return CopySysRgn(rgn);
	}

	inline SysRgn NewSysRgnFromQDRgn( QDRgn qdRgn )
	{ 
		if (qdRgn == nil)
			return nil;
			
  		return CopySysRgn(qdRgn);
	}
	
	inline bool16 SysPointInSysRgn( const SysPoint& p, SysRgn rgn )
	{ 
		// we used to just call PtInRgn, but that crashes on 10.1 if rgn is NULL....
		if(rgn)
			return ::PtInRgn(p, rgn); 
		else
			return kFalse;
	}

inline bool16 RectInSysRgn(SysRgn rgn, const SysRect *theRect)
	{ return MTOOLBOX::RectInRgn(theRect,rgn); }

inline bool16 EqualSysRgn(SysRgn rgn1, SysRgn rgn2)
	{ return MTOOLBOX::EmptyRgn(rgn1, rgn2); }
	
inline void UnionSysRgn(SysRgn srcRgn1, SysRgn srcRgn2, SysRgn destRgn)
	{ MTOOLBOX::UnionRgn(srcRgn1, srcRgn2, destRgn); }
	
inline void DiffSysRgn(SysRgn srcRgn, SysRgn removeRgn, SysRgn destRgn)
	{ MTOOLBOX::DiffRgn(srcRgn, removeRgn, destRgn); }
	
inline void IntersectSysRgn(SysRgn srcRgn1, SysRgn srcRgn2, SysRgn destRgn)
	{ MTOOLBOX::SectRgn (srcRgn1, srcRgn2, destRgn); }
	
inline bool16 EmptySysRgn(SysRgn theRgn)
	{ return MTOOLBOX::EmptyRgn(theRgn); }

inline void XorSysRgn(SysRgn srcRgn1, SysRgn srcRgn2, SysRgn destRgn)
	{ MTOOLBOX::XorRgn (srcRgn1, srcRgn2, destRgn); }
	
inline void OffsetSysRgn(SysRgn rgn, int32 deltaX, int32 deltaY)
	{ MTOOLBOX::OffsetRgn (rgn, deltaX, deltaY); }
		
inline void InsetSysRgn(SysRgn rgn, int32 deltaX, int32 deltaY)
	{ MTOOLBOX::InsetRgn (rgn, deltaX, deltaY); }

	inline void InvertSysRgn(SysPort /*port*/, const SysRgn theRgn)
	{
		QUICKDRAW::InvertRgn(theRgn);
	}

//===    SysWireframe     ========================

	inline SysWireframe CreateSysWireframe()
		{ return ::CreateSysRgn(); }

	inline SysWireframe CreateRectSysWireframe (SysRect sysRect)
		{ return ::CreateRectSysRgn(sysRect);}

	inline void DeleteSysWireframe(SysWireframe sysRgn)
		{ ::DeleteSysRgn (sysRgn); }
	
	inline SysWireframe CopySysWireframe(SysWireframe sysRgn)
		{ return ::CopySysRgn(sysRgn); }
	
	inline void CopySysWireframe(SysWireframe srcRgn, SysWireframe dstRgn)
		{ ::CopySysRgn(srcRgn, dstRgn); }

	inline void OffsetSysWireframe(SysWireframe rgn, int32 deltaX, int32 deltaY)
		{ ::OffsetSysRgn (rgn, deltaX, deltaY); }

	inline void InsetSysWireframe(SysWireframe rgn, int32 deltaX, int32 deltaY)
		{ ::InsetSysRgn (rgn, deltaX, deltaY); }

	inline void UnionSysWireframe(SysWireframe srcRgn1, SysWireframe srcRgn2, SysWireframe destRgn)
		{ ::UnionSysRgn(srcRgn1, srcRgn2, destRgn); }
		
	inline void DiffSysWireframe(SysWireframe srcRgn, SysWireframe removeRgn, SysWireframe destRgn)
		{ ::DiffSysRgn(srcRgn, removeRgn, destRgn); }
		
	inline void IntersectSysWireframe(SysWireframe srcRgn1, SysWireframe srcRgn2, SysWireframe destRgn)
		{ ::IntersectSysRgn (srcRgn1, srcRgn2, destRgn); }
		
	inline void XorSysWireframe(SysWireframe srcRgn1, SysWireframe srcRgn2, SysWireframe destRgn)
		{ ::XorSysRgn (srcRgn1, srcRgn2, destRgn); }

#endif

PUBLIC_DECL void EraseSysRect(SysPort port, const SysRect *theRect);

PUBLIC_DECL void EraseSysRgn(SysPort port, const SysRgn theRgn);

PUBLIC_DECL QDRgn	GetAvailableWindowPositioningRegion(void);
		
inline void SystemBeep()
	{ ::SysBeep(0); }

PUBLIC_DECL bool16	FindApplicationFile(uint32 creator, FSSpec* fsSpec);
PUBLIC_DECL Boolean	IsFrontProcess(void);


#endif
		// __MSystemUtils__
