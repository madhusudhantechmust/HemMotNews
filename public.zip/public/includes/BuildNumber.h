//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/BuildNumber.h $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2009/08/14 12:23:16 $
//  
//  $Revision: #104 $
//  
//  $Change: 714080 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __BUILDNUMBER__
#define __BUILDNUMBER__

#include "CrossPlatformTypes.h"

//----------------------------------------------------------------------------------------
// Only use spaces as separators (no tabs) in these defines to make automated parsing
// and extraction of the build and change numbers easier.
//----------------------------------------------------------------------------------------
#define kBuildNumber 578
#define kBuildNumberStr "578"
#define kChangeNumberStr "714076"


//----------------------------------------------------------------------------------------
// Create a new file and add it to the end of the list for each new InDesign product version.
//----------------------------------------------------------------------------------------
#include "K2BuildNumber.h"
#include "SherpaBuildNumber.h"
#include "HotakaBuildNumber.h"
#include "AnnaBuildNumber.h"
#include "DragontailBuildNumber.h"
#include "FiredrakeBuildNumber.h"
#include "CobaltBuildNumber.h"
#include "BasilBuildNumber.h"


//----------------------------------------------------------------------------------------
// Now, build the overall definitions from the most recently included file.
//----------------------------------------------------------------------------------------

#define kVersionNumber					kBasilVersionNumber
#define kVersionNumberStr				kBasilVersionNumberStr
#define kVersionNumberForResourceStr	kBasilVersionNumberForResourceStr
#define kUIVersionStr					kBasilUIVersionStr
#define kMajorVersionNumber				kBasilMajorVersionNumber
#define kMinorVersionNumber				kBasilMinorVersionNumber
#define kDotVersionNumber				kBasilDotVersionNumber
#define kMajorVersionNumberForResource	kBasilMajorVersionNumberForResource
#define kMinorVersionNumberForResource	kBasilMinorVersionNumberForResource
#define kDotVersionNumberForResource	kBasilDotVersionNumberForResource
#define kVersionCopyRightStr			kBasilVersionCopyRightStr
#ifdef WINDOWS
#define kShortCopyRightStr				kBasilShortCopyRightStr
#endif
#ifdef DEBUG
#define kAUMComponentVersionStr			kBasilAUMComponentVersionStr kBuildNumberStr "D"
#else
#define kAUMComponentVersionStr			kBasilAUMComponentVersionStr kBuildNumberStr
#endif
#ifdef MACINTOSH
#define kApplicationCFBundleVersionStr	kBasilCFBundleVersionStr
#endif
#define kMajorScriptVersionNumber		kBasilMajorScriptVersionNumber
#define kMinorScriptVersionNumber		kBasilMinorScriptVersionNumber

#ifdef MACINTOSH
	#ifdef PRERELEASE
			#define kDevelopmentStage development
	#else		
			#define kDevelopmentStage release
	#endif
#endif

#endif
