//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/InterfaceColorDefines.h $
//  
//  Owner: brendan o'shea
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Note: This file is included in .fr files, so don't add any C/C++ structures.
//  
//========================================================================================

#pragma once
#ifndef __InterfaceColorDefines__
#define __InterfaceColorDefines__

// NOTE: These enums represent the "standard" set of Adobe Interface 
//       Colors which are common to all Adobe Applications.  See Adobe 
//       UI guidelines for description of this index table.
const int32	  kInvalidInterfaceColor	=	-1;
const int32	  kInterfaceWhite			=	0;	// also known as kADMWhiteColor
const int32	  kInterfaceButtonUpFill	=	1;	// aka kADMButtonUpColor
const int32	  kInterfaceBevelShadow		=	2;	// aka kADMShadowColor	
const int32	  kInterfacePaletteFill		=	3;	// aka kADMBackgroundColor
const int32	  kInterfaceIconFrameDimmed	=	4;		
const int32	  kInterfaceIconFrameActive	=	5;	
const int32	  kInterfaceBevelHighlight	=	6;	
const int32	  kInterfaceButtonDownFill	=	7;	// aka kADMButtonDownColor
const int32	  kInterfaceIconFillSelected =	8;	
const int32	  kInterfaceBorder			=	9;		
const int32	  kInterfaceButtonDarkShadow =	10;	// aka kADMButtonDownShadowColor
const int32	  kInterfaceIconFrameSelected =	11;		
const int32	  kInterfaceBlack			=	12;	// aka kADMBlackColor

// NOTE: Add any custom K2 color enumerations below here:
const int32	  kInterfaceTooltipText		=	13;	// aka kADMToolTipForegroundColor
const int32	  kInterfaceTooltipBackground =	14;	// aka kADMToolTipBackgroundColor
const int32	  kInterfaceDisabledGray	=	15;	
const int32	  kInterfaceHighLight		=	16;	// aka kADMHiliteColor
const int32	  kInterfaceHighLightText	=	17;	// aka kADMHiliteTextColor
const int32   kInterfaceCntlMgrTabsPane	=	18;	
const int32	  kInterfaceAboutBoxGrayText=	19;	
const int32	  kInterfaceMenuHighLight	=	20;	// aka kADMMenuHiliteColor??
const int32   kInterfaceBlueProgressBack=   21;
#endif