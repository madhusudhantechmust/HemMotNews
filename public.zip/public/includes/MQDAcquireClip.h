//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/MQDAcquireClip.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __MQDAcquireClip__
#define __MQDAcquireClip__

#ifdef WIDGET_BUILD
#pragma export on
#endif

class IControlView;
class IViewPort;

/**	MQDAcquireClip - An object that sets up the clip for a view or viewport. To be used when you want to draw using QuickDraw. This is usually
 	not used standalone but as a template parameter to AGMGraphicsContextWith.
 	@see SysGraphicsContext.h
*/
class WIDGET_DECL MQDAcquireClip
{
	public:
		MQDAcquireClip(IViewPort* vp, IControlView* view, SysRgn clipRgn = nil);
		MQDAcquireClip(IViewPort* vp, SysRgn clipRgn);
		~MQDAcquireClip();
		
		SysRgn			GetClip() const;
		SysRgn			GetOriginAdjustedClip() const;
		
		SysPort			GetSysPort() const;
		
		void			SetupPlatformClip();
		void			TearDownPlatformClip();

	private:
		void			SetPlatformClipRgnFromView(IControlView* view, SysRgn clipRgn);
		void			SetPlatformClipRgn(SysRgn clipRgn);
		void			OffsetClip(SysRgn clipRgn, int16 direction);

		void			CommonInit();

	private:
		IViewPort* fVP;
		IControlView* fView;
		SysRgn fClipRgn;
		SysRgn fAdjustedClipRgn;
		QDRgn fPrevClipRgn;
		bool16 fClipHasBeenApplied;
		bool16 fClipRgnWasCreated;	// i.e. does this object own the fClipRgn?
};

#pragma export off

#endif
