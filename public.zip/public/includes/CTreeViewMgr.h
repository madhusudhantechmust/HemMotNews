//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/CTreeViewMgr.h $
//  
//  Owner: Matt Joss
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __CTreeViewMgr__
#define __CTreeViewMgr__

#include "ITreeViewMgr.h"
#include "HelperInterface.h"
#include "K2Vector.h"
#include "KeyValuePair.h"
#include "PMPoint.h"
#include "NodeID.h"

//----------------------------------------------------------------------------------------
// Forward Declarations
//----------------------------------------------------------------------------------------
class IPanelControlData;
class ITreeViewHierarchyAdapter;
class ITreeViewController;
class TreeNodeTraverser;
class TreeNodeHelper;
class AcquireDelayedBusyCursor;

//----------------------------------------------------------------------------------------
// Class Info
//----------------------------------------------------------------------------------------
#pragma export on

class WIDGET_DECL CTreeViewMgr : public ITreeViewMgr
{
public:
	CTreeViewMgr(IPMUnknown *boss);
	~CTreeViewMgr();
	
	virtual void		ChangeRoot( bool16 widgetHeightIsConstant );		
#ifdef DEBUG
	virtual void		ChangeRoot( bool16 widgetHeightIsConstant, bool16 /*testAdapterAndNodeID*/ ) { fTestTree = kTrue; ChangeRoot(widgetHeightIsConstant); }	
#endif

	virtual void		NodeAdded( const NodeID& nodeAdded );		
	virtual void		NodesAdded( const NodeIDList&	nodesAdded );		
	virtual void		BeforeNodeDeleted( const NodeID& nodeDeleted );		
	virtual void		BeforeNodesDeleted( NodeIDList& nodesDeleted );		
	virtual void		NodeMoved( const NodeID& nodeMoved, const NodeID& oldParent  );		
	virtual void		NodeChanged( const NodeID& nodeChanged, bool16 childrenChangedAlso, int32 message = 0 );		
	virtual void		ScrollToNode( const NodeID& nodeDeleted, ScrollWhere	whereToScroll );		

	virtual bool16		IsNodeExpanded( const NodeID& nodeInQuestion ) const;	
	virtual bool16		IsNodeExpanded(IControlView* widget) const;	
	virtual void		ExpandNode( const NodeID& nodeToExpand, bool16 expandAllDescendants = kFalse );	
	virtual void		CollapseNode( const NodeID& nodeToCollapse, bool16 collapseAllDescendants = kFalse );	

	virtual void		HandleScroll( int32 amount, bool16 scrollVertical );
	virtual	void		HandleResize();

	virtual	void		ScrollUp();
	virtual	void		ScrollDown();

	virtual IControlView* QueryWidgetFromNode( const NodeID& node ) const;	
	virtual	NodeID_rv	Search( const PMString& partialNodeName ) const;
	virtual	NodeID_rv	Search( const NodeID& nodeToSearch ) const;

	virtual	void		Purge(int32 level);

	virtual	void		ClearTree(bool16 clearExpandedNodeList);
	virtual	void		ReadWrite(IPMStream *s, ImplementationID prop);

	enum { kAbove = 1, kBelow = -1 };
	static	int32 		AboveOrBelow(ITreeViewHierarchyAdapter* adapter, const NodeID& referenceNode, const NodeID& nodeInQuestion);
	static void			PurgeMemory(int32 level, void *refPtr);
	virtual	void			RefreshSubTree(const NodeID& subTreeRoot, bool16 includeEntireHier);

	virtual	void			ArrangeWidgets();
	virtual	PMRect 			GetViewableArea();

	void AllowPurge()
		{ ++fAllowPurge; }
	void DisallowPurge()
		{ --fAllowPurge; }
	bool IsPurgeAllowed() const
		{ return (fAllowPurge == 0); }

protected:
	void					ExpandNodeRecurse( const NodeID& nodeToExpand, bool16 expandAllDescendants = kFalse);	
	void					CollapseNodeRecurse( const NodeID& nodeToCollapse, bool16 collapseAllDescendants = kFalse );
	void					PlaceWidgets( const NodeID& anchorNode, const PMReal& anchorNodePosition, const NodeIDList* skipNodes = nil);
								// framePositionLookup sorted
	void		 			HandleNodePlacement( const NodeID& node, K2Vector<KeyValuePair<NodeID, PMReal> >*	framePositionLookup, const PMReal& location  );
	void 					DeselectNode(  const NodeID& nodeToDeselect, ITreeViewController* controller, const ITreeViewHierarchyAdapter* adapter);
	PMReal 					GetNodePosition( const NodeID& node );
	void					ScrollHorizontal( int32 amount );
	void					ScrollVertical( int32 amount );
	void	 				AdjustTreeScrollerSize( PMPoint scrollerSize );
	PMReal 					AdjustScrollIncrements( WidgetID whichScrollBar, const PMReal& scrollerTop, const PMReal& scrollerBottom, const PMReal& viewSize );
	void					AdjustScrollValue(bool16 vertical = kTrue);
	PMReal					AdjustScrollerPosition( );
	PMPoint 				RecursiveGetSize( const NodeID& node, bool16 includeThisNodeInSize = kTrue, const NodeIDList* ignoreTheseNodes = nil);
	IControlView*			QueryWidgetForNode(const NodeID& node);
	IControlView*			QueryCachedWidget( WidgetID typeOfWidget );
	void 					AdjustHorizSize( IControlView* widget );
	void					DisposeWidget(IControlView*);
	void 					DeleteWidget(IControlView*	widget);
	NodeID_rv				GetNodeIDFromInterface(IControlView*	widget) const;
	bool16 					AncestorsAreExpanded(const NodeID& node);
			bool16			IsAncestor(const NodeID& possibleAncestor, const NodeID& possibleDescendant) const;
	typedef enum { kNodeAdded, kNodeChanged, kNodeDeleted } ChangeType;
	PMReal					GetNewScrollerWidth( const PMReal& sizeOfChangingNode, const NodeIDList* changingNodes, ChangeType typeOfChange );
	void					ExpandToShowNode( const NodeID& scrollToNode );
	void					MoveScroller( const PMPoint& moveTo );
#ifdef DEBUG
	void  					TestTree( const NodeID& node);
	void					CheckNode(const NodeID& node, const PMString& calledFrom, int32 i = -1) const;
#else
	inline void				CheckNode(const NodeID& /*node*/, const PMString& /*calledFrom*/, int32 /*i */= -1) const {}
#endif			

	IControlView*			fTreeScrollerView;

private:
	K2Vector<KeyValuePair<NodeID, int32> >	fNodeToWidgetPositionLookup;	// sorted
	NodeIDList	fExpansionLookup;	// sorted
	bool16							fDisplayRootNode;	
	NodeID					fRootNode;
	bool16					fScrollForceRedraw;
	int32					fVThumbScrollIncrement;
	bool16					fRootIsValid;  //We use this so that flag that calls after ClearTree() will fail until ChangeRoot is called,
											//specifically, we want to ignore resize calls.  We can't set the root to invalid because that
											// would cause ChangeRoot() calls with the same root to lose the expansion info
	mutable K2Vector< KeyValuePair<PMString, NodeID> >	fTreeNodeNameList;
	int32					fAllowPurge;	// 0 if purging currently enabled for this object
	DECLARE_HELPER_METHODS()

#ifdef DEBUG
	bool16							fTestTree;
#endif

	//Widget Cache
	typedef K2Vector<IControlView*> WidgetList;
	K2Vector<KeyValuePair<WidgetID, WidgetList> >	fWidgetCache;		// sorted
		
	friend	class TreeNodeTraverser;
	friend	class TreeNodeHelper;
};

#pragma export off

#endif
