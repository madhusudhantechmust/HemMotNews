//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/CursorDefs.h $
//  
//  Owner: Dave Burnard
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __CURSORDEFS__
#define __CURSORDEFS__

// NOTE: CursorIDs should all be less than kSnapToCrsrOffset (5000)
//		 Any snap versions of the cursors are then the same ID + 5000

// Offset from regular CursorID to snapped version (if it exists).
const int32 kSnapToCrsrOffset = 5000;

const CursorID kCrsrNone_SetByPlatform = 	-3;	// Used on Win for regions where Win sets the cursor
const CursorID kCrsrNone 		= 	-2;
const CursorID kCrsrTool 		= 	-1;
const CursorID kCrsrPointer 	= 	0;
const CursorID kCrsrWatch	 	= 	4;
const CursorID kCrsrAnimatedWait = 	5;
const CursorID kCrsrGrabberHand	= 	270;
const CursorID kCrsrSelectionArrow	= 	271;
const CursorID kCrsrPlaceText	= 	272;
const CursorID kCrsrDragCopy	=	275;
const CursorID kCrsrDrag		=	276;
const CursorID kNorthSouthPointer =	 277;
const CursorID kEastWestPointer =	278;
const CursorID kNESWPointer 	=	279;
const CursorID kNWSEPointer 	=	280;
const CursorID kCrsrPlaceEPS = 282;
const CursorID kCrsrPlaceGraphic = 	283;
const CursorID kCrsrAutoText	= 	285;
const CursorID kCrsrSemiAutoText = 286;
const CursorID kCrsrCrosshair 	= 	287;
const CursorID kCrsrIBeam 		= 	288;			// Used by Public
const CursorID kCrsrRotation	= 	290;
const CursorID kCrsrZoomIn		= 	291;
const CursorID kCrsrZoomOut		= 	292;

// Cursors #s 293-296 appear to be used by inlines

const CursorID kCrsrObjectSelect = 297;
const CursorID kCrsrObjectDirectSelect = 298;
const CursorID kCrsrNoZoom		= 	300;
const CursorID kCrsrLocked 		= 301;
const CursorID kCrsrClosedPath = 302;
const CursorID kCrsrDirectSelect = 303;
const CursorID kCrsrGroupSelect = 304;
const CursorID kCrsrConvertDirection = 307;
const CursorID kCrsrRightMouse = 308;
const CursorID kCrsrItemCreation = 309;
const CursorID kCrsrItemTransform = 310;
const CursorID kCrsrAnchorDirectSelect = 311;
const CursorID kCrsrControlDirectSelect = 312;
const CursorID kCrsrSegmentDirectSelect = 313;

const CursorID kCrsrPlaceTextIntoSemiAuto   = 369;
const CursorID kCrsrOpenHand   = 370;
const CursorID kCrsrClosedHand = 371;
const CursorID kCrsrBadDropTarget = 372;
const CursorID kCrsrClosedHandCopy = 373;
const CursorID kCrsrPlaceBadDropTarget = 377;
const CursorID kCrsrPlaceTextInto = 378;
const CursorID kCrsrPlaceImageInto = 379;
const CursorID kCrsrPlaceEPSInto = 380;
const CursorID kCrsrPlaceVerticalText = 381;
const CursorID kCrsrPlaceVerticalTextInto = 382;
const CursorID kCrsrPlaceVerticalTextAuto = 383;
const CursorID kCrsrLinkFrames = 384;
const CursorID kCrsrUnlinkFrames = 385;
const CursorID kCrsrSplitter = 386;
const CursorID kCrsrPlaceTextIntoAuto = 387;
const CursorID kCrsrPlaceVerticalTextIntoAuto = 388;
const CursorID kCursorLock = 389;
const CursorID kCursorADBE3DButton = 390;

const CursorID kCrsrTOPStartBracket		= 391;
const CursorID kCrsrTOPEndBracket		= 392;
const CursorID kCrsrTOPCenterBracket	= 393;

const CursorID kCrsrSemiAutoVerticalText = 394;
const CursorID kCrsrPlaceVerticalTextIntoSemiAuto = 395;
const CursorID kCrsrVerticalSplitter = 396;

const CursorID kCrsrPlaceTextAutoStop = 397;
const CursorID kCrsrPlaceTextIntoAutoStop = 398;
const CursorID kCrsrPlaceTextAutoStopVertical = 399;
const CursorID kCrsrPlaceTextIntoAutoStopVertical = 400;

const CursorID kAnimCrsrWatch_First = 401;
const CursorID kAnimCrsrWatch_1 = 401;
const CursorID kAnimCrsrWatch_2 = 402;
const CursorID kAnimCrsrWatch_3 = 403;
const CursorID kAnimCrsrWatch_4 = 404;
const CursorID kAnimCrsrWatch_5 = 405;
const CursorID kAnimCrsrWatch_6 = 406;
const CursorID kAnimCrsrWatch_7 = 407;
const CursorID kAnimCrsrWatch_8 = 408;
const CursorID kAnimCrsrWatch_Last = 408;

const CursorID kCrsrDragText			= 410;
const CursorID kCrsrDragCopyText		= 411;
const CursorID kCrsrDragToNewFrame		= 412;
const CursorID kCrsrDragCopyToNewFrame	= 413;
const CursorID kCrsrDragTextLocked		= 414;
const CursorID kCrsrDragTextBadDropTarget = kCrsrPlaceBadDropTarget;	// Reuse this cursor

const CursorID kCrsrDragApplyToStroke	= 415;
const CursorID kCrsrDragApplyToFill		= 416;

const CursorID kCrsrPlaceFileInto		= 417;
const CursorID kCrsrPlaceFile			= 418;

const CursorID kCrsrDragUnformattedText					= 419;
const CursorID kCrsrDragCopyUnformattedText				= 420;
const CursorID kCrsrDragUnformattedTextToNewFrame		= 421;
const CursorID kCrsrDragCopyUnformattedTextToNewFrame	= 422;

const CursorID kCrsrPointyHand			= 423;
const CursorID kCrsrPointyHandCopy		= 424;

const CursorID kCrsrCascadePlace = 	425;
const CursorID kCrsrDropLoadGun = 	426;

const CursorID kCrsrPlaceSnippet = 	427;
const CursorID kCrsrPlaceSnippetOrigLoc = 428;
const CursorID kCrsrClosedHandZoomScroll   = 429;

// qME
const CursorID kCrsrAutoMEText = 450;
const CursorID kCrsrPlaceMETextIntoAuto = 451;
const CursorID kCrsrSemiAutoMEText = 452;
const CursorID kCrsrPlaceMETextIntoSemiAuto = 453;
const CursorID kCrsrPlaceMEText = 454;
const CursorID kCrsrPlaceMETextInto = 455;
const CursorID kCrsrPlaceMETextAutoStop = 456;
const CursorID kCrsrPlaceMETextIntoAutoStop = 457;
const CursorID kCrsrLinkMEFrames = 458;
const CursorID kCrsrUnlinkMEFrames = 459;
//end qME

// These CursorIDs match their corresponding cursor but have kSnapToCrsrOffset added.
const CursorID kCrsrPlaceTextSnap			= (kCrsrPlaceText + kSnapToCrsrOffset);
const CursorID kCrsrDragCopySnap			= (kCrsrDragCopy + kSnapToCrsrOffset);
const CursorID kCrsrDragSnap				= (kCrsrDrag + kSnapToCrsrOffset);
const CursorID kNorthSouthPointerSnap		= (kNorthSouthPointer + kSnapToCrsrOffset);
const CursorID kEastWestPointerSnap			= (kEastWestPointer + kSnapToCrsrOffset);
const CursorID kNESWPointerSnap				= (kNESWPointer + kSnapToCrsrOffset);
const CursorID kNWSEPointerSnap				= (kNWSEPointer + kSnapToCrsrOffset);
const CursorID kCrsrPlaceEPSSnap			= (kCrsrPlaceEPS + kSnapToCrsrOffset);
const CursorID kCrsrPlaceGraphicSnap		= (kCrsrPlaceGraphic + kSnapToCrsrOffset);
const CursorID kCrsrAutoTextSnap			= (kCrsrAutoText + kSnapToCrsrOffset);
const CursorID kCrsrSemiAutoTextSnap		= (kCrsrSemiAutoText + kSnapToCrsrOffset);
const CursorID kCrsrCrosshairSnap			= (kCrsrCrosshair + kSnapToCrsrOffset);
const CursorID kCrsrRotationSnap			= (kCrsrRotation + kSnapToCrsrOffset);
const CursorID kCrsrItemCreationSnap		= (kCrsrItemCreation + kSnapToCrsrOffset);
const CursorID kCrsrPlaceVerticalTextSnap	= (kCrsrPlaceVerticalText + kSnapToCrsrOffset);
const CursorID kCrsrPlaceVerticalTextAutoSnap	= (kCrsrPlaceVerticalTextAuto + kSnapToCrsrOffset);
const CursorID kCrsrSemiAutoVerticalTextSnap = (kCrsrSemiAutoVerticalText + kSnapToCrsrOffset);
const CursorID kCrsrPlaceTextAutoStopSnap		= (kCrsrPlaceTextAutoStop + kSnapToCrsrOffset);
const CursorID kCrsrPlaceTextIntoAutoStopSnap	= (kCrsrPlaceTextIntoAutoStop + kSnapToCrsrOffset);
const CursorID kCrsrPlaceTextAutoStopVerticalSnap = (kCrsrPlaceTextAutoStopVertical + kSnapToCrsrOffset);
const CursorID kCrsrPlaceTextIntoAutoStopVerticalSnap = (kCrsrPlaceTextIntoAutoStopVertical + kSnapToCrsrOffset);
const CursorID kCrsrPlaceFileSnap = (kCrsrPlaceFile + kSnapToCrsrOffset);
const CursorID kCrsrCascadePlaceSnap		= (kCrsrCascadePlace + kSnapToCrsrOffset);
const CursorID kCrsrDropLoadGunSnap		= (kCrsrDropLoadGun + kSnapToCrsrOffset);
const CursorID kCrsrPlaceSnippetSnap		= (kCrsrPlaceSnippet + kSnapToCrsrOffset);
const CursorID kCrsrPlaceSnippetOrigLocSnap = (kCrsrPlaceSnippetOrigLoc + kSnapToCrsrOffset);

// qME
const CursorID kCrsrAutoMETextSnap	= (kCrsrAutoMEText + kSnapToCrsrOffset);
const CursorID kCrsrSemiAutoMETextSnap	= (kCrsrSemiAutoMEText + kSnapToCrsrOffset);
const CursorID kCrsrPlaceMETextSnap = (kCrsrPlaceMEText + kSnapToCrsrOffset);
const CursorID kCrsrPlaceMETextAutoStopSnap = (kCrsrPlaceMETextAutoStop + kSnapToCrsrOffset);
const CursorID kCrsrPlaceMETextIntoAutoStopSnap = (kCrsrPlaceMETextIntoAutoStop + kSnapToCrsrOffset);
//end qME




#endif		// __Cursordefs__
