//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/AppPrefsListElementTypes.h $
//  
//  Owner: Matt Joss
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  ADOBE CONFIDENTIAL
//  
//========================================================================================

#pragma once
#ifndef __AppPrefsListElementTypes__
#define __AppPrefsListElementTypes__

#include "ScriptingDefs.h"
#include <set>
#include "XPID.h"


/** This is a helper class that keeps a list of all standard element types that we export
*/
class AppPrefsListElementTypes 
{
public:
	/**
		Is the specified type a list element that we export?
	
		@param	elementType the type we are inquiring about
		@return	bool16 kTrue if this elementType is in the list, kFalse if not
	*/
	static bool16 IsTypeInList( ScriptID elementType )
	{
		const std::set<ScriptID>& elementTypes = GetListElementTypes();
		return (elementTypes.find(elementType) != elementTypes.end());
	}

	/**
		returns a list of list element types that are part of the standard export
	*/
	static const std::set<ScriptID>& GetListElementTypes()
	{
		static std::set<ScriptID>	gListElementTypes;
		if (gListElementTypes.empty())
		{
			gListElementTypes.insert(c_Color);
			gListElementTypes.insert(c_CharStyle);
			gListElementTypes.insert(c_ParaStyle);
			gListElementTypes.insert(c_XMLTag);
			gListElementTypes.insert(c_StrokeStyle);
			gListElementTypes.insert(c_DashStrokeStyle);
			gListElementTypes.insert(c_DotStrokeStyle);
			gListElementTypes.insert(c_StripeStrokeStyle);
			gListElementTypes.insert(c_TrapStyle);
			gListElementTypes.insert(c_PDFExportStyle);
			gListElementTypes.insert(c_DocumentStyle);
			gListElementTypes.insert(c_PrintStyle);
			gListElementTypes.insert(c_FlattenerStyle);
			gListElementTypes.insert(c_XMLStyleToTagMap);
			gListElementTypes.insert(c_XMLTagToStyleMap);
			gListElementTypes.insert(c_ObjectStyle);
			gListElementTypes.insert(c_Ink);
			gListElementTypes.insert(c_Swatch);
			gListElementTypes.insert(c_Tint);
			gListElementTypes.insert(c_Gradient);
			gListElementTypes.insert(c_MixedInk);
			gListElementTypes.insert(c_MixedInkGroup);
//			gListElementTypes.insert(c_AGMBlackBox);
			gListElementTypes.insert(c_NamedGrid);
			gListElementTypes.insert(c_KinsokuTable);
			gListElementTypes.insert(c_MojikumiTable);	
			gListElementTypes.insert(c_VendorLanguage);	// add this object so that it will be exported, see bug #1148334.

		}
		
		return gListElementTypes;
	}	
};

#endif //__AppPrefsListElementTypes__
