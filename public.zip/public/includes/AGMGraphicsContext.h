//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/AGMGraphicsContext.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __AGMGraphicsContext__
#define __AGMGraphicsContext__

#include "AGMGraphicsContextWith.h"

/**
 This is a convenience typedef for declaring a platform-specific graphics 
 context to wrap an AGM-based port
 
 This is intended to be used as a stack-based object to set up a view port for 
 drawing. For instance, a typical use is in the Draw method of an IControlView:
 
 <pre>
 void MyExampleControlView::Draw(IViewPort *viewPort, SysRgn updateRgn)
 {
	AGMGraphicsContext gc(viewPort, this, updateRgn);
	IGraphicsPort port(gc.GetViewPort(), UseDefaultIID());
	
	port->gsave();
	...
	port->grestore();
 }
 </pre>
 
 On Windows, this resolves to AGMGraphicsContextWith<WAGMAcquireCoordSys, WAGMAcquireClip> AGMGraphicsContext
 
 @see AGMGraphicsContextWith
 */
#ifdef MACINTOSH
#include "MAGMAcquireClip.h"
#include "MAGMAcquireCoordSys.h"
typedef AGMGraphicsContextWith<MAGMAcquireCoordSys, MAGMAcquireClip> AGMGraphicsContext;
#endif

#ifdef WINDOWS
#include "WAGMAcquireClip.h"
#include "WAGMAcquireCoordSys.h"
typedef AGMGraphicsContextWith<WAGMAcquireCoordSys, WAGMAcquireClip> AGMGraphicsContext;
#endif

#endif
