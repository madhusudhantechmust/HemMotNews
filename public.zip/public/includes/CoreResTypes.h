//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/CoreResTypes.h $
//  
//  Owner: Steve Pellegrin
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __CoreResTypes__
#define __CoreResTypes__

#ifdef __ODFRC__
#ifdef __WINDOWS__
#ifndef WINDOWS
#define WINDOWS 1
#endif
#else
#ifndef MACINTOSH
#define MACINTOSH 1
#endif
#endif
#endif

// ---- Core types used by ODFRC scripts.

#ifdef MACINTOSH

// String for making a carriage return in a string. Useful for alerts.
// e.g. "Here is a string" kLineSeparatorString "that takes up two lines."
// Resource compiler will combine into one string with a carriage return.
#define kLineSeparatorString				"\r"

//#define kOldClassRsrcType 		'OCLS' // use new .fr based kClassRsrcType
//#define kOldAddInClassRsrcType 	'OACL' // use new .fr based kAddInClassRsrcType
#define kInterfaceColorsType	'Colr'
#define kPErrorTableType 		'petb'
#define kUErrorTableType 		'uetb'
#define kRulerRsrcType 			'rulr'
//#define kOldPlugInDependents		'PLG0' // use new .fr based kPlugInDependents
#define kPlugInVersion			'PVER'
//#define kOldCriticalTagsRsrcType	'OCTG'// use new .fr based kCriticalTagsRsrcType
//#define kOldIgnoreTagsRsrcType		'OITG'// use new .fr based kIgnoreTagsRsrcType


// ----- Type ids for new core resources. [amb]

#define kSysControlRsrcType					'CNTL'
#define kViewRsrcType						'VIEW'
#define kPanelListRsrcType					'PLST'
#define kLocaleIndexRsrcType				'LOCR'
#define kStringTableRsrcType				'PMST'
#define kTIPSRsrcType						'TIPS'
#define kIDListRsrcType						'ILST'
#define kIDListPairRsrcType					'ILTP'
#define kToolRsrcType						'TLDF'
#define kMenuRsrcType						'MENR'
#define kActionRsrcType						'ACTD'
#define kActionIDPoolRsrcType				'ACTP'
#define kInterfaceFontTableRsrcType			'UIFT'
#define kICCProfileRsrcType					'ICCP'
#define kCustomDialogRsrcType				'DITL'		
#define kInterfaceEquivalentsRsrcType		'IFEQ' // Interface Equivalents		
#define kFactoryListRsrcType				'FACT'
#define kFeatureSetRsrcType					'FEAT'
#define kADAMRsrcType						'ADAM'
#define kEVERsrcType						'EVE_'

#define kClassRsrcType 						'CLAS'
#define kAddInClassRsrcType 				'ACLS'
#define kCriticalTagsRsrcType				'CTAG'
#define kIgnoreTagsRsrcType					'ITAG'
#define kPlugInDependents					'PLUG'
#define kProductRsrcType					'PROD'

#define kFileTypeTableRsrcType				'FTTB'
#define kApplPubFileTypeRsrcType			'APFT'
#define kClassTableRsrcType 				'CLST'
#define kServiceProviderType				'SERV'
#define kImplementationAliasRsrcType		'IALS'

#define kInterfaceEquivalentsRsrcType		'IFEQ' // Interface Equivalents		
#define kKitListRsrcType					'KLST'
#define kSelectionExtRsrcType				'ISui'

//#ifdef ID_DEPRECATED
#define kScriptElementRsrcType				'SCEI'
//#endif
#define kScriptElementRsrcType2				'SCE2'
#define kAppVersionRsrcType					'GUID'

#define kPNGArtRsrcType						'PNGA' // resource type PNGA, PNG ART! Icons Are not Localized! Regular version.
#define kPNGArtRollOverRsrcType				'PNGR' // resource type PNGR, PNG ART! Icons Are not Localized! Rollover version.
#define kPNGArtDarkRsrcType					'PNGD' // resource type PNGAD, PNG ART! Icons Are not Localized! Used in App Bar. Used in App Bar, Darker version.
#define kPNGArtRollOverDarkRsrcType			'PNGK' // resource type PNGRD, PNG ART! Icons Are not Localized! Used in App Bar. Darker rollover version.

#define kHighLevelUIFuncGroupRsrcType		'HLFG'
#define kHighLevelUIFuncWidgetSetRsrcType	'HLFW'
#define kHighLevelUIFuncMenuSetRsrcType		'HLFM'
#define kHighLevelUIFuncActionSetRsrcType	'HLFA'

#define kTemplateRsrcType					'TMPL'
#define kPackagesRsrcType					'PCKS'

// ----- Type ids for schemas. [shp]

#define kSchemaRsrcType						'SCMA'
#define kSchemaListRsrcType					'SCML'
#define kBossDirectiveRsrcType				'BOSD'
#define kFormatNumberPathRsrcType			'FNPA'
#define kVersionListRsrcType				'VRLS'

#define kIDNameListRsrcType				'IDNL'
#define kExtraPluginInfoType			'IDPL'

#endif

#ifdef WINDOWS

// String for making a carriage return in a string. Useful for alerts.
// e.g. "Here is a string" kLineSeparatorString "that takes up two lines."
// Resource compiler will combine into one string with a carriage return.
#define kLineSeparatorString				"\n"

//#define kOldClassRsrcType 		100
//#define kOldAddInClassRsrcType 101
#define kInterfaceColorsType 103
#define kPErrorTableType	106
#define kUErrorTableType	107
#define kRulerRsrcType 		109
#define kWNDCLASSType	 	112
//#define kOldPlugInDependents	117

//#define kTCLigatureType		118
#define kPlugInVersion		119
//#define kOldCriticalTagsRsrcType	121
//#define kOldIgnoreTagsRsrcType		122


// ----- Type ids for new core resources. [amb]

#define kSysControlRsrcType				500
#define kViewRsrcType					501
#define kPanelListRsrcType				502
#define kLocaleIndexRsrcType			503
#define kStringTableRsrcType			504
#define kIDListRsrcType					505
#define kToolRsrcType					506
#define kMenuRsrcType					507
#define kActionRsrcType					509
#define kActionIDPoolRsrcType			5091
#define kTIPSRsrcType					510
#define kIDListPairRsrcType				511
#define kICCProfileRsrcType				512
#define kCustomDialogRsrcType			513		
#define kInterfaceEquivalentsRsrcType	514	
#define kFeatureSetRsrcType				515

#define kClassRsrcType 					516
#define kAddInClassRsrcType				517
#define kFactoryListRsrcType			518
#define kCriticalTagsRsrcType			519
#define kIgnoreTagsRsrcType				520
#define kPlugInDependents				521
#define kInterfaceFontTableRsrcType		522
#define kProductRsrcType				610

#define kFileTypeTableRsrcType			524
#define kApplPubFileTypeRsrcType		525
#define kServiceProviderType			526
#define kImplementationAliasRsrcType	527

#define kKitListRsrcType				528
#define kClassTableRsrcType 			529
#define kSelectionExtRsrcType			530

#define kADAMRsrcType					531
#define kEVERsrcType					532

//#ifdef ID_DEPRECATED
#define kScriptElementRsrcType			550
//#endif
#define kScriptElementRsrcType2			551
#define kAppVersionRsrcType				552

#define kPNGArtRsrcType					578 // resource PNGA, PNG ART! Icons Are not Localized! Regular version.
#define kPNGArtRollOverRsrcType			579 // resource PNGR, PNG ART! Icons Are not Localized! Rollover version.
#define kPNGArtDarkRsrcType				580 // resource PNGAD, PNG ART! Icons Are not Localized! Used in App Bar. Used in App Bar, Darker version.
#define kPNGArtRollOverDarkRsrcType		581 // resource PNGRD, PNG ART! Icons Are not Localized! Used in App Bar. Darker rollover version.

#define kHighLevelUIFuncGroupRsrcType		590
#define kHighLevelUIFuncWidgetSetRsrcType	591
#define kHighLevelUIFuncMenuSetRsrcType		592
#define kHighLevelUIFuncActionSetRsrcType	593

#define kTemplateRsrcType					594
#define kPackagesRsrcType					595

// ----- Type ids for schemas. [shp]

#define kSchemaRsrcType					600
#define kBossDirectiveRsrcType			601
#define kFormatNumberPathRsrcType		602
#define kVersionListRsrcType			603
#define kSchemaListRsrcType				604

#define kIDNameListRsrcType				605
#define kExtraPluginInfoType			606

//#define kProductRsrcType				610	//defined above

#endif

#endif
