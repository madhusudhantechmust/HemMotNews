//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/RequestContext.h $
//  
//  Owner: Jonathan W. Brown
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __REQUESTCONTEXT__
#define __REQUESTCONTEXT__

#include "FormatID.h"
#include "K2SmartPtr.h"
#include "k2VectorStreaming.h"
#include "PMLocaleId.h"	//see also FeatureSets.h and PMLocaleIds.h

class IScriptEngine ;
class IScriptManager ;

namespace ScriptInfo
{

/** A scripting client */
typedef ClassID ScriptClient ;
/**
	A scripting DOM version. To access the current scripting DOM version 
	(i.e., kMajorScriptVersionNumber, kMinorScriptVersionNumber), use
	Utils<IScriptUtils>()->GetCurrentScriptDOMVersion().
*/
typedef FormatID ScriptVersion ;
/** A list of scripting DOM versions */
typedef K2Vector<ScriptVersion> ScriptVersionList ;
/** The minimum scripting DOM version: 0,0 */
extern PUBLIC_DECL const ScriptVersion kMinimumScriptVersion ;
/** The maximum scripting DOM version: kMaxInt32, kMaxInt32 */
extern PUBLIC_DECL const ScriptVersion kMaximumScriptVersion ;
/** The CS scripting DOM version: kDragontailMajorScriptVersionNumber, kDragontailMinorScriptVersionNumber */
extern PUBLIC_DECL const ScriptVersion kDragontailScriptVersion ;
/** The CS2 scripting DOM version: kFiredrakeMajorScriptVersionNumber, kFiredrakeMinorScriptVersionNumber */
extern PUBLIC_DECL const ScriptVersion kFiredrakeScriptVersion ;
/** The CS3 scripting DOM version: kCobaltMajorScriptVersionNumber, kCobaltMinorScriptVersionNumber */
extern PUBLIC_DECL const ScriptVersion kCobaltScriptVersion ;
/** The CS4 scripting DOM version: kBasilMajorScriptVersionNumber, kBasilMinorScriptVersionNumber */
extern PUBLIC_DECL const ScriptVersion kBasilScriptVersion ;


//CONVERSION UTILITIES

/**	Convert a version number to a string */
extern PUBLIC_DECL PMString ToString( const ScriptVersion& version ) ;
/**	Convert a string to a version number */
extern PUBLIC_DECL ScriptVersion ToVersion( PMString s, PMString::ConversionError* pError = nil ) ;
/**	Convert a version number to a real */
extern PUBLIC_DECL PMReal ToReal( const ScriptVersion& version ) ;
/**	Convert a real to a version number */
extern PUBLIC_DECL ScriptVersion ToVersion( PMReal r ) ;


/**
	The context for a scripting DOM (document object model)
*/
class PUBLIC_DECL RequestContext
{
	public:
		typedef object_type data_type ;

		RequestContext() {}
		RequestContext( const IScriptManager* client, const ScriptVersion& version, const PMLocaleId& locale ) ;
		RequestContext( const RequestContext& other ) { *this = other ; }
		~RequestContext() {}

		/** Get product, feature set, and locale */
		const PMLocaleId&			GetLocale() const			{ return fLocale ; }
		/** Get the scripting DOM version */
		const ScriptVersion&		GetVersion() const			{ return fVersion ; }
		/** Get the client */
		const ScriptClient&			GetClient() const			{ return fClient ; }

		/** Query the script manager for the client */
		IScriptManager*				QueryScriptManager() const ;

		/** */
		RequestContext&					operator=( const RequestContext& ) ;
		/** */
		bool16						operator==( const RequestContext& other ) const { return ( fLocale == other.fLocale && fVersion == other.fVersion && fClient == other.fClient ) ; }
		/** */
		bool16						operator!=( const RequestContext& other ) const { return ( fLocale != other.fLocale || fVersion != other.fVersion || fClient != other.fClient ) ; }

		/** Persist this object */
		void						ReadWrite( IPMStream* s ) ;

	private:
		PMLocaleId					fLocale ;		//defined in PMLocaleId.h
		ScriptVersion				fVersion ;		//min version is 0.0; max version is kMaxInt32.kMaxInt32 (0x7FFFFFFF)
		ScriptClient				fClient ;		//ClassID of the client's script manager boss

#ifdef DEBUG
	public:
		/** Get a string describing this object (debug-only) */
		ConstCString				WhoAmI() const ;
		mutable scoped_array<char>	fWhoAmI ;
#endif
} ;

/** A list of DOM contexts */
typedef K2Vector<RequestContext> RequestContextList ;
DEFINEK2READWRITE( RequestContext )

/**
	The context for a scripting request determines the content of the scripting 
	document object model (DOM) that is used to process the request. It also 
	determines how a request is handled based on preferences in the client's 
	implementation of IScriptManager and IScriptPreferences.
*/
class PUBLIC_DECL EngineContext : public RequestContext
{
	public:
		typedef object_type data_type ;

		EngineContext() : fEngine( nil ) {}
		EngineContext( const IScriptManager* client, const ScriptVersion& version, const PMLocaleId& locale, const IScriptEngine* engine = nil ) ;
		EngineContext( const EngineContext& other ) : fEngine( nil ) { *this = other ; }
		~EngineContext() ;

		/** Query the script engine for this context. If none is set, returns the script manager's default engine. */
		IScriptEngine*				QueryScriptEngine() const ;

		/** */
		EngineContext&				operator=( const EngineContext& ) ;
		/** */
		bool16						operator==( const EngineContext& other ) const ;
		/** */
		bool16						operator!=( const EngineContext& other ) const ;

	private:
		const IScriptEngine*		fEngine ;

#ifdef DEBUG
	public:
		/** Get a string describing this object (debug-only) */
		ConstCString				WhoAmI() const ;
#endif
} ;

}	// End namespace ScriptInfo

#endif //__REQUESTCONTEXT__
