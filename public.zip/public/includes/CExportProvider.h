//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/includes/CExportProvider.h $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once
#ifndef __CExportProvider_h__
#define __CExportProvider_h__

#include "IExportProvider.h"

#ifdef PUBLIC_DECL
#pragma export on
#endif

/**
	Core base class implementation for IExportProvider
*/

class PUBLIC_DECL CExportProvider : public CPMUnknown<IExportProvider>
{			
public:
	CExportProvider(IPMUnknown* boss);
	virtual ~CExportProvider();

	/**@name  File Export  */
	//@{-----------------------------------------------------------------------------

	/** Export to a file. Default implementation calls ExportToStream. */
	virtual void ExportToFile(const IDFile& sysFile, IDocument* doc, IPMUnknown* targetboss, const PMString& formatName, UIFlags uiFlags);

	/** The provider indicates whether it can do normal file based exports. */
	virtual bool16 CanExportToFile() const;

	//@}-----------------------------------------------------------------------------

	/**@name  Clipboard/DragDrop Export  */
	//@{-----------------------------------------------------------------------------

	//	Stub this out since only a few ExportProviders actually support this type of export
	
	/** The provider indicates whether it can do normal file-based exports. */
	virtual bool16 CanExportForExternalize() const;

	/** For Clip/Drag operations, what internal flavor does this exporter operate on? */
	virtual PMFlavor GetInternalFlavor() const;
	
	/** For Clip/Drag operations, what external flavors can this exporter produce? */
	virtual int32 CountExternalFlavors() const;
	virtual ExternalPMFlavor GetExternalFlavor(int32 n) const;

	/** For Clip/Drag operations, what format type, if any, would be used to produce the desired external flavor? */
	virtual bool16 CanExportThisFlavor(const ExternalPMFlavor& flavor, PMString& outFormatName) const;
		
	/** Externalize the given data to a stream. */
	virtual ErrorCode ExportForExternalize(IDataExchangeHandler *handler, const ExternalPMFlavor toWhichFlavor, IPMStream* stream);

	//@}-----------------------------------------------------------------------------

protected:
	/** Send an export signal to responders
		@param service IN is the signal's service ID
		@param document IN is the target document
		@param sysFile IN is the file being exported
		@param formatName IN is the format being exported
		@param uiFlags IN are the ui flags
	*/
	virtual ErrorCode SendSignal( const ServiceID& service, IDocument* document, const IDFile& sysFile, const PMString& formatName, UIFlags uiFlags ) ;
};

#pragma export off

#endif // __CExportProvider_h__
