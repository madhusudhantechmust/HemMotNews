//this file is designed to be parsed by a custom script.
//it should have 3 comment lines at the top, followed by one single JS command line.
//The single JS command should include no spaces, except those that surround REPLACE_WITH_PATH
var separator = "/";
var scriptName = new String(app.activeScript);
var dirSeparator = scriptName.lastIndexOf(separator);
var parentDir = scriptName.substring(0,dirSeparator+1);
markerFile = File(parentDir + "corba.marker");
if (!markerFile.exists) {
markerFile.open("w");
markerFile.write("Marker file for Adobe InDesign Server CORBA API Generation");
markerFile.close();
app.generateCorbaApi(File(
REPLACE_WITH_PATH
));app.quit();}