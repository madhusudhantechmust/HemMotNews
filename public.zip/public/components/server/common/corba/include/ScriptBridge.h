//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/ScriptBridge.h $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __ScriptBridge_h__
#define __ScriptBridge_h__

#include <vector>

#include "CorbaObjectSpecifier.h"

class ScriptData;
class CorbaScriptDataAdaptor;
class ScriptEnv;

//========================================================================================
// CLASS ScriptBridge
//========================================================================================

class ScriptBridge
{
public:
	static ErrorCode GetProperty(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& property, CorbaScriptDataAdaptor& adaptor);
	static ErrorCode SetProperty(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& property, const CorbaScriptDataAdaptor& adaptor);

	typedef std::pair<ScriptID, CorbaScriptDataAdaptor*> Parameter;
	typedef std::vector<Parameter> ParameterList;
	static ErrorCode MethodCall(const ScriptEnv& env,
								const CorbaObjectSpecifier* objectSpecifier,
								const ScriptID& childObjectType,
								const ScriptID& method,
								const ParameterList& parameters,
								CorbaScriptDataAdaptor& result);

	static ErrorCode GetChildCnt(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& childObjectType, int32& cnt);
	static ErrorCode GetNthChild(const ScriptEnv& env,
								 const CorbaObjectSpecifier* objectSpecifier,
								 const int32& index,
								 const ScriptID& property,
								 CorbaScriptDataAdaptor& result);
	static ErrorCode GetNamedChild(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const PMString& name, const ScriptID& property, CorbaScriptDataAdaptor& result);
	static ErrorCode GetIdentifiedChild(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const int32& id, const ScriptID& property, CorbaScriptDataAdaptor& result);
	static ErrorCode GetAllChildren(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& property, CorbaScriptDataAdaptor& result);
	static ErrorCode GetRangeOfChildren(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const CorbaScriptDataAdaptor& range, const ScriptID& property, CorbaScriptDataAdaptor& result);
};

#endif
