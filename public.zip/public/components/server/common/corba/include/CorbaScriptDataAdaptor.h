//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/CorbaScriptDataAdaptor.h $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __CorbaScriptDataAdaptor_h__
#define __CorbaScriptDataAdaptor_h__

#include "ScriptData.h"

#undef nil
#include "BaseTypes.hh"
#include "VariableType.hh"
#include "SObject.hh"
#define nil 0

class ScriptEnv;

//========================================================================================
// CLASS CorbaScriptDataAdaptor
//========================================================================================

class CorbaScriptDataAdaptor
{
public:
	static PMString CorbaToPMString(const CORBA::WChar* str) ;
	static CORBA::WChar* PMToCorbaString(const PMString str) ;

	// ---- Overrides for the script model side.

	virtual void SetScriptData(const ScriptData& scriptData);
	virtual ScriptData GetScriptData() const;

	// ---- Accessors for the corba side.

	com::adobe::ids::framework::SObject_ptr GetObject(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::Long GetEnumeration(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::Short GetShort(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::Long GetLong(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::LongLong GetLongLong(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::Boolean GetBoolean(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::Double GetDouble(const ScriptEnv& env, const long& nth = 0) const;
	com::adobe::ids::Unit_var GetUnit(const ScriptEnv& env, const long& nth = 0) const;
	com::adobe::ids::DateType GetDate(const ScriptEnv& env, const long& nth = 0) const;
	CORBA::WChar* GetString(const ScriptEnv& env, const long& nth = 0) const;
	com::adobe::ids::VariableType_var GetVariableType(const ScriptEnv& env) const;
	com::adobe::ids::VariableType_var GetVariableType(const ScriptEnv& env, const long& nth) const;
	CORBA::WChar* GetFile(const ScriptEnv& env, const long& nth = 0) const;

	long GetItemCnt(const ScriptEnv& env) const;

	void AppendObject(const ScriptEnv& env, com::adobe::ids::framework::SObject_ptr object, const bool& useList = false);
	void AppendEnumeration(const ScriptEnv& env, const CORBA::Long& value, const bool& useList = false);
	void AppendShort(const ScriptEnv& env, const CORBA::Short& value, const bool& useList = false);
	void AppendLong(const ScriptEnv& env, const CORBA::Long& value, const bool& useList = false);
	void AppendLongLong(const ScriptEnv& env, const CORBA::LongLong& value, const bool& useList = false);
	void AppendBoolean(const ScriptEnv& env, const CORBA::Boolean& value, const bool& useList = false);
	void AppendDouble(const ScriptEnv& env, const CORBA::Double& value, const bool& useList = false);
	void AppendUnit(const ScriptEnv& env,  const com::adobe::ids::Unit& value, const bool& useList = false);
	void AppendDate(const ScriptEnv& env, const com::adobe::ids::DateType& date, const bool& useList = false);
	void AppendString(const ScriptEnv& env, const CORBA::WChar* string, const bool& useList = false);
	void AppendVariableType(const ScriptEnv& env, const com::adobe::ids::VariableType& vt, const bool& useList = false);
	void AppendFile(const ScriptEnv& env, const CORBA::WChar* file, const bool& useList = false);
	void AppendRange(const ScriptEnv &env, const com::adobe::ids::VariableType& from, const com::adobe::ids::VariableType& to, const bool& useList = false);
	void AppendList(const ScriptEnv &env, const com::adobe::ids::List& list, const bool& useList = false);
	void AppendObjectList(const ScriptEnv &env, const com::adobe::ids::ObjectList& objectList, const bool& useList = false);

private:
	CORBA::WChar* CreateCorbaString(const PMString& string) const;
	uint64 IDTimeToUnixTime(const uint64 number) const;
	uint64 UnixTimeToIDTime(const uint64 number) const;

private:
	mutable ScriptData fScriptData;
	ScriptListData fScriptListData;
};

#endif
