//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/CorbaObjectSpecifier.h $
//  
//  Owner: Jonathan W. Brown
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __CorbaObjectSpecifier_h__
#define __CorbaObjectSpecifier_h__

#include "ScriptClientObject.h"
#include "ScriptInfo.h"

#undef nil
#include <omniORB4/CORBA.h>
#define nil 0

class IScript ;

/**
	This class manages references to objects in the internal object model for scripting
	DOM objects being held by the Corba client.
*/
class CorbaObjectSpecifier : public ScriptClientObject
{
public:
	/**
		Generate an ObjectId that refers to an object specifier for the Corba client
	*/
	static PortableServer::ObjectId* CreateCorbaObjectId( const CorbaObjectSpecifier* objectSpecifier ) ;
	/**
		Locate the Corba client object specifier to which an ObjectID refers. May
		return nil if the object specifier no longer exists. If not nil, then the
		return value is AddRef'd.
	*/
	static const CorbaObjectSpecifier* ParseCorbaObjectId( const PortableServer::ObjectId& oid ) ;

public:
	/**
		Construct a Corba client object specifier for the given model object in the given context
	*/
	CorbaObjectSpecifier( IScript* script, const EngineContext& context ) ;

	/**
		Increment the number of references held by the client on this ScriptClientObject.
	*/
	void						AddRefFromClient() const { AddRef() ; }

	/**
		Decrement the number of references held by the client on this ScriptClientObject.
	*/
	void						ReleaseRefFromClient() const ;

	/**
		Increment the number of references held by the object model on this ScriptClientObject.
	*/
	virtual void				AddRefFromObjectModel() const { AddRef() ; }
		
	/**
		Decrement the number of references held by the object model on this ScriptClientObject.
	*/
	virtual void				ReleaseRefFromObjectModel() const { Release() ; }

	/**
		Release all InDesign object model boss references that are being held by this client
		object on the passed in boss.
		@param script is the IScript interface on the boss making the request
	*/
	virtual void				ReleaseReferencesToObjectModel( IScript* script ) ;

public:
	/** Return the unique id of this instance */
	int32						GetID() const { return fID ; }
	/** Return a core object specifier string that refers to the object in the scripting DOM specified by this instance */
	PMString					GetCoreSpecifier() const ;
	/** Return the value of the ScriptID for the type of the object in the scripting DOM specified by this instance */
	int32						GetObjectType() const { return fObjectType ; }
	/** Query the internal model object specified by this instance */
	IScript*					QueryScript() const ;

private:
	void						AddRef() const { ++fRefCount ; }
	void						Release() const { if ( --fRefCount == 0 ) delete this ; }

private:
	const int32					fID ;
	mutable int32				fRefCount ;
	IScript*					fScript ;
	EngineContext				fContext ;
	int32						fObjectType ;

private:
	/** Used to generate a unique id for each instance of this class */
	static int32				fNextID ;
	/** Used to maintain a lookup list of all instances of this class */
	static K2Vector<CorbaObjectSpecifier*>	fActiveCorbaObjects ;

private:
	//hide constructor
	CorbaObjectSpecifier();
	//hide copy constructor
	CorbaObjectSpecifier( const CorbaObjectSpecifier& ) ;
	//hide destructor
	virtual ~CorbaObjectSpecifier() ;
};

#endif
