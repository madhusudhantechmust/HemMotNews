//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/APIBaseImpl.h $
//  
//  Owner: 
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __APIBaseImpl_h__
#define __APIBaseImpl_h__

#include "PMString.h"

#include "OmniOrbConfig.h"

#include "BaseTypes.hh"
#include "APIBase.hh"

namespace com { namespace adobe { namespace ids {

class APIBase_Servant:
	public virtual com::adobe::ids::ServantBase,
	public virtual POA_com::adobe::ids::framework::APIBase
{
public:
	APIBase_Servant(const PMString& objectSpecifier);
	virtual ~APIBase_Servant();
   
	virtual CORBA::Long getObjectType() = 0;

	virtual char* getObjectSpecifier();
    virtual CORBA::Boolean isVariableType();

protected:
	PMString fObjectSpecifier;
	bool fIsVariableType;
};

} } }

#endif
