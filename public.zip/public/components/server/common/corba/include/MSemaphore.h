//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/MSemaphore.h $
//  
//  Owner: Lonnie Millett
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __MSemaphore__
#define __MSemaphore__

#include <pthread.h>

namespace id {

//========================================================================================
// CLASS MSemaphore
//========================================================================================

class PUBLIC_DECL MSemaphore
{
public:
	MSemaphore(const uint32& initialCount);
	~MSemaphore();

	void Acquire();
	void Relinquish();

private:
	uint32 fCount;					// Current count of the semaphore.
	uint32 fWaitersCount;			// Number of threads that have called <sema_wait>.  
	pthread_mutex_t fLock;			// Serialize access to <count_> and <waiters_count_>.
	pthread_cond_t fCountNonzero;	// Condition variable that blocks the <count_> 0.
};

}

#endif

