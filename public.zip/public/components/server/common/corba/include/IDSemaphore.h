//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/IDSemaphore.h $
//  
//  Owner: Lonnie Millett
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#pragma once

#ifdef MACINTOSH
#include "MSemaphore.h"
namespace id {
typedef MSemaphore Semaphore;
}
#endif

#ifdef WINDOWS
#include "WSemaphore.h"
namespace id {
typedef WSemaphore Semaphore;
}
#endif

