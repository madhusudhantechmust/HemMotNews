//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/ScriptEnv.h $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __ScriptEnv_h__
#define __ScriptEnv_h__

#include "RequestContext.h"

class IScriptEngine ;
class IScriptEventData ;
class ActiveScriptState ;

//========================================================================================
// CLASS ScriptEnv
//========================================================================================

class ScriptEnv
{
public:
	ScriptEnv();
	~ScriptEnv();

	const ScriptInfo::EngineContext&	GetRequestContext() const { return *fRequestContext ; }
	IScriptEventData*					CreateScriptEventData() const ;

private:
	IScriptEngine* fScriptEngine;
	ActiveScriptState* fActiveScriptState;
	ScriptInfo::EngineContext* fRequestContext;
};

#endif
