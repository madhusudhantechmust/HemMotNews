//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/include/client/VCPluginHeaders.h $
//  
//  Owner: ???
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  used when the corba implementation plug-in is built. Both clients and
//  the server implementation plug-in includes the client stubs, by including
//  the set of files SourceXX.cpp in their projects. The server implementation
//  sets the preprocessor define CORBA_IMPL, which in addition makes it so that
//  the SourceXX.cpp files include the implementation files also.//  
//  
//========================================================================================

