//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/impl/APIBaseImpl.cpp $
//  
//  Owner: 
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  ADOBE CONFIDENTIAL
//  
//  with the terms of the Adobe license agreement accompanying it. If you have received
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ---- Implementation Includes ----

#include "APIBaseImpl.h"

namespace com { namespace adobe { namespace ids {

APIBase_Servant::APIBase_Servant(const PMString& objectSpecifier) :
	fObjectSpecifier(objectSpecifier),
	fIsVariableType(false)
{
}

APIBase_Servant::~APIBase_Servant()
{
}

CORBA::Boolean APIBase_Servant::isVariableType()
{
	return fIsVariableType;
}

char* APIBase_Servant::getObjectSpecifier()
{
	return CORBA::string_dup(fObjectSpecifier.GrabCString());
}

} } }
