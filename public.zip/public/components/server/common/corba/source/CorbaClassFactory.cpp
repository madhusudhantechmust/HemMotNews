//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/CorbaClassFactory.cpp $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ---- Interface Includes ----

#include "IScriptManager.h"
#include "IScriptUtils.h"
#include "IScript.h"

// ---- Implementation Includes ----

#include "CorbaUtilsID.h"
#include "CorbaClassFactory.h"
#include "ActiveScriptState.h"
#include "Utils.h"
#include "ScriptEnv.h"

// ---- Library Includes ----

using namespace std;
using namespace com::adobe::ids;

map<CORBA::Long, CorbaClassFactory::CreateObjectFunc> CorbaClassFactory::fObjectFunctionTable;
map<CORBA::Long, CorbaClassFactory::CreateServantFunc> CorbaClassFactory::fServantFunctionTable;

FactoryRegistrar::FactoryRegistrar(const CORBA::Long& objectType, CorbaClassFactory::CreateObjectFunc createObjectFunc, CorbaClassFactory::CreateServantFunc createServantFunc)
{
	CorbaClassFactory::RegisterFactory(objectType, createObjectFunc, createServantFunc);
}

void CorbaClassFactory::RegisterFactory(const CORBA::Long& objectType, CreateObjectFunc createObjectFunc, CreateServantFunc createServantFunc)
{
	fObjectFunctionTable.insert(make_pair(objectType, createObjectFunc));
	fServantFunctionTable.insert(make_pair(objectType, createServantFunc));
}

framework::SObject_ptr CorbaClassFactory::CreateObject( IScript* script, const EngineContext& context )
{
	framework::SObject_var object = framework::SObject::_nil();
	const CorbaObjectSpecifier* objectSpecifier = new CorbaObjectSpecifier( script, context ) ;
	const long objectTypeId = objectSpecifier->GetObjectType() ;
	map<CORBA::Long, CreateObjectFunc>::const_iterator i = fObjectFunctionTable.find(objectTypeId);
	if (i != fObjectFunctionTable.end())
		object = i->second(objectSpecifier);
	objectSpecifier->ReleaseRefFromClient() ;
	return object._retn();
}

PortableServer::Servant CorbaClassFactory::CreateServant( const CorbaObjectSpecifier* objectSpecifier )
{
	PortableServer::Servant servant = NULL;
	if ( objectSpecifier )
	{
		const long objectTypeId = objectSpecifier->GetObjectType() ;
		map<CORBA::Long, CreateServantFunc>::const_iterator i = fServantFunctionTable.find(objectTypeId);
		if (i != fServantFunctionTable.end())
			servant = i->second(objectSpecifier);
	}
	return servant;
}
