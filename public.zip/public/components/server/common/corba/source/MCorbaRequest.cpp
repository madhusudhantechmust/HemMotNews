//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/MCorbaRequest.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: boshea $
//  
//  $DateTime: 2008/08/19 14:53:30 $
//  
//  $Revision: #2 $
//  
//  $Change: 643820 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPlugInHeaders.h"

// ----- Interface Includes -----

#include "MCorbaRequest.h"
#include "MEvent.h"

// ----- Implementation Includes -----

//========================================================================================
// METHODS CorbaRequest
//========================================================================================

//----------------------------------------------------------------------------------------
// CorbaRequest::CorbaRequest
//----------------------------------------------------------------------------------------

CorbaRequest::CorbaRequest()
{
}

//----------------------------------------------------------------------------------------
// CorbaRequest::~CorbaRequest
//----------------------------------------------------------------------------------------

CorbaRequest::~CorbaRequest()
{
}

//----------------------------------------------------------------------------------------
// CorbaRequest::WakeupEventLoop
//----------------------------------------------------------------------------------------

void CorbaRequest::WakeupEventLoop() const
{
	// ---- This message wakes up the main event loop, so the idle tasks will get
	//		processed. The main event loop does not do anything special with
	//		this message.

    EventRef event;
    CreateEvent(NULL, kEventClassCustom, kEventWakeupEventLoop,
				0, kEventAttributeNone, &event);
	PostEventToQueue(GetMainEventQueue(), event, kEventPriorityHigh);
	::ReleaseEvent(event);	// queue owns the event - release the retain that got added by the 'CreateEvent'
}

