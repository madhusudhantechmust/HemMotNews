//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/ScriptBridge.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ---- Interface Includes ----

#include "IScript.h"
#include "IScriptRequestHandler.h"
#include "IScriptUtils.h"

// ---- Implementation Includes ----

#include "CorbaUtilsID.h"
#include "ScriptBridge.h"
#include "CorbaScriptDataAdaptor.h"
#include "ScriptEnv.h"

using namespace std;

//----------------------------------------------------------------------------------------
// ScriptBridge::GetProperty
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetProperty(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& propID, CorbaScriptDataAdaptor& adaptor)
{
	InterfacePtr<IScriptRequestHandler> scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler(env.GetRequestContext()));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData> scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	ErrorCode error = scriptRequestHandler->DoGetProperty(script, propID, scriptEventData);
	if (error != kSuccess) return error;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	if (scriptEventData->GetNumReturnData( script ) == 0) return kFailure;
	
	adaptor.SetScriptData( scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue() );
	return kSuccess;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::SetProperty
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::SetProperty(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& propID, const CorbaScriptDataAdaptor& adaptor)
{
	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData>	scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	scriptEventData->InsertEventData(propID, adaptor.GetScriptData());

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	return scriptRequestHandler->DoSetProperty(script, propID, scriptEventData);
}

//----------------------------------------------------------------------------------------
// ScriptBridge::MethodCall
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::MethodCall(const ScriptEnv& env,
								   const CorbaObjectSpecifier* objectSpecifier,
								   const ScriptID& childObjectType,
								   const ScriptID& method,
								   const ParameterList& parameters,
								   CorbaScriptDataAdaptor& result)
{
	ErrorCode error = kSuccess;

	{
		// ---- Scope everything, just in case the ProcessScheduledCmds at the end of this function
		//		causes things to go out of scope (e.g. when the method we are calling is 'closedoc', 
		//		putting the IScript for the document into the ScriptList causes confusion when the ScriptList
		//		is destructed (and holding onto a stale pointer)

		InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
		if (!scriptRequestHandler) return kFailure;

		InterfacePtr<IScriptEventData>	scriptEventData(env.CreateScriptEventData());
		if (!scriptEventData) return kFailure;

		for (ParameterList::const_iterator i = parameters.begin(); i != parameters.end(); i++)
		{
			// ---- The first three params need to change 
			scriptEventData->InsertEventData(i->first, i->second->GetScriptData());
		}

		InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
		error = scriptRequestHandler->DoHandleCollectionEvent(script, childObjectType, method, scriptEventData);
		if ( error == kEventNotHandled )
			error = scriptRequestHandler->DoHandleEvent(script, method, scriptEventData);
		if (error != kSuccess) return error;

		if (scriptEventData->GetNumReturnData( script ) > 0)
		{
			ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
			result.SetScriptData(scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue());
		}
	}

	// ---- Process all scheduled commands except for the kLowestPriority. This is because the
	//		quit command is scheduled with this priority by ApplicationScriptProvider and we
	//		don't actually want that command to execute until we've finished processing this
	//		CORBA request. Otherwise the application will be shutdown while in the middle of
	//		handling an idle task, which is bad. [mburbidg 8-2-06]

	CmdUtils::ProcessScheduledCmds(ICommand::kLowPriority);

	return error;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::GetChildCnt
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetChildCnt(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& childObjectType, int32& cnt)
{
	cnt = 0;

	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData>	scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	ErrorCode error = scriptRequestHandler->DoHandleCollectionEvent( script, childObjectType, ScriptID( e_Count ), scriptEventData ) ;
	if (error != kSuccess) return kFailure;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	if ( scriptEventData->GetNumReturnData( script ) == 0 ) return kFailure ;

	error = scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue().GetInt32(&cnt);
	return kSuccess;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::GetNthChild
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetNthChild(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const int32& index, const ScriptID& propID, CorbaScriptDataAdaptor& result)
{	
	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData> scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	if (!script) return kFailure;

	ErrorCode error = scriptRequestHandler->DoGetObject(script, propID, kFormIndex, ScriptData(index), scriptEventData);
	if (error != kSuccess) return error;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	if ( scriptEventData->GetNumReturnData( script ) == 0 ) return kFailure;

	ScriptList returnList;
	scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue().GetObjectList(returnList);
	ASSERT(returnList.size() == 1);
	
	if (returnList.size() != 1) return kFailure;
	
	ScriptData returnObject(returnList[0]);
	result.SetScriptData(returnObject);
	return kSuccess;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::GetNamedChild
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetNamedChild(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const PMString& name, const ScriptID& propID, CorbaScriptDataAdaptor& result)
{
	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData> scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;
	
	PMString ntName(name);
	ntName.SetTranslatable(kFalse);

	ScriptData scriptData(ntName);

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	if (!script) return kFailure;

	ErrorCode err = scriptRequestHandler->DoGetObject(script, propID, kFormName, scriptData, scriptEventData);
	if (err != kSuccess) return err;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	if ( scriptEventData->GetNumReturnData( script ) == 0 ) return kFailure ;

	ScriptList returnList;
	scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue().GetObjectList(returnList);
	ASSERT(returnList.size() == 1);
	
	if (returnList.size() != 1) return kFailure;
	
	ScriptData returnObject(returnList[0]);
	result.SetScriptData(returnObject);

	return kSuccess;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::GetIdentifiedChild
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetIdentifiedChild(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const int32& id, const ScriptID& propID, CorbaScriptDataAdaptor& result)
{
	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData> scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	if (!script) return kFailure;

	ErrorCode err = scriptRequestHandler->DoGetObject(script, propID, kFormUniqueID, ScriptData(id), scriptEventData);
	if (err != kSuccess) return err;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	if ( scriptEventData->GetNumReturnData( script ) == 0 ) return kFailure ;

	ScriptList returnList;
	scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue().GetObjectList(returnList);
	ASSERT(returnList.size() == 1);
	
	if (returnList.size() != 1) return kFailure;
	
	ScriptData returnObject(returnList[0]);
	result.SetScriptData(returnObject);

	return kSuccess;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::GetAllChildren
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetAllChildren(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const ScriptID& propID, CorbaScriptDataAdaptor& result)
{	
	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData> scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	if (!script) return kFailure;

	ErrorCode error = scriptRequestHandler->DoGetObject(script, propID, kFormAll, ScriptData(ScriptID(kFormAll)), scriptEventData);
	if (error != kSuccess) return error;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	if ( scriptEventData->GetNumReturnData( script ) == 0 ) return kFailure;

	result.SetScriptData(scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue());
	return kSuccess;
}

//----------------------------------------------------------------------------------------
// ScriptBridge::GetRangeOfChildren
//----------------------------------------------------------------------------------------

ErrorCode ScriptBridge::GetRangeOfChildren(const ScriptEnv& env, const CorbaObjectSpecifier* objectSpecifier, const CorbaScriptDataAdaptor& range, const ScriptID& propID, CorbaScriptDataAdaptor& result)
{	
	InterfacePtr<IScriptRequestHandler>	scriptRequestHandler(Utils<IScriptUtils>()->QueryScriptRequestHandler( env.GetRequestContext() ));
	if (!scriptRequestHandler) return kFailure;

	InterfacePtr<IScriptEventData> scriptEventData(env.CreateScriptEventData());
	if (!scriptEventData) return kFailure;

	InterfacePtr<IScript> script( objectSpecifier->QueryScript() ) ;
	if (!script) return kFailure;

	ErrorCode error = scriptRequestHandler->DoGetObject(script, propID, kFormRange, range.GetScriptData(), scriptEventData);
	if (error != kSuccess) return error;

	ASSERT(scriptEventData->GetNumReturnData( script ) == 1);
	result.SetScriptData(scriptEventData->GetNthReturnData( script, 0 ).GetReturnValue());
	return kSuccess;
}
