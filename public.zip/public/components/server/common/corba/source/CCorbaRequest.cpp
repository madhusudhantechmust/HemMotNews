//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/CCorbaRequest.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPlugInHeaders.h"

// ----- Interface Includes -----

#include "CCorbaRequest.h"

// ----- Implementation Includes -----

#include "AcquireResource.h"
#include "CCommandLineArgs.h"

//========================================================================================
// METHODS CCorbaRequest
//========================================================================================

//----------------------------------------------------------------------------------------
// CCorbaRequest::CCorbaRequest
//----------------------------------------------------------------------------------------

CCorbaRequest::CCorbaRequest() :
	fRequestSemaphore(1),
	fRequest(NULL),
	fResultsSemaphore(1)
{
	fResultsSemaphore.Acquire();
}

//----------------------------------------------------------------------------------------
// CCorbaRequest::~CCorbaRequest
//----------------------------------------------------------------------------------------

CCorbaRequest::~CCorbaRequest()
{
}

//----------------------------------------------------------------------------------------
// CCorbaRequest::SetRequest
//----------------------------------------------------------------------------------------

void CCorbaRequest::SetRequest(void* request)
{
	AcquireResource<id::Semaphore> aqSm(fRequestSemaphore);
	fRequest = request;

	// ---- This message wakes up the main event loop, so the idle tasks will get
	//		processed.
	
	WakeupEventLoop();
}

//----------------------------------------------------------------------------------------
// CCorbaRequest::GetRequest
//----------------------------------------------------------------------------------------

void* CCorbaRequest::GetRequest() const
{
	AcquireResource<id::Semaphore> aqSm(fRequestSemaphore);

	void* request = fRequest;
	fRequest = NULL;

	return request;
}

//----------------------------------------------------------------------------------------
// CCorbaRequest::SignalResultsAvailable
//----------------------------------------------------------------------------------------

void CCorbaRequest::SignalResultsAvailable()
{
	fResultsSemaphore.Relinquish();
}

//----------------------------------------------------------------------------------------
// CCorbaRequest::WaitForResults
//----------------------------------------------------------------------------------------

void CCorbaRequest::WaitForResults() const
{
	fResultsSemaphore.Acquire();
	((CCorbaRequest*) this)->SetRequest(NULL);
}

