//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/CorbaScriptDataAdaptor.cpp $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ---- Interface Includes ----

#include "IScript.h"
#include "IScriptUtils.h"

// ---- Implemetation Includes ----

#include "CorbaUtilsID.h"
#include "CorbaScriptDataAdaptor.h"
#include "CorbaClassFactory.h"
#include "FileUtils.h"
#include "ActiveScriptState.h"
#include "ScriptEnv.h"

#include "boost/shared_ptr.hpp"

// the ID time is equal to the NT FILETIME, which is the count of 100 ns
// since January 1, 1601. This is the offset to the Unix time that the CORBA API uses
// (January 1, 1970) in milliseconds:
const int64 TIME_BIAS = 11644473600000LL ;	//milliseconds
const int64 TIME_CONVERSION = 10000 ;

using namespace com::adobe::ids;

PMString CorbaScriptDataAdaptor::CorbaToPMString(const CORBA::WChar* str)
{
	PMString idStr(WideString((wchar_t*) str, std::wstring(str).size()));
	return idStr;
}

CORBA::WChar* CorbaScriptDataAdaptor::PMToCorbaString(const PMString str)
{
	int32 strLength = str.WCharLength();
	if (0 == strLength)
		return CORBA::wstring_dup(L"");

	boost::shared_ptr<wchar_t> data(new wchar_t[str.WCharLength() + 1]);
	str.GetWChar_tString(data.get(), str.WCharLength() + 1);
	return CORBA::wstring_dup(data.get());
}
//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::SetScriptData
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::SetScriptData(const ScriptData& scriptData)
{
		fScriptData = scriptData;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetScriptData
//----------------------------------------------------------------------------------------

ScriptData CorbaScriptDataAdaptor::GetScriptData() const
{
	if (fScriptListData.size() > 0)
		fScriptData.SetList(fScriptListData);

	return fScriptData;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetObject
//----------------------------------------------------------------------------------------

framework::SObject_ptr CorbaScriptDataAdaptor::GetObject(const ScriptEnv& env, const long& nth) const
{
	framework::SObject_var object = framework::SObject::_nil();

	if (fScriptData.GetType() == ScriptData::s_object)
	{
		if (nth == 0)
		{
			InterfacePtr<IScript> scriptObject(fScriptData.QueryObject());
			object = CorbaClassFactory::CreateObject( scriptObject, env.GetRequestContext() );
		}
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				InterfacePtr<IScript> scriptObject(scriptListData[nth].QueryObject());
				object = CorbaClassFactory::CreateObject( scriptObject, env.GetRequestContext() );
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetObject - couldn't get the list");
	}
	else if (fScriptData.GetType() == ScriptData::s_objectlist)
	{
		ScriptList	scriptList;
		if (fScriptData.GetObjectList(scriptList) == kSuccess)
		{
			if (nth < scriptList.size())
				object = CorbaClassFactory::CreateObject( scriptList[nth], env.GetRequestContext() );
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetObject - couldn't get the object list");
	}

	return object._retn();
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetEnumeration
//----------------------------------------------------------------------------------------

CORBA::Long CorbaScriptDataAdaptor::GetEnumeration(const ScriptEnv& env, const long& nth) const
{
	ScriptID result = 0;

	if (fScriptData.GetType() == ScriptData::s_enumeration)
	{
		if (nth == 0)
			fScriptData.GetEnumeration(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_enumeration)
					scriptListData[nth].GetEnumeration(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetEnumeration - couldn't get the list");
	}

	return (CORBA::Long) result.Get();
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetShort
//----------------------------------------------------------------------------------------

CORBA::Short CorbaScriptDataAdaptor::GetShort(const ScriptEnv& env, const long& nth) const
{
	int16 result = 0;

	if (fScriptData.GetType() == ScriptData::s_shortint)
	{
		if (nth == 0)
			fScriptData.GetInt16(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_shortint)
					scriptListData[nth].GetInt16(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetShort - couldn't get the list");
	}

	return (CORBA::Short) result;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetLong
//----------------------------------------------------------------------------------------

CORBA::Long CorbaScriptDataAdaptor::GetLong(const ScriptEnv& env, const long& nth) const
{
	int32 result = 0;

	if (fScriptData.GetType() == ScriptData::s_longint)
	{
		if (nth == 0)
			fScriptData.GetInt32(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_longint)
					scriptListData[nth].GetInt32(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetLong - couldn't get the list");
	}

	return (CORBA::Long) result;
}
//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetLongLong
//----------------------------------------------------------------------------------------

CORBA::LongLong CorbaScriptDataAdaptor::GetLongLong(const ScriptEnv& env, const long& nth) const
{
	int64 result = 0;

	if (fScriptData.GetType() == ScriptData::s_longlongint)
	{
		if (nth == 0)
			fScriptData.GetInt64(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_longlongint)
					scriptListData[nth].GetInt64(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetLong - couldn't get the list");
	}

	return (CORBA::LongLong) result;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetBoolean
//----------------------------------------------------------------------------------------

CORBA::Boolean CorbaScriptDataAdaptor::GetBoolean(const ScriptEnv& env, const long& nth) const
{
	bool16 result = 0;

	if (fScriptData.GetType() == ScriptData::s_boolean)
	{
		if (nth == 0)
			fScriptData.GetBoolean(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_longint)
					scriptListData[nth].GetBoolean(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetBoolean - couldn't get the list");
	}

	return (CORBA::Boolean) result;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetDouble
//----------------------------------------------------------------------------------------

CORBA::Double CorbaScriptDataAdaptor::GetDouble(const ScriptEnv& env, const long& nth) const
{
	PMReal result = 0;

	if (fScriptData.GetType() == ScriptData::s_double)
	{
		if (nth == 0)
			fScriptData.GetPMReal(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_double)
					scriptListData[nth].GetPMReal(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetDouble - couldn't get the list");
	}

	return (CORBA::Double) ::ToDouble(result);
}
//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetUnit
//----------------------------------------------------------------------------------------

Unit_var CorbaScriptDataAdaptor::GetUnit(const ScriptEnv& env, const long& nth) const
{
	PMReal result = 0;

	if (fScriptData.GetType() == ScriptData::s_unit)
	{
		if (nth == 0)
			fScriptData.RetrieveUnit(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_unit)
					scriptListData[nth].RetrieveUnit(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetUnit - couldn't get the list");
	}

	Unit_var unit = new Unit();
	unit->asDouble(::ToDouble(result));

	return unit;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetDate
//----------------------------------------------------------------------------------------

DateType CorbaScriptDataAdaptor::GetDate(const ScriptEnv& env, const long& nth) const
{
	uint64 result = 0;

	if (fScriptData.GetType() == ScriptData::s_date)
	{
		if (nth == 0)
			fScriptData.GetDate(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_date)
					scriptListData[nth].GetDate(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetDate - couldn't get the list");
	}

	return (DateType) IDTimeToUnixTime(result);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetString
//----------------------------------------------------------------------------------------

CORBA::WChar* CorbaScriptDataAdaptor::GetString(const ScriptEnv& env, const long& nth) const
{
	PMString result = "";

	if (fScriptData.GetType() == ScriptData::s_string)
	{
		if (nth == 0)
			fScriptData.GetPMString(result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_string)
					scriptListData[nth].GetPMString(result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetString - couldn't get the list");
	}

	ASSERT_MSG( result.empty() || !result.IsTranslatable() || result.HasTranslated(), 
		FORMAT_ARGS( "CorbaScriptDataAdaptor::GetString - Untranslated key string: %s "
						"\r\nEng: Script providers must return untranslated strings to INX and translated strings to scripting clients. "
						"\r\nQE: Please report this assert as a 2/2 bug.", result.GrabCString() ) ) ;
	return CreateCorbaString(result);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetVariableType
//----------------------------------------------------------------------------------------

VariableType_var CorbaScriptDataAdaptor::GetVariableType(const ScriptEnv& env) const
{
	VariableType_var vt = new VariableType();

	switch (fScriptData.GetType())
	{
	case ScriptData::s_empty:		vt->empty(true);						break;
	case ScriptData::s_boolean:		vt->asBoolean(GetBoolean(env));			break;
	case ScriptData::s_string:		vt->asString(GetString(env));			break;
//	case ScriptData::s_shortint:	vt->asShort(GetShort(env));				break;
	case ScriptData::s_longint:		vt->asLong(GetLong(env));				break;
//	case ScriptData::s_longlongint:	vt->asLongLong(GetLongLong(env));		break;
	case ScriptData::s_double:		vt->asDouble(GetDouble(env));			break;
	case ScriptData::s_object:
		{
			framework::SObject_var object = GetObject(env);
			vt->asObject(object);	
		}
		break;
	case ScriptData::s_date:		vt->asDate(GetDate(env));				break;
	case ScriptData::s_file:		vt->asFile(GetFile(env));				break;
	case ScriptData::s_enumeration:	vt->asEnumeration(GetEnumeration(env));	break;
	case ScriptData::s_unit:		vt->asUnit(GetUnit(env));				break;
	case ScriptData::s_list:
		{
			ScriptListData scriptListData;
			if (fScriptData.GetList(scriptListData) == kSuccess)
			{
				List list;
				list.length(scriptListData.size());
				for (int i = 0; i < scriptListData.size(); i++)
				{
					CorbaScriptDataAdaptor adaptor;
					adaptor.SetScriptData(scriptListData[i]);
					VariableType_var elem = adaptor.GetVariableType(env);
					list[i] = elem;
				}
				vt->asList(list);
			}
			break;
		}
	case ScriptData::s_objectlist:
		{
			ObjectList list;
			list.length(GetItemCnt(env));
			for (long i = 0; i < GetItemCnt(env); i++)
			{
				list[i] = GetObject(env, i);
			}
			vt->asObjectList(list);
			break;
		}
	default:
		ASSERT_FAIL(FORMAT_ARGS("CorbaScriptDataAdaptor::GetVariableType - Script type (%d) not handled", fScriptData.GetType()));
	}

	return vt;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetVariableType
//----------------------------------------------------------------------------------------

VariableType_var CorbaScriptDataAdaptor::GetVariableType(const ScriptEnv& env, const long& nth) const
{
	VariableType_var vt = new VariableType();

	switch (fScriptData.GetType())
	{
	case ScriptData::s_empty:		vt->empty(true);								break;
	case ScriptData::s_boolean:		vt->asBoolean(GetBoolean(env, nth));			break;
	case ScriptData::s_string:		vt->asString(GetString(env, nth));				break;
//	case ScriptData::s_shortint:	vt->asShort(GetShort(env, nth));				break;
	case ScriptData::s_longint:		vt->asLong(GetLong(env, nth));					break;
//	case ScriptData::s_longlongint:	vt->asLongLong(GetLongLong(env, nth));			break;
	case ScriptData::s_double:		vt->asDouble(GetDouble(env, nth));				break;
	case ScriptData::s_object:		vt->asObject(GetObject(env, nth));				break;
	case ScriptData::s_date:		vt->asDate(GetDate(env, nth));					break;
	case ScriptData::s_file:		vt->asFile(GetFile(env, nth));					break;
	case ScriptData::s_enumeration:	vt->asEnumeration(GetEnumeration(env, nth));	break;
	case ScriptData::s_unit:		vt->asUnit(GetUnit(env, nth));					break;
	case ScriptData::s_list:
		{
			ScriptListData scriptListData;
			if (fScriptData.GetList(scriptListData) == kSuccess)
			{
				CorbaScriptDataAdaptor adaptor;
				adaptor.SetScriptData(scriptListData[nth]);
				vt = adaptor.GetVariableType(env);
			}
			break;
		}
	case ScriptData::s_objectlist:
		{
			framework::SObject_var object = GetObject(env, nth);
			vt->asObject(object);
			break;
		}
	default:
		ASSERT_FAIL(FORMAT_ARGS("CorbaScriptDataAdaptor::GetVariableType - Script type (%d) not handled", fScriptData.GetType()));
	}

	return vt;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetFile
//----------------------------------------------------------------------------------------

CORBA::WChar* CorbaScriptDataAdaptor::GetFile(const ScriptEnv& env, const long& nth) const
{
	IDFile result;

	if (fScriptData.GetType() == ScriptData::s_file)
	{
		if (nth == 0)
			fScriptData.GetFile(&result);
	}
	else if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
		{
			if (nth < scriptListData.size())
			{
				if (scriptListData[nth].GetType() == ScriptData::s_file)
					scriptListData[nth].GetFile(&result);
			}
		}
		else
			ASSERT_FAIL("CorbaScriptDataAdaptor::GetFile - couldn't get the list");
	}

	return CreateCorbaString(PMString(result.GetPath(false).GrabWString(), result.GetPath(false).UTF16Count()));
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::GetItemCnt
//----------------------------------------------------------------------------------------

long CorbaScriptDataAdaptor::GetItemCnt(const ScriptEnv& env) const
{
	long cnt = 0;

	if (fScriptData.GetType() == ScriptData::s_list)
	{
		ScriptListData scriptListData;
		if (fScriptData.GetList(scriptListData) == kSuccess)
			cnt = scriptListData.size();
	}
	else if (fScriptData.GetType() == ScriptData::s_objectlist)
	{
		ScriptList scriptList;
		if (fScriptData.GetObjectList(scriptList) == kSuccess)
			cnt = scriptList.size();
	}
	else
		cnt = 1;

	return cnt;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendObject
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendObject(const ScriptEnv& env, framework::SObject_ptr object, const bool& useList)
{
	if (CORBA::is_nil(object))
	{
		fScriptData.SetObject(NULL);
		if (useList)
			fScriptListData.push_back(fScriptData);
	}
	else
	{
		ScriptList	resolvedObjects;
		CORBA::String_var objectSpecifier = object->getObjectSpecifier();
		if (Utils<IScriptUtils>()->ResolveSpecifier(env.GetRequestContext(), PMString(objectSpecifier), resolvedObjects) == kSuccess)
		{
			fScriptData.SetObject(resolvedObjects[0]);
			if (useList)
				fScriptListData.push_back(fScriptData);
		}
	}
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendEnumeration
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendEnumeration(const ScriptEnv& env, const CORBA::Long& value, const bool& useList)
{
	fScriptData.SetEnumeration(ScriptID(value));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendShort
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendShort(const ScriptEnv& env, const CORBA::Short& value, const bool& useList)
{
	fScriptData.SetInt16(int16(value));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendLong
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendLong(const ScriptEnv& env, const CORBA::Long& value, const bool& useList)
{
	fScriptData.SetInt32(int32(value));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendLongLong
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendLongLong(const ScriptEnv& env, const CORBA::LongLong& value, const bool& useList)
{
	fScriptData.SetInt64(int64(value));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendBoolean
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendBoolean(const ScriptEnv& env, const CORBA::Boolean& value, const bool& useList)
{
	fScriptData.SetBoolean(bool16(value));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendDouble
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendDouble(const ScriptEnv& env, const CORBA::Double& value, const bool& useList)
{
	fScriptData.SetPMReal(PMReal(value));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendUnit
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendUnit(const ScriptEnv& env, const com::adobe::ids::Unit& unit, const bool& useList)
{
	switch (unit._d())
	{
		case kUnitString:		AppendString(env, unit.asString(), useList);				break;
		case kUnitDouble:		AppendDouble(env, unit.asDouble(), useList);				break;
		default:
			ASSERT_FAIL("Unknown Unit type");
	}
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendDate
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendDate(const ScriptEnv& env, const com::adobe::ids::DateType& date, const bool& useList)
{
	uint64 idDateTime = UnixTimeToIDTime( uint64(date));
	fScriptData.SetDate(idDateTime);
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendString
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendString(const ScriptEnv& env, const CORBA::WChar* string, const bool& useList)
{
	PMString idStr = CorbaToPMString(string);
	Utils<IScriptUtils>()->TranslateKeyStringFromScriptClient( idStr ) ;

	fScriptData.SetPMString(idStr);
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendVariableType
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendVariableType(const ScriptEnv& env, const com::adobe::ids::VariableType& vt, const bool& useList)
{
	switch (vt._d())
	{
	case kLongInt:		AppendLong(env, vt.asLong(), useList);					break;
	case kBoolean:		AppendBoolean(env, vt.asBoolean(), useList);			break;
	case kString:		AppendString(env, vt.asString(), useList);				break;
	case kFile:			AppendFile(env, vt.asFile(), useList);					break;
	case kDouble:		AppendDouble(env, vt.asDouble(), useList);				break;
	case kUnit:			AppendUnit(env, vt.asUnit(), useList);					break;
	case kObject:		AppendObject(env, vt.asObject(), useList);				break;
	case kDate:			AppendDate(env, vt.asDate(), useList);					break;
	case kEnumeration:	AppendEnumeration(env, vt.asEnumeration(), useList);	break;
	case kList:
		{
			if (useList)
			{
				CorbaScriptDataAdaptor itemAdaptor;
				itemAdaptor.AppendVariableType(env, vt, false);
				fScriptListData.push_back(itemAdaptor.GetScriptData());
			}
			else
				AppendList(env, vt.asList(), useList);
		}				
		break;

	case kObjectList:	AppendObjectList(env, vt.asObjectList(), useList);		break;
	default:
		ASSERT_FAIL(FORMAT_ARGS("CorbaScriptDataAdaptor::AppendVariableType - Corba type (%d) not handled", vt._d()));
	}
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendList
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendList(const ScriptEnv& env, const List& list, const bool& useList)
{
	for (CORBA::ULong i = 0; i < list.length(); i++)
	{
		CorbaScriptDataAdaptor itemAdaptor;
		itemAdaptor.AppendVariableType(env, list[i], useList);
		fScriptListData.push_back(itemAdaptor.GetScriptData());
	}
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendObjectList
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendObjectList(const ScriptEnv& env, const ObjectList& objectList, const bool& useList)
{
	ScriptList list;

	for (CORBA::ULong i = 0; i < objectList.length(); i++)
	{
		ScriptList	resolvedObjects;
		CORBA::String_var objectSpecifier = objectList[i]->getObjectSpecifier();
		if (Utils<IScriptUtils>()->ResolveSpecifier(env.GetRequestContext(), PMString(objectSpecifier), resolvedObjects) == kSuccess)
			list.push_back(resolvedObjects[0]);
	}

	fScriptData.SetObjectList(list);
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendFile
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendFile(const ScriptEnv& env, const CORBA::WChar* file, const bool& useList)
{
	PMString fileName = CorbaToPMString(file);
	fileName.SetTranslatable(kFalse);

	fScriptData.SetFile(IDFile(AString(fileName.GrabUTF16Buffer(NULL))));
	if (useList)
		fScriptListData.push_back(fScriptData);
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::AppendRange
//----------------------------------------------------------------------------------------

void CorbaScriptDataAdaptor::AppendRange(const ScriptEnv &env, const com::adobe::ids::VariableType& from, const com::adobe::ids::VariableType& to, const bool& useList)
{
	if (from._d() == kLongInt && to._d() == kLongInt)
	{
		AppendVariableType(env, from, true);
		AppendVariableType(env, to, true);
	}
	else if (from._d() == kString && to._d() == kString)
	{
		AppendVariableType(env, from, true);
		AppendVariableType(env, to, true);
	}
	else if (from._d() == kObject && to._d() == kObject)
	{
		AppendVariableType(env, from, true);
		AppendVariableType(env, to, true);
	}
	else
		ASSERT_FAIL(FORMAT_ARGS("CorbaScriptDataAdaptor::AppendRange - Corba type (%d) not handled", from._d()));
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::CreateCorbaString
//----------------------------------------------------------------------------------------

CORBA::WChar* CorbaScriptDataAdaptor::CreateCorbaString(const PMString& string) const
{
	CORBA::WChar* result = CORBA::wstring_alloc(string.WCharLength() + 1);
	string.GetWChar_tString(result, string.WCharLength() + 1);
	return result;
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::IDTimeToUnixTime
//----------------------------------------------------------------------------------------

uint64 CorbaScriptDataAdaptor::IDTimeToUnixTime(const uint64 number) const
{
	uint64 unixTime = number; 
	unixTime /= TIME_CONVERSION;
	unixTime -= TIME_BIAS;
	return unixTime; 
}

//----------------------------------------------------------------------------------------
// CorbaScriptDataAdaptor::UnixTimeToIDTime
//----------------------------------------------------------------------------------------

uint64 CorbaScriptDataAdaptor::UnixTimeToIDTime(const uint64 number) const
{
	// convert from Unix time in msec to NT time
	uint64 idTime = number;
	idTime += TIME_BIAS;
	idTime *= TIME_CONVERSION ;
	return idTime; 
}