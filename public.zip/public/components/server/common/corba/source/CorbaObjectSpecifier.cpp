//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/CorbaObjectSpecifier.cpp $
//  
//  Owner: Jonathan W. Brown
//  
//  $Author: boshea $
//  
//  $DateTime: 2008/08/26 11:49:43 $
//  
//  $Revision: #2 $
//  
//  $Change: 645565 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"
#include "CorbaObjectSpecifier.h"

#include "IScript.h"
#include "IScriptUtils.h"

PortableServer::ObjectId* CorbaObjectSpecifier::CreateCorbaObjectId( const CorbaObjectSpecifier* objectSpecifier )
{
	PMString coreSpecifierID ;
	coreSpecifierID.AsNumber( objectSpecifier->GetID() ) ;
	return PortableServer::string_to_ObjectId( coreSpecifierID.GrabCString() ) ;
}

const CorbaObjectSpecifier* CorbaObjectSpecifier::ParseCorbaObjectId( const PortableServer::ObjectId& oid )
{
	CORBA::String_var objectId = PortableServer::ObjectId_to_string(oid);
//	PMString coreSpecifierID ;
//	coreSpecifierID.SetCString( objectId.in() ) ;
//	const int32 id = coreSpecifierID.GetAsNumber() ;
	const int32 id = std::strtol(objectId.in(), NULL, 10);	// can't use PMString, since this code gets called from a thread & PMString isn't thread safe
	for ( K2Vector<CorbaObjectSpecifier*>::const_iterator iter = fActiveCorbaObjects.begin() ; iter != fActiveCorbaObjects.end() ; ++iter )
	{
		if ( (*iter)->GetID() == id )
		{
			(*iter)->AddRefFromClient() ;
			return *iter ;
		}
		if ( (*iter)->GetID() > id )	//fActiveCorbaObjects is sorted in ascending order by id
			break ;
	}
	return nil ;
}


int32 CorbaObjectSpecifier::fNextID = 1 ;
K2Vector< CorbaObjectSpecifier* > CorbaObjectSpecifier::fActiveCorbaObjects ;

CorbaObjectSpecifier::CorbaObjectSpecifier( IScript* script, const EngineContext& context ) :
	fID( fNextID++ ),
	fRefCount( 1 ),
	fScript( script ),
	fContext( context ),
	fObjectType()
{
	fActiveCorbaObjects.push_back( this ) ;
	//ASSERT( fScript ) ;	//could be nil for a null object
	if ( fScript )
	{
		fObjectType = fScript->GetObjectType( context ).Get() ;	//cache it to avoid calling QueryInterface from non-main thread
		fScript->AddRef() ;
		fScript->RegisterClientObject( this ) ;
	}
}

CorbaObjectSpecifier::~CorbaObjectSpecifier()
{
	ASSERT( fScript == nil ) ;	//otherwise someone should be holding a reference to this object
	fActiveCorbaObjects.erase( std::find( fActiveCorbaObjects.begin(), fActiveCorbaObjects.end(), this ) ) ;
}

//If the only thing holding this instance is its target objects, 
//release them so this instance will destruct (#1578671)
void CorbaObjectSpecifier::ReleaseRefFromClient() const
{
/*	//CORBA doesn't hold a reference on this object between calls, 
	//so we can't assume this object is no longer needed
	if ( fScript != nil && fRefCount == 2 )
		ReleaseReferencesToObjectModel( fScript ) ;
*/	Release() ;
}

void CorbaObjectSpecifier::ReleaseReferencesToObjectModel( IScript* script )
{
	ASSERT( script == fScript ) ;
	if ( fScript )
	{
		fScript->UnregisterClientObject( this ) ;
		fScript->Release() ;
		fScript = nil ;
	}
}

PMString CorbaObjectSpecifier::GetCoreSpecifier() const
{
	PMString coreSpecifier ;
	if ( fScript )
		Utils<IScriptUtils>()->GenerateSpecifier( fContext, fScript, coreSpecifier ) ;
	return coreSpecifier ;
}

IScript* CorbaObjectSpecifier::QueryScript() const
{
	if ( fScript )
		fScript->AddRef() ;
	return fScript ;
}
