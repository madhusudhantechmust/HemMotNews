//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/com/adobe/ids/VariableTypeUtils.java $
//  
//  Owner: Kirk Mattson
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

package com.adobe.ids;

import com.adobe.ids.VariableType;
import com.adobe.ids.Unit;
import com.adobe.ids.framework.SObject;

/**
 * @author mburbidg
 *
 * Utility class for creating VariableType objects.
 */
public class VariableTypeUtils {
	
	/**
	 * Get createEmpty
	 * @return A variable type that wraps nothing
	 */
	public static VariableType createEmpty() {
       	VariableType vt = new VariableType();
       	vt.empty(false);
       	return vt;
	}
	
	/**
	 * Get createBoolean
	 * @param value the boolean value
	 * @return A variable type that wraps a boolean value
	 */
	public static VariableType createBoolean(boolean value) {
       	VariableType vt = new VariableType();
       	vt.asBoolean(value);
       	return vt;
	}
	
	/**
	 * Get createBooleanList
	 * @param values an array of boolean values
	 * @return A variable type that wraps a list of boolean values
	 */
	public static VariableType createBooleanList(boolean values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createBoolean(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createDate
	 * @param date the date value
	 * @return A variable type that wraps a date value
	 */
	public static VariableType createDate(long date) {
       	VariableType vt = new VariableType();
       	vt.asDate(date);
       	return vt;
	}
	
	/**
	 * Get createDateList
	 * @param dates an array of longs representing dates
	 * @return A variable type that wraps a list of dates
	 */
	public static VariableType createDateList(long dates[]) {
		VariableType list[] = new VariableType[dates.length];
		for (int i = 0; i < dates.length; i++)
			list[i] = createDate(dates[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createDouble
	 * @param value the double value
	 * @return A variable type that wraps a double value
	 */
	public static VariableType createDouble(double value) {
       	VariableType vt = new VariableType();
       	vt.asDouble(value);
       	return vt;
	}
	
	/**
	 * Get createDoubleList
	 * @param values an array of doubles
	 * @return A variable type that wraps a list of doubles
	 */
	public static VariableType createDoubleList(double values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createDouble(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createUnit
	 * @param value a value in units
	 * @return A variable type that wraps a unit
	 */
	public static VariableType createUnit(Unit value) {
       	VariableType vt = new VariableType();
       	vt.asUnit(value);
       	return vt;
	}
	
	/**
	 * Get createUnitList
	 * @param values an array of units
	 * @return A variable type that wraps a list of units
	 */
	public static VariableType createUnitList(Unit values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createUnit(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createEnumeration
	 * @param value an int representation of an enumeration value
	 * @return A variable type that wraps an enumeration
	 */
	public static VariableType createEnumeration(int value) {
       	VariableType vt = new VariableType();
       	vt.asEnumeration(value);
       	return vt;
	}
	
	/**
	 * Get createEnumerationList
	 * @param values an array of ints representing enumeration values
	 * @return A variable type that wraps a list of enumerations
	 */
	public static VariableType createEnumerationList(int values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createEnumeration(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createFile
	 * @param file the file
	 * @return A variable type that wraps the file
	 */
	public static VariableType createFile(String file) {
       	VariableType vt = new VariableType();
       	vt.asFile(file);
       	return vt;
	}
	
	/**
	 * Get createFileList
	 * @param values an array of strings representing files
	 * @return A variable type that wraps a list of files
	 */
	public static VariableType createFileList(String values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createFile(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createLong
	 * @param value the value
	 * @return A variable type that wraps a long value
	 */
	public static VariableType createLong(int value) {
       	VariableType vt = new VariableType();
       	vt.asLong(value);
       	return vt;
	}
	
	/**
	 * Get createLongList
	 * @param values an array of int values
	 * @return A variable type that wraps a list of long values
	 */
	public static VariableType createLongList(int values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createLong(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createString
	 * @param string the string
	 * @return A variable type that wraps a string
	 */
	public static VariableType createString(String string) {
       	VariableType vt = new VariableType();
       	vt.asString(string);
       	return vt;
	}
	
	/**
	 * Get createStringList
	 * @param values an array of strings
	 * @return A variable type that wraps a list of strings
	 */
	public static VariableType createStringList(String values[]) {
		VariableType list[] = new VariableType[values.length];
		for (int i = 0; i < values.length; i++)
			list[i] = createString(values[i]);
       	VariableType vt = new VariableType();
       	vt.asList(list);
       	return vt;
	}
	
	/**
	 * Get createObject
	 * @param object the object
	 * @return A variable type that wraps an object
	 */
	public static VariableType createObject(SObject object) {
       	VariableType vt = new VariableType();
       	vt.asObject(object);
       	return vt;
	}
	
	/**
	 * Get createList
	 * @param value an array of variable types
	 * @return A variable type that wraps a list of variable types
	 */
	public static VariableType createList(VariableType value[]) {
       	VariableType vt = new VariableType();
       	vt.asList(value);
       	return vt;
	}
	
	/**
	 * Get createObjectList
	 * @param value an array of objects
	 * @return A variable type that wraps a list of objects
	 */
	public static VariableType createObjectList(SObject value[]) {
       	VariableType vt = new VariableType();
       	vt.asObjectList(value);
       	return vt;
	}
}
