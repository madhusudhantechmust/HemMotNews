//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/com/adobe/ids/UnitUtils.java $
//  
//  Owner: Kirk Mattson
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

package com.adobe.ids;

import com.adobe.ids.Unit;

/**
 * @author mburbidg
 *
 * Utility class for creating Unit objects.
 */
public class UnitUtils {

	/**
	 * Get createEmpty
	 * @return A variable type that wraps nothing
	 */
	public static Unit createEmpty() {
       	Unit unit = new Unit();
       	unit.empty(false);
       	return unit;
	}

	/**
	 * Create a Unit from a double
	 * @param value the double value
	 * @return A variable type that wraps a double value
	 */
	public static Unit createDouble(double value)
	{
		Unit unit = new Unit();
		unit.asDouble(value);
		return unit;
	}

	/**
	 * Create a Unit array from a double array
	 * @param values an array of the double values
	 * @return A variable type that wraps a double value
	 */
	public static Unit[] createDouble(double[] values)
	{
		Unit[] units = new Unit[values.length];
		for (int i = 0; i < values.length; i++)
			units[i] = UnitUtils.createDouble(values[i]);
		return units;
	}

	/**
	 * Create a Unit from a String
	 * @param string the string
	 * @return A variable type that wraps a string
	 */
	public static Unit createString(String string)
	{
		Unit unit = new Unit();
		unit.asString(string);
		return unit;
	}

	/**
	 * Create a Unit array from a String array
	 * @param values an array of the double values
	 * @return A variable type that wraps a double value
	 */
	public static Unit[] createString(String[] values)
	{
		Unit[] units = new Unit[values.length];
		for (int i = 0; i < values.length; i++)
			units[i] = UnitUtils.createString(values[i]);
		return units;
	}
}
