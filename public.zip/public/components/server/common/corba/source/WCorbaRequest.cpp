//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/WCorbaRequest.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPlugInHeaders.h"

// ----- Interface Includes -----

#include "WCorbaRequest.h"

// ----- Implementation Includes -----

//========================================================================================
// METHODS CorbaRequest
//========================================================================================

//----------------------------------------------------------------------------------------
// CorbaRequest::CorbaRequest
//----------------------------------------------------------------------------------------

CorbaRequest::CorbaRequest() :
	fMainThreadId(::GetCurrentThreadId()),
	fMsg(0)
{
}

//----------------------------------------------------------------------------------------
// CorbaRequest::~CorbaRequest
//----------------------------------------------------------------------------------------

CorbaRequest::~CorbaRequest()
{
}

//----------------------------------------------------------------------------------------
// CorbaRequest::WakeupEventLoop
//----------------------------------------------------------------------------------------

void CorbaRequest::WakeupEventLoop() const
{
	// ---- This message wakes up the main event loop, so the idle tasks will get
	//		processed. The main event loop does not do anything special with
	//		this message.

	if (fMsg == 0)
	{
		fMsg = RegisterWindowMessage(L"com.adobe.ids.CorbaRequest");
	}
	PostThreadMessage(fMainThreadId, fMsg, 0, 0);
}

