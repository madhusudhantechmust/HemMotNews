//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/source/ScriptEnv.cpp $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"
#include "ScriptEnv.h"

#include "IScriptManager.h"
#include "IScriptUtils.h"

#include "CorbaUtilsID.h"
#include "ActiveScriptState.h"

ScriptEnv::ScriptEnv() :
	fScriptEngine(NULL),
	fActiveScriptState(NULL),
	fRequestContext(NULL)
{
	InterfacePtr<IScriptManager> scriptMgr( Utils<IScriptUtils>()->QueryScriptManager( kCorbaAPIScriptMgrBoss ) ) ;
	fScriptEngine = scriptMgr->QueryDefaultEngine() ;
	fActiveScriptState = new ActiveScriptState( fScriptEngine ) ;
	fRequestContext = new ScriptInfo::EngineContext( fScriptEngine->GetRequestContext() ) ;
}

ScriptEnv::~ScriptEnv()
{
	fScriptEngine->Release();
	fScriptEngine = NULL;

	delete fRequestContext;
	fRequestContext = NULL;

	delete fActiveScriptState;
	fActiveScriptState = NULL;
}

IScriptEventData* ScriptEnv::CreateScriptEventData() const
{
	return fScriptEngine->CreateScriptEventData() ;
}
