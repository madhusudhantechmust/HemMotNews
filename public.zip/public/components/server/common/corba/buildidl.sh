#!/bin/sh

if [ $# -lt 1 -o $# -gt 1 ] 
  then
    echo "Usage: buildidl debug|release " 1>&2
    exit 1
fi

mkdir -p gen/$1/stubs

ARCH_RESULT=`arch`

if [ $ARCH_RESULT = "i386" ] 
  then
     ARCH=universal_mac
  elif [ $ARCH_RESULT = "ppc" ]
     then
        ARCH=powerpc_mac
  else
     echo "UNKNOWN MACINTOSH ARCHITECTURE. BUILD FAILED."
     exit 1
fi

echo ARCH=$ARCH

make -j 3 TARGET=$1 IDLC=$OMNIORB_HOME/bin/omniidl IDLJ=../../tools/adobeidlj/adobeIdlj

if [ $? != 0 ]
then
  echo "IDL BUILD FAILED"
  exit 1
else  
  echo "IDL BUILD SUCCESSFUL"
  exit 0
fi

