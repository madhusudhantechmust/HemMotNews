#!/usr/bin/perl
#//========================================================================================
#//  
#//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/common/corba/bldCHM.pl $
#//  
#//  Owner: Heath Lynn
#//  
#//  $Author: pmbuilder $
#//  
#//  $DateTime: 2008/08/18 15:33:07 $
#//  
#//  $Revision: #1 $
#//  
#//  $Change: 643572 $
#//  
#//  Copyright 2006 Adobe Systems Incorporated. All rights reserved.
#//  
#//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
#//  with the terms of the Adobe license agreement accompanying it.  If you have received
#//  this file from a source other than Adobe, then your use, modification, or 
#//  distribution of it requires the prior written permission of Adobe.
#//  
#//  
#//  Purpose: This script builds a chm file from the JavaDocs.  It runs on Windows only. 
#//	
#//  How it works: 
#//  	After IDS CORBA JavaDocs are created you can run this script to create the 
#//  	files needed to create a chm.  This includes project (.hpp), index (.hhk), and table of contents files (.hhc).
#//
#//  	If the script finds the chm compiler in it's default location (c:\\Program Files\\HTML Help Workshop\\hhc.exe), 
#//		it will create the chm file.
#//		
#//		The chm related files are first created in the gen\target folder, and then moved to the gen\target\chm folder.
#//		This is done because the chm has to be generated at the top level of its contents, that means the .chm has
#//		to be generated above the javadoc folder.  When the .chm is compiled, then it can be moved and used anywhere.
#//
#//  For more help run:
#//		bldCHM.pl -h
#//  
#//========================================================================================


use Getopt::Std;
use Cwd;
use File::Basename;
use File::Path;
use File::Copy;

use strict;
use warnings;

my $WINDOWS = $^O eq "MSWin32";
my $SLASHSEPARATOR = $WINDOWS ? "\\" : "/";
my $HHC_PATH = "c:\\Program Files\\HTML Help Workshop\\hhc.exe";
my $BASENAME = "InDesignServerAPIRef";
my $JAVADOC_PATH = "javadoc";


sub Usage
{
	print STDERR "\tbuild a chm file from gen/<target>/javadoc\n";
	print STDERR "Usage: bldCHM.pl -[d|r]\n";
	print STDERR "Or:      bldCHM.pl <target>\n";
	print STDERR "\nOptions:\n";
	print STDERR "\t-d\tBuild debug target\n";
	print STDERR "\t-h\tDisplay this help message.\n";
	print STDERR "\t-r\tBuild release target\n";
	exit -1;
}

if( !$WINDOWS )
{
	die "This script is written to run on Windows only!";
}

# Handle Arguments
#
my $opt_string = 'dhr';
getopts( "$opt_string", \my %opt ) or Usage();
if( $opt{h} ) {
	Usage();
}

my @targets;
if( $opt{d} ) {
	push( @targets, "debug" );
}

if( $opt{r} ) {
	push( @targets, "release" );
}

if( @ARGV == 1 )
{
	if( uc($ARGV[0]) eq "DEBUG") {
		push( @targets, "debug" );
	}

	if( uc($ARGV[0]) eq "RELEASE") {
		push( @targets, "release" );
	}
}

if( @targets < 1 )
{
	print STDERR "Incorrect usage!\n";
	Usage();
}

foreach my $target( @targets )
{
	my $cwd = cwd;

	print "Creating chm project files...\n";

	# chdir to the output dir:   "gen\release" or "gen\debug"
	my $outputDir = "gen" . $SLASHSEPARATOR . $target;
	chdir $outputDir or die "Failed to chdir to $outputDir";
	$outputDir = cwd;		# store absolute path.


	#copy the static folder items to the output folder so the .gif and .css file can be found by the chm compiler
	if (! -e "static") {
		mkdir("static", 0755);
	}
	copy("$cwd/static/ids-sdk.gif", "$outputDir/static/ids-sdk.gif");
	copy("$cwd/static/adobe.css", "$outputDir/static/adobe.css");


	# open output files (.hhp, .hhc, .hhk) in output folder.
	my ($PROJECT, $TOC, $INDEX);
	open( $PROJECT, ">$BASENAME.hhp") or die "Failed to open $BASENAME.hhp for writing";
	open( $TOC, ">$BASENAME.hhc") or die "Failed to open $BASENAME.hhc for writing";
	open( $INDEX, ">$BASENAME.hhk") or die "Failed to open $BASENAME.hhk for writing";


	# Write the top/static part of these files
	WriteProjectStart($PROJECT);
	WriteTOCStart($TOC);
	WriteIndexStart($INDEX);
	

	# Write the bottom/dynamic part of these files
	chdir "$JAVADOC_PATH" or die "Failed to chdir to $JAVADOC_PATH";
	MakeHTMLHelpFiles($JAVADOC_PATH . $SLASHSEPARATOR . "com", $PROJECT, $TOC, $INDEX) or die "Failed in MakeHTMLHelpFiles";


	# close the files
	CloseProject( $PROJECT );
	CloseTOC( $TOC );
	CloseIndex( $INDEX );

	
	# Compile the CHM
	# make sure HTML Help Workshop is installed
	if( !-e $HHC_PATH ){
		print "Cannot compile the chm file.  HTML Help Workshop must be installed to:  $HHC_PATH\n";
 	} 
 	else 
	{
		chdir $outputDir or die "Failed to chdir back to $outputDir.";
		my $projectFilePath = $BASENAME . ".hhp";
		if( -e $projectFilePath  )
		{
			# call HTML Help Workshop to compile the chm
			print "Compiling the chm file...\n";
			system("\"$HHC_PATH\" $projectFilePath 1>hhc-out.txt 2>hhc-err.txt");

			# move all the chm-related files to the chm folder
			my $chmFolder = "chm";
			if (! -e $chmFolder) {
				mkdir($chmFolder, 0755) || die "Cannot mkdir $outputDir/$chmFolder: $!\n";
			}
			move("$BASENAME.chm", "$chmFolder\\$BASENAME.chm");
			move("$BASENAME.hhp", "$chmFolder\\$BASENAME.hhp");
			move("$BASENAME.hhc", "$chmFolder\\$BASENAME.hhc");
			move("$BASENAME.hhk", "$chmFolder\\$BASENAME.hhk");
			move("hhc-out.txt", "$chmFolder\\hhc-out.txt");
			move("hhc-err.txt", "$chmFolder\\hhc-err.txt");
 		} 
 		else 
 		{
			print "Could not open $projectFilePath";
		}
	}
	

	chdir $cwd or die "Failed to chdir back to $cwd.";
}


sub WriteProjectStart
{
	my $project = $_[0];
	my $str = << "END";

[OPTIONS]
Compatibility=1.1 or later
Compiled file=BASENAME.chm
Contents file=BASENAME.hhc
Default topic=JAVADOC_PATH\\overview-summary.html
Display compile progress=Yes
Full-text search=Yes
Index file=BASENAME.hhk
Language=0x409 English (United States)
Title=Overview (Adobe InDesign CS3 Server CORBA API)


[FILES]
JAVADOC_PATH\\overview-summary.html
END

$str =~ s/BASENAME/$BASENAME/g;
$str =~ s/JAVADOC_PATH/$JAVADOC_PATH/g;
print $project "$str";

}

sub CloseProject
{
	my $project = $_[0];
	print $project "\n[INFOTYPES]\n\n";
	close $project;
}

sub WriteTOCStart
{
	my $toc = $_[0];
	my $str = << "END";

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!--Sitemap 1.0-->
</HEAD>
<BODY>
<OBJECT type="text/site properties"><param name="ImageType" value="Folder"></OBJECT><UL>
END

	print $toc "$str";
}

sub CloseTOC
{
	my $toc = $_[0];
	my $str = << "END";
</UL>
</BODY>
</HTML>
END

	print $toc "$str";
	close $toc;
}

sub WriteIndexStart
{
	my $index = $_[0];
	my $str = << "END";
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML><HEAD></HEAD><BODY>
<OBJECT type="text/site properties">
<param name="FrameName" value="right">
</OBJECT>
<UL>
END
	print $index "$str";
}

sub CloseIndex
{
	my $index = $_[0];
	my $str = << "END";
</UL>
</BODY>
</HTML>
END
	print $index "$str";
	close $index;
}

sub mySort
{
	my $str1 = uc($a);
	my $str2 = uc($b);
	
	if ( $str1 =~ /^\W/ && $str2 =~ /^\w/) {
		return -1;
	}
	elsif ($str1 =~ /^\w/ && $str2 =~ /^\W/) {
		return 1;
	}

	return $str1 cmp $str2;
};

sub ExpandMethods
{
	my $index = $_[0];
	my $file = $_[1];
	my $dir = $_[2];
	my $class = GetClassFromFile($file);


	my $filecontents = "";
	ReadEntireFileIntoString( $file, \$filecontents );


	# To keep the index working I want to remove
	# all spaces between commas in quotes
	while($filecontents =~ s/(HREF|NAME)(\s*=\s*\")([^\ \t\"]+)([\ \t]+)([^\"]+)(\")/$1$2$3$5$6/ig)
	{
		# do nothing
	}



	# only use the METHOD SUMMARY Table in the .html file to create the index.
	my $methodsummary = $filecontents;
	
	# remove text before the "METHOD SUMMARY" comment.  Use /s to deal with new lines.
	$methodsummary =~ s/.*METHOD SUMMARY//s;

	# remove all text after the </TABLE> tag designating the end of the method summary table.
	$methodsummary =~ s/<\/TABLE>.*//s;



	my @lines = split(/\n/, $methodsummary);

	my $foundAMethod = 0;

	foreach my $line( @lines )
	{
		while($line =~s/HREF\s*=\s*\"(.+?#.+?\(.*?\))\">\s*(.+?)\s*<\/A>/REPLACED/)
		{
			my $method = $2;
			chomp $method;

			if( $method eq $class ) {
				$method .= " constructor";
			}

			my $url = $1;
			chomp $url;

			# if windows - replace forward slashes with back slashes
			$url =~ s/\//\\/g;

			# replace relative path (..\..) with absolute path
			$url =~ s/.*\\com/$dir/;
			
			if( ! $foundAMethod ) {
				print $index "  <UL>\n";
				$foundAMethod = 1;
			}
				
			print $index "     <LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"$method\"><param name=\"Local\" value=\"$url\"></OBJECT>\n";
		}
	}

	if( $foundAMethod ) {
		print $index "  </UL>\n";

		#  Rewrite the .html file using the fixed spaces between commas in quotes, so the index functions properly.
		open (OUT, ">$file" ) or return; # error
		print OUT "$filecontents";
		close OUT;
	}

      return 1;
}


sub MakeHTMLHelpFiles
{
	my $dir = $_[0];
	my $project = $_[1];
	my $toc = $_[2];
	my $index = $_[3];

	# determine package
	my $package = $dir;
	$package =~ s/[\/\\]/\./g;
	$package =~ s/.*(com.*)/$1/;


	# determine base directory
	my $basedir = substr($dir, 0, index($dir, "\\com") + 4);


	# chdir to package dir if it's not a file type we don't care about
	my @dirParts = split( /\\|\//, $dir);
	my $workingDir = $dirParts[$#dirParts] ; 
 
	if( $workingDir =~ /\-use/ || $workingDir =~ /\-frame/ )
	{
		return 1;
	}

	chdir ($workingDir) or die "Failed to chdir to $workingDir";

	if( -f "package-summary.html" )
	{
		print $project "$dir" . $SLASHSEPARATOR ."package-summary.html\n";
		print $toc "<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"$package\"><param name=\"Local\" value=\"$dir" . $SLASHSEPARATOR . "package-summary.html\"></OBJECT><UL>\n";
	}

	
	
	# glob files
	my @files = glob("*.html");
	@files = sort mySort @files;

	# process files
	foreach my $file (@files)
	{
		if( $file eq "package-summary.html" || $file =~ /-use|-frame|-tree/ ) {
			next;
		}
		
		my $class = GetClassFromFile($file);
		my $expandedFile = "$dir" . $SLASHSEPARATOR ."$file";
		print $project "$expandedFile\n";
		print $toc "<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"$class\"><param name=\"Local\" value=\"$expandedFile\"></OBJECT></LI>\n";
		print $index "<LI><OBJECT type=\"text/sitemap\"><param name=\"Name\" value=\"$class\"><param name=\"Local\" value=\"$expandedFile\"></OBJECT>\n";
		ExpandMethods($index, $file, $basedir) or die "Failed to expand methods for $file";
	}

	if( -f "package-summary.html" )
	{
		print $toc "</UL>\n</LI>\n";
	}

	# process dirs
	@files = glob("*");
	foreach my $file (@files)
	{
		if( -d $file )
		{
			MakeHTMLHelpFiles($dir . $SLASHSEPARATOR . $file, $project, $toc, $index) or die "Failed in MakeHTMLHelpFiles on $file.";
		}
	}

	chdir ("..");
}

sub GetClassFromFile
{
	my $class = $_[0];
	$class =~ s/\.html//i;
	return $class;
}

sub ReadEntireFileIntoString
{

	# Open the file
	my $file = $_[0];
	my $str = $_[1];
	
	open (IN, "<$file" ) or return; # error

	# Save the input record seperator
	my $savedRecordSeperator = $/;

	# Undefine the input record seperator
	$/ = undef;

	# Read the file 
	$$str = <IN>;

	# restore the input record seperator
	$/ = $savedRecordSeperator;

	# Close the file
	close IN;

	return 1;
}

