#!/bin/sh

usage()
{
    echo ""
    echo "Usage: corba.sh debug|release [-home=/absolute/path/to/InDesignServer/home ] [-nojavadoc] [-nojava] [-noservant] [-nogen]"
    echo ""
    echo "Use one of \"debug\" or \"release\". "
	echo "Use the \"-home\" argument to specify the absolute directory to an InDesignServer root directory."
    echo "Use \"-nojavadoc\" to prevent javadoc generation."
	echo "Use \"-nojava\" to prevent compiling the java stubs."
	echo "Use \"-noservant\" to prevent compiling the CORBA Support plug-in."
	echo "Use \"-nogen\" to skip to after the InDesignServer corba source generation step."
    echo ""
    echo ""
    echo "CORBA API BUILD FAILED"
    exit 1
}

checkerrors()
{
  if [ $? != 0 ]
  then
    if [ "$XPWD" ]
    then
      cd "$XPWD"
    fi
    echo "CORBA API BUILD FAILED"
    exit 1
  fi
}

PRODUCT=indesignserver
TARGET=debug
PRODUCT_PRJ=CorbaSupport.xcodeproj
NAMESPACE=com.adobe.ids
HOMEDIR=no
JAVA=yes
JAVADOC=yes
SERVANT=yes
GENERATECORBA=yes
CREATE_SCRIPTS_DIR=no

if [[ $# -eq 0 ]]
then
   echo "Configuration [debug | release] required"
   usage
fi


actual_num_params=0
while [[ "$1" != "" ]] 
do
	if [[ "$LONGPARAM" = "" ]] 
	then 
	  if [[ k$1 =  k[Dd][Ee][Bb][Uu][Gg] || k$1 =  k[Rr][Ee][Ll][Ee][Aa][Ss][Ee] ]]
	  then
		PARAMS[actual_num_params]="$1"
        actual_num_params=`expr $actual_num_params + 1`
        LONGPARAM=
      elif [[ $1 =  \-* ]]
	  then
		if [[ ( $# -gt 1 ) && ( $2 != \-* ) && ( $2 != [Dd][Ee][Bb][Uu][Gg] ) && ( $2 !=  [Rr][Ee][Ll][Ee][Aa][Ss][Ee] ) ]]
		then
			LONGPARAM="$1"
	    else
			PARAMS[actual_num_params]="$1"
            actual_num_params=`expr $actual_num_params + 1`
	    fi
	  else
	    usage
	  fi  
	else
		if [[ ( $# -gt 1 ) && ( $2 != \-* ) && ( $2 != [Dd][Ee][Bb][Uu][Gg] ) && ( $2 !=  [Rr][Ee][Ll][Ee][Aa][Ss][Ee] ) ]]
		then
			LONGPARAM="$LONGPARAM $1"
	        else
			PARAMS[actual_num_params]="$LONGPARAM $1"
            		actual_num_params=`expr $actual_num_params + 1`
            		LONGPARAM=
	        fi
	fi
	
    shift

done



num_args_processed=0
while [ $num_args_processed -lt $actual_num_params ]
do

	if [[ ${PARAMS[num_args_processed]} =  [Dd][Ee][Bb][Uu][Gg] ]]
	then
		TARGET=Debug
	elif [[ ${PARAMS[num_args_processed]} =  [Rr][Ee][Ll][Ee][Aa][Ss][Ee] ]]
	then
		TARGET=Release
	elif [[ ${PARAMS[num_args_processed]} =  [\-][Hh][Oo][Mm][Ee]=* ]]
	then
    	HOMEDIR=`echo "${PARAMS[num_args_processed]}" | cut -f 2 -d = -`
	elif [[ ${PARAMS[num_args_processed]} =  [\-][Nn][Oo][Jj][Aa][Vv][Aa] ]]
	then
    	JAVA=no
	elif [[ ${PARAMS[num_args_processed]} =  [\-][Nn][Oo][Jj][Aa][Vv][Aa][Dd][Oo][Cc] ]]
	then
    	JAVADOC=no
	elif [[ ${PARAMS[num_args_processed]} =  [\-][Nn][Oo][Ss][Ee][Rr][Vv][Aa][Nn][Tt] ]]
	then
    	SERVANT=no
	elif [[ ${PARAMS[num_args_processed]} =  [\-][Nn][Oo][Gg][Ee][Nn] ]]
	then
		GENERATECORBA=no
	else
		usage
	fi
	
	num_args_processed=`expr $num_args_processed + 1`
	
done

if [ "$HOMEDIR" = "no" ]
then
    HOMEDIR=../../../../../../build/mac/$TARGET
fi

SCRIPTSDIR="$HOMEDIR/scripts/startup scripts"

echo ""
echo "About to build CORBA API for $PRODUCT $TARGET. Expect this step to take at least 20-30"
echo " minutes. The beginning of each step will be noted in this console window."
echo " For more details on the status of these steps, please look at"
echo " BldCorba_$PRODUCT$TARGET.log."
echo ""
echo "Building CORBA API for $PRODUCT $TARGET now..."

date
date > BldCorba_$PRODUCT$TARGET.log 

if [ "$GENERATECORBA" = "yes" ]
then
	echo "Step 1 of 6: Preparing directories..."
	echo "Step 1 of 6: Preparing directories..." >> BldCorba_$PRODUCT$TARGET.log 
	echo ""
	
	#create startup scripts folder, if necessary
	if [ ! -d "$HOMEDIR/scripts/startup scripts" ]
	   then
		CREATE_SCRIPTS_DIR=yes
		mkdir -p "$SCRIPTSDIR" >> BldCorba_$PRODUCT$TARGET.log 2>&1
	fi
	
	# recreate target directory for CORBA sourcefiles
	rm -rf gen/$TARGET >> BldCorba_$PRODUCT$TARGET.log 2>&1
	mkdir -p gen/$TARGET >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm "$SCRIPTSDIR/$TARGET.adobe.corba.js" >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm "$SCRIPTSDIR/corba.marker" >> BldCorba_$PRODUCT$TARGET.log 2>&1
	
	# populate corba.js template
	echo "\"$PWD/gen/$TARGET\"" > /tmp/$TARGET.adobe.corba.path.tmp
#	echo "s/\//\\\\\//g w /tmp/$TARGET.adobe.corba.path.tmp2" > /tmp/$TARGET.adobe.corba.sed.1
	echo "s=/=\\\\/=g  w /tmp/$TARGET.adobe.corba.path.tmp2" > /tmp/$TARGET.adobe.corba.sed.1
	sed -n -f /tmp/$TARGET.adobe.corba.sed.1 "/tmp/$TARGET.adobe.corba.path.tmp" >> BldCorba_$PRODUCT$TARGET.log 2>&1
	echo "4,$ s=REPLACE_WITH_PATH=`cat /tmp/$TARGET.adobe.corba.path.tmp2` =" > /tmp/$TARGET.adobe.corba.sed.2
	sed -f /tmp/$TARGET.adobe.corba.sed.2 scripts/corba.js > /tmp/$TARGET.adobe.corba.js
	cp -f "/tmp/$TARGET.adobe.corba.js" "$SCRIPTSDIR/" >> BldCorba_$PRODUCT$TARGET.log 2>&1
	checkerrors
	
	rm /tmp/$TARGET.adobe.corba.path.tmp >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm /tmp/$TARGET.adobe.corba.path.tmp2 >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm /tmp/$TARGET.adobe.corba.sed.1 >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm /tmp/$TARGET.adobe.corba.sed.2 >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm /tmp/$TARGET.adobe.corba.js >> BldCorba_$PRODUCT$TARGET.log 2>&1
	
	echo ""
	date
	date >> BldCorba_$PRODUCT$TARGET.log 
	echo "Step 2 of 6: Using InDesign Server to create CORBA sourcefiles..."
	echo "Step 2 of 6: Using InDesign Server to create CORBA sourcefiles..." >> BldCorba_$PRODUCT$TARGET.log 
	echo ""

	"$HOMEDIR/$PRODUCT" -configuration configuration_$TARGET | tee -a BldCorba_$PRODUCT$TARGET.log 2>&1
	checkerrors
else
	echo "Skipping step 1 and 2 because -nogen specified..."
	echo "Skipping step 1 and 2 because -nogen specified..." >> BldCorba_$PRODUCT$TARGET.log 
	echo ""
fi

if [ "$CREATE_SCRIPTS_DIR" = "yes" ]
  then 
    rm -Rf "$SCRIPTSDIR" >> BldCorba_$PRODUCT$TARGET.log 2>&1
else
    rm "$SCRIPTSDIR/$TARGET.adobe.corba.js" >> BldCorba_$PRODUCT$TARGET.log 2>&1
	rm "$SCRIPTSDIR/corba.marker" >> BldCorba_$PRODUCT$TARGET.log 2>&1
fi

date
date >> BldCorba_$PRODUCT$TARGET.log 
echo "Step 3 of 6: Calling buildidl to build IDL files and Java stubs..."
echo "Step 3 of 6: Calling buildidl to build IDL files and Java stubs..." >> BldCorba_$PRODUCT$TARGET.log 
echo ""
./buildidl.sh $TARGET >> BldCorba_$PRODUCT$TARGET.log 2>&1
checkerrors

if [ $JAVA = yes ]
then
	date
	date >> BldCorba_$PRODUCT$TARGET.log 
	echo "Step 4 of 6: Calling ant to compile/package Java stubs..."
	echo "Step 4 of 6: Calling ant to compile/package Java stubs..." >> BldCorba_$PRODUCT$TARGET.log 
	echo ""
	ant -DTARGET=$TARGET >> BldCorba_$PRODUCT$TARGET.log 2>&1
	checkerrors
fi

if [ $JAVADOC = yes ]
then
	date
	date >> BldCorba_$PRODUCT$TARGET.log 
	echo "Step 5 of 6: Calling ant to create JavaDoc..."
	echo "Step 5 of 6: Calling ant to create JavaDoc..." >> BldCorba_$PRODUCT$TARGET.log 
	echo ""
	ant javadoc -DTARGET=$TARGET >> BldCorba_$PRODUCT$TARGET.log 2>&1
	checkerrors
fi

if [ $SERVANT = yes ]
then
	date
	date >> BldCorba_$PRODUCT$TARGET.log 
	echo "Step 6 of 6: Calling XCode to build the InDesign CorbaSupport plugin..."
	echo "Step 6 of 6: Calling XCode to build the InDesign CorbaSupport plugin..." >> BldCorba_$PRODUCT$TARGET.log 
	echo ""
	XPWD=$PWD
	cd ../../../../../../build/mac/prj
	xcodebuild -project $PRODUCT_PRJ -target $TARGET >> $XPWD/BldCorba_$PRODUCT$TARGET.log 2>&1 
	checkerrors
	cd "$XPWD"
	XPWD=
fi

date
date >> BldCorba_$PRODUCT$TARGET.log 

echo "CORBA API BUILD SUCCESSFUL"
exit 0

