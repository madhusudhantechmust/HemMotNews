//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/sampleclient/main.cpp $
//  
//  Owner: Jeff Argast
//  
//  $Author: boshea $
//  
//  $DateTime: 2008/08/19 14:53:31 $
//  
//  $Revision: #2 $
//  
//  $Change: 643821 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  SampleClient is sample application that demonstrates how to
//  communicate with InDesignServer via soap. InDesignServer
//  exposes a single soap entry point called RunScript which
//  allows you to send the server a script (JavaScript, AppleScript, VBScript) for execution.
//  SampleClient uses gSoap for its implementation of soap.
//  
//  SampleClient is designed by run from the commandline.  For
//  example a typical run would look like:
//  
//  sampleclient -host localhost:18383 c:\testscript.js
//  
//========================================================================================
#ifdef WIN32
#define _UNICODE
#include <tchar.h>
#endif

#include "soapH.h"
#include "SoapClientUtils.h"

// ---- Library Includes ----

#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

#include <boost/lexical_cast.hpp>
using boost::lexical_cast;

/** display_help
	Display a message that describes the proper usage of SampleClient.  Output is on stdout.
*/
void display_help()
{
	cout << "SampleClient runs a script through InDesign Server.  "
		"The server instance is on a specified host."
		<< std::endl << std::endl;
	cout << "usage 1: sampleclient -h" << std::endl;
	cout << "Requests the display of this help information." << std::endl;
	cout << std::endl;
	cout << "usage 2: sampleclient [options] <script> [script args]" << std::endl;
	cout << "<script> specifies the script to be run. " << std::endl;
	cout << "\tIf file extension is \".applescript\", script content is assumed to be Applescript" << std::endl;
	cout << "\tIf file extension is \".vbs\", script content is assumed to be VBScript" << std::endl;
	cout << "\tOtherwise, script content is assumed to be JavaScript" << std::endl;
	cout << "[script args] specify any arguments to be passed to the script." << std::endl;
	cout << "\tThe form of each arg is \"name=value\", including the quotation marks." << std::endl;
	cout << "options..." << std::endl;
	cout << "\t-host <host> specifies the host.  <host> is an IP address" << std::endl;
	cout << "\t\tfollowed by a port, using the form ip:port.  If host and" << std::endl;
	cout << "\t\tclient are the same, use localhost:port.  The default is" << std::endl;
	cout << "\t\tlocalhost:18383." << std::endl;
	cout << "\t-server specifies that the script is in the server's (host's) file" << std::endl;
	cout << "\t\tsystem.  By default, the script is in the client's file system." << std::endl;
	cout << "\t-repeat specifies the number of times to execute the script." << std::endl;
	cout << std::endl;
}

/** report_error
	Display a specific error message if one is specified, otherwise display a message that describes
	the proper usage of SampleClient.  Output is on stderr.

	@param msg IN the string to display
*/
void report_error(const string& msg = "")
{
	if (!msg.empty())
	{
		std::cerr << "Error: " << msg << endl;
		std::cerr << "     : For usage, run sampleclient -h." << endl << endl;
	}

	display_help();
}

/** read_script_text
	Opens the script specified by path_name, extracts the text and returns it in script_text.

	@param path_name IN the full path name of the script to be executed.
	@param script_text OUT the text contents of the script.
	@return kTrue if the file could be opened.  kFalse otherwise.
*/
bool read_script_text(const string& path_name, string& script_text);

/** parse_args
	Parses and extracts the command line arguments passed to SampleClient.

	@param argc IN the number of command line arguments passed to SampleClient.
	@param argv IN a pointer to each individual command line argument.
	@param script OUT the path to the script.
	@param host OUT the name of the server (host) we want to send the script to.
	@param repeat OUT the number of times we want to execute the script.
	@param specifyScriptFile OUT kTrue if the script needs to be read locally.  kFalse if script resides on the server.
	@param script_args OUT a vector of script arguments that will be passed to the script.  Script arguments are specified
	as "name=value".
	@return 0, if processing of a script should continue; otherwise return -1.
*/
int parse_args(int argc, const char * argv[], string& script, string& host, int &repeat, bool& specifyScriptFile, vector< IDSP_ScriptArg >& script_args)
{
	if (argc < 2 || strcmp(argv[1],"-h") == 0)
	{
		display_help();
		return(-1);
	}

	for (int i = 1; i < argc; i++)
	{
		if (strcmp(argv[i],"-host") == 0)
			host = argv[++i];
		else if (strcmp(argv[i],"-server") == 0)
			specifyScriptFile = false;
		else if (strcmp(argv[i],"-repeat") == 0)
		{
			if (argc < i + 2)
			{
				report_error("-repeat must be followed by an integer.");
				return(-1);
			}

			try
			{
				repeat = lexical_cast<int>(argv[++i]);
			}
			catch (...)
			{
				report_error("-repeat must be followed by an integer.");
				return(-1);
			}
		}
		else
		{
			// -- Collect the set of script arguments.  If it is not a script argument it's assumed its the script itself.
			const char *equalsSignPtr = strchr(argv[i],'=');

			if (equalsSignPtr != NULL)
			{
				IDSP_ScriptArg script_arg;
				script_arg.name = string(argv[i]);
				script_arg.name.erase(script_arg.name.find('='));
				equalsSignPtr++;
				script_arg.value = string(equalsSignPtr);
				script_args.push_back(script_arg);
			}
			else if (script.empty())
				script = string(argv[i]);
			else
			{
				string msg("\"");
				msg += script;
				msg += "\" was identified as the specified script;";
				msg += " then an unrecognizable argument was found:  \"";
				msg += argv[i];//arg;
				msg += "\".";
				report_error(msg);
				return(-1);
			}
		}

	}

	return(0);
}

/** main
	The main entry point.

	@param argc IN the number of command line arguments passed to SampleClient.
	@param argv IN a pointer to each individual command line argument.
	@return -1 if an error occurred. 0 if everything was successful.
*/
#ifdef MACINTOSH
#define sampleclient_main main
#endif

#ifdef WIN32
int sampleclient_main (int argc, const char *argv[]);
// because we have '_UNICODE' defined (above), command line arguments passed in are unicode; need to convert 
// them to UTF-8 before passing them to InDesign

//int main(int argc, const char **argv);

int _tmain(int argc, wchar_t *argv[])
{
	int			utf8Argc = 0;
	const char	**utf8Argv = (const char **)(new char *[argc]);

	for (int i = 0; i < argc; i++)
		{
		int bytesRequired = WideCharToMultiByte(CP_UTF8, 0, argv[i], -1, NULL, 0, NULL, NULL);

		if (bytesRequired > 0)
			{
			bytesRequired += 2;	// leave room for null terminator
			char *buffer = new char[bytesRequired];
			if (WideCharToMultiByte(CP_UTF8, 0, argv[i], -1, buffer, bytesRequired, NULL, NULL) != 0)
				utf8Argv[utf8Argc++] = buffer;
			}
		}

	return (sampleclient_main(utf8Argc, utf8Argv));
}

#endif


int sampleclient_main (int argc, const char * argv[])
{
	string script;
	string host = "localhost:18383";	// -- The default host if one is not specified
	bool specifyScriptFile = true;		// -- By default we assume that we need to read the contents of the script file
	vector< IDSP_ScriptArg > script_args;
	int repeat = 1;
	bool exitWithError = false;

	int argsErrorCode(parse_args(argc, argv, script, host, repeat, specifyScriptFile, script_args));
	if (argsErrorCode != 0)
	{
		exit(argsErrorCode);
	}

	struct soap soap;
    soap_init2(&soap, SOAP_IO_KEEPALIVE, SOAP_IO_KEEPALIVE);

	// -- If a script is not specified then we can not continue.
	int soapResults = SOAP_OK;
	if (script.empty())
	{
		report_error("No script was specified.");
		exit(-1);
	}

	string scriptText;	// -- Used to hold the contents of the script

	// -- IDSP__RunScriptParameters is a soap type that we have defined for containing the information
	// -- necessary to ask the server to run a script.
	// script language
	
	IDSP__RunScriptParameters runScriptParams;
	runScriptParams.scriptArgs = &script_args;
	runScriptParams.scriptLanguage = "javascript";		// javascript is default

	// see if we have an applescript or vbscript extension; set language accordingly
	if (script.rfind(".applescript") != script.npos)
		runScriptParams.scriptLanguage = "applescript";
	else if (script.rfind(".vbs") != script.npos) {
		runScriptParams.scriptLanguage = "visual basic";
	}

	if (specifyScriptFile)
	{
		if (read_script_text(script, scriptText))
		{
			runScriptParams.scriptText = const_cast<char*>(scriptText.c_str());
			runScriptParams.scriptFile = "";
		}
		else
		{
			report_error("The script file specified can not be found");
			exit(-1);
		}
	}
	else
	{
		runScriptParams.scriptFile = const_cast<char*>(script.c_str());
		runScriptParams.scriptText = "";
	}

	for (int i = 0; i < repeat; i++)
	{
		// -- IDSP__RunScriptResponse is another soap type that we have defined to contain the results from running the script.
		IDSP__RunScriptResponse runScriptResponse;
		runScriptResponse.errorString = "";

		// -- soap_call_IDSP__RunScript is the server's entry point for running a script.
		soapResults = soap_call_IDSP__RunScript (&soap, host.c_str(), "", &runScriptParams, runScriptResponse);

		// -- If we are successful in sending the script via soap to the server and getting a return value
		// -- then soapResults will equal SOAP_OK.  Otherwise we use soap_print_fault to write out any soap
		// -- error messages to the console.
		if (soapResults == SOAP_OK)
		{
			if (runScriptResponse.errorNumber == 0)
			{
				cout << "Script result";
				IDSP__Data* dataHolder = runScriptResponse.scriptResult;
				if (dataHolder)
				{
					ShowAny(dataHolder);
				}
				else
				{
					cout << ": No data." << std::endl;
				}
			}
			else
			{
				cout << "Error number: " << runScriptResponse.errorNumber << std::endl;
				if (runScriptResponse.errorString != NULL)
					cout << runScriptResponse.errorString<< std::endl;
				exitWithError = true;
			}
		}
		else
		{
			report_error("SOAP error message follows.");
			soap_print_fault(&soap, stderr);
			exitWithError = true;
		}

		soap_destroy(&soap);
		soap_end (&soap);
	}

	soap_done (&soap);
	if (exitWithError)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
