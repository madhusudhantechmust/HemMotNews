//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/sampleclient/MRendezvousClient.h $
//  
//  Owner: Peter Boctor
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#ifndef __MRendezvousClient__
#define __MRendezvousClient__

#include <CarbonEvents.h>

class RendezvousClient
{
public:

	virtual void ListClients();
	virtual char* FindClient(const char* clientName);

private:

	static void ListClientBrowserCallback(CFNetServiceBrowserRef browser, CFOptionFlags flags, CFTypeRef domainOrService, CFStreamError* error, void* info);

	static void	FindClientBrowserCallback(CFNetServiceBrowserRef browser, CFOptionFlags flags, CFTypeRef domainOrService, CFStreamError* error, void* info);
	static void FindClientResolveCallback(CFNetServiceRef service, CFStreamError* error, void* info);
	
	static void InstallEventHandlers();
	static pascal void TimerAction(EventLoopTimerRef theTimer, EventLoopIdleTimerMessage inAction, void* userData);
	
	static void CancelBrowsing();
	static void CancelResolving();
	
	static CFStringRef fFindClientName;
	static char fFoundClientIP[64];
	static CFNetServiceBrowserRef fServiceBrowserRef;
	static CFNetServiceRef fServiceBeingResolved;
};

#endif
