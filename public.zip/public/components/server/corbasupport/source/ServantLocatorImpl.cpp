//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/corbasupport/source/ServantLocatorImpl.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ---- Interface Includes ----

#include "ICorba.h"

// ---- Implementation Includes ----

#include "ServantLocatorImpl.h"
#include "Utils.h"
#include "CorbaClassFactory.h"

// ---- Runtime Includes ----

namespace com { namespace adobe { namespace ids {

//========================================================================================
// IMPLEMENTATION Corba
//========================================================================================

ServantLocatorImpl::ServantLocatorImpl()
{
}

ServantLocatorImpl::~ServantLocatorImpl()
{
}

PortableServer::Servant ServantLocatorImpl::preinvoke(
	const PortableServer::ObjectId& oid,
	PortableServer::POA_ptr poa,
	const char* operation,
	void*& cookie) throw (CORBA::SystemException, PortableServer::ForwardRequest)
{
	const CorbaObjectSpecifier* objectSpecifier = CorbaObjectSpecifier::ParseCorbaObjectId(oid);	//could return nil
	PortableServer::Servant servant = CorbaClassFactory::CreateServant(objectSpecifier);
	if ( objectSpecifier )
		objectSpecifier->ReleaseRefFromClient() ;
	return servant ;
}

void ServantLocatorImpl::postinvoke(
	const PortableServer::ObjectId& oid,
	PortableServer::POA_ptr poa,
	const char* operation,
	void* cookie,
	PortableServer::Servant servant) throw (CORBA::SystemException)
{
	delete servant;
}

}}}
