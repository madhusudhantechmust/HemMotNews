//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/corbasupport/source/CorbaServiceIdleTask.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ----- Interface Includes -----

#include "ICorba.h"
#include "IIdleTask.h"
#include "IIdleTaskMgr.h"
#include "IScript.h"
#include "IScriptUtils.h"

// ----- Implementation Includes -----

#include "ApplicationImpl.h"
#include "CorbaRequest.h"
#include "CorbaScriptDataAdaptor.h"
#include "CorbaSupportID.h"
#include "CCommandLineArgs.h"
#include "FileUtils.h"
#include "MessageLog.h"
#include "ScriptEnv.h"
#include "ScriptBridge.h"
#include "ServantLocatorImpl.h"

// ----- System ----

#undef nil
#include <omniORB4/CORBA.h>
#define nil 0

#include <boost/shared_ptr.hpp>
using namespace boost;

using namespace com::adobe::ids;

//========================================================================================
// CLASS CorbaIdleTask
//========================================================================================

class CorbaIdleTask: public CPMUnknown<IIdleTask>
{
public:
	typedef CPMUnknown<IIdleTask> inherited;

	CorbaIdleTask(IPMUnknown *boss); 

	virtual uint32 RunTask( uint32 appFlags, IdleTimer* timeCheck);
	virtual void InstallTask(uint32 millisecsBeforeFirstRun);
	virtual void UninstallTask();
	virtual const char* TaskName();

private:
	void InitializeCorba();
	void TerminateCorba();
	void WriteIORFile(basics::Application_ptr application);

	static void* BSLAllocate(size_t size);
	static void BSLFree(void* p);
	static void LogFnc(const char* str);

	CorbaRequest fRequest;
	
	static void ThreadProc(void* parameter);
	omni_thread* fThread;

private:
	CORBA::ORB_ptr fOrb;
	basics::Application_ptr fApplication;
	ServantLocatorImpl* fServantLocatorImpl;
	PortableServer::ServantManager_ptr fServantLocator;
};

//========================================================================================
// METHODS CorbaIdleTask
//========================================================================================

CREATE_PMINTERFACE(CorbaIdleTask, kCorbaIdleTaskImpl)

//----------------------------------------------------------------------------------------
// CorbaIdleTask::CorbaIdleTask
//----------------------------------------------------------------------------------------

CorbaIdleTask::CorbaIdleTask(IPMUnknown *boss) :
	inherited(boss),
	fOrb(NULL),
	fThread(NULL),
	fRequest()
{
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::RunTask
//----------------------------------------------------------------------------------------

uint32 CorbaIdleTask::RunTask( uint32 appFlags, IdleTimer* timeCheck)
{
	InitializeCorba();

	if (fOrb == NULL)
		return kNextEventCycle;

	char* request = (char*) fRequest.GetRequest();

	if (request != NULL)
	{
		if (fOrb->work_pending())
			fOrb->perform_work();

//		delete [] request;	// now just passing a non-0 number around
		fRequest.SignalResultsAvailable();
	}

	return kNextEventCycle;
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::InstallTask
//----------------------------------------------------------------------------------------
 
void CorbaIdleTask::InstallTask(uint32 millisecsBeforeFirstRun)
{
	InterfacePtr<IIdleTaskMgr> idleTaskMgr(GetExecutionContextSession(), UseDefaultIID());
	idleTaskMgr->AddTask(this, millisecsBeforeFirstRun);
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::UninstallTask
//----------------------------------------------------------------------------------------

void CorbaIdleTask::UninstallTask()
{
	TerminateCorba();

	InterfacePtr<IIdleTaskMgr> idleTaskMgr(GetExecutionContextSession(), UseDefaultIID());
	idleTaskMgr->RemoveTask(this);
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::TaskName
//----------------------------------------------------------------------------------------

const char* CorbaIdleTask::TaskName()
{
	return "Corba Service Task";
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::InitializeCorba
//----------------------------------------------------------------------------------------

void CorbaIdleTask::InitializeCorba()
{
	if (fOrb != NULL)
		return;

	gInfoLog.Write("Initializing Corba API", "server", MessageLog::kDontTranslate);

	int argc = gCommandLineArgs->GetArgCnt();
	boost::shared_ptr<char*> argv(new char*[argc]);
	for (int32 i = 0; i < argc; i++)
	{
		const char* char_ptr = gCommandLineArgs->GetNthArg(i).GrabCString();
		argv.get()[i] = (char*) char_ptr;
	}

	omniORB::setLogFunction(LogFnc);

	fOrb = CORBA::ORB_init(argc, argv.get());

	CORBA::Object_var object = fOrb->resolve_initial_references("RootPOA");
	PortableServer::POA_var rootPoa = PortableServer::POA::_narrow(object);
	PortableServer::POAManager_var poa_mgr = rootPoa->the_POAManager();

	poa_mgr->activate();

	CORBA::PolicyList policies;
	policies.length(4);

	enum PortableServer::ThreadPolicyValue threadPolicy = PortableServer::MAIN_THREAD_MODEL;
	policies[0] = rootPoa->create_thread_policy(threadPolicy);

	enum PortableServer::IdAssignmentPolicyValue assignmentPolicy = PortableServer::USER_ID;
	policies[1] = rootPoa->create_id_assignment_policy(assignmentPolicy);

	enum PortableServer::RequestProcessingPolicyValue requestProcessingPolicy = PortableServer::USE_SERVANT_MANAGER;
	policies[2] = rootPoa->create_request_processing_policy(requestProcessingPolicy);

	enum PortableServer::ServantRetentionPolicyValue servantRetentionPolicy = PortableServer::NON_RETAIN;
	policies[3] = rootPoa->create_servant_retention_policy(servantRetentionPolicy);

	PortableServer::POA_var poa = rootPoa->create_POA("ids_poa", poa_mgr, policies);

	fServantLocatorImpl = new ServantLocatorImpl;
	fServantLocator = fServantLocatorImpl->_this();
	poa->set_servant_manager(fServantLocator);

	Utils<ICorba>()->Initialize(fOrb, poa);

	try
	{
		ScriptEnv env ;
		InterfacePtr<IScript> applScript( Utils<IScriptUtils>()->QueryApplicationScript() ) ;
		const CorbaObjectSpecifier* objectSpecifier = new CorbaObjectSpecifier( applScript, env.GetRequestContext() ) ;
		framework::SObject_var appObject = Application_Servant::Create( objectSpecifier ) ;
		fApplication = basics::Application::_narrow(appObject);
		objectSpecifier->ReleaseRefFromClient() ;
	}
	catch (PortableServer::POA::WrongPolicy& /*ex*/)
	{
		ASSERT_FAIL(FORMAT_ARGS("Corba exception : %s", "" /*ex._name() compile error on XCode*/));
	}
	catch (...)
	{
		ASSERT_FAIL("failing...");
	}

	WriteIORFile(fApplication);

	if (fThread == NULL)
		fThread = omni_thread::create(ThreadProc, this);
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::TerminateCorba
//----------------------------------------------------------------------------------------

void CorbaIdleTask::TerminateCorba()
{
	CORBA::release(fApplication);
	CORBA::release(fServantLocator);
	fOrb->shutdown(true);
	fOrb = NULL;
	delete fServantLocatorImpl;
	fServantLocatorImpl = NULL;
}

//----------------------------------------------------------------------------------------
// CorbaIdleTask::WriteIORFile
//----------------------------------------------------------------------------------------

void CorbaIdleTask::WriteIORFile(basics::Application_ptr application)
{
	CORBA::String_var ior = fOrb->object_to_string(application);

	PMString msg("Application");
	msg.Append(ior);
	gInfoLog.Write(msg, "server", MessageLog::kDontTranslate);

	IDFile iorFile;
	PMString iorStr = gCommandLineArgs->GetIORFile();
	if (!iorStr.IsEmpty())
	{
		FileUtils::PMStringToIDFile(iorStr, iorFile);

		FILE* fh = /*FileUtils::OpenFile*/ fopen(iorStr.GrabCString(), "wt");
		if (fh != NULL)
		{
			msg = "Writing IOR to '";
			msg.Append(gCommandLineArgs->GetIORFile());
			msg.Append("'");
			gInfoLog.Write(msg, "server", MessageLog::kDontTranslate);
			
			fprintf(fh, "%s\n", fOrb->object_to_string(fApplication));
			fclose(fh);
		}
		else
		{
			msg = "Cannot open IOR file '";
			msg.Append(gCommandLineArgs->GetIORFile());
			msg.Append("' for writing, check permissions");
			gErrorLog.Write(msg, "server", MessageLog::kDontTranslate);
		}
	}
}

void CorbaIdleTask::LogFnc(const char* str)
{
	printf("%s", str);
}

//----------------------------------------------------------------------------------------
// BedrockStartupShutdownService::ThreadProc
//----------------------------------------------------------------------------------------

void CorbaIdleTask::ThreadProc(void* parameter)
{
	CorbaIdleTask* task = (CorbaIdleTask*) parameter;

	while (!task->fOrb->wait_for_work())
	{
//		task->fRequest.SetRequest(new char[1]);
		task->fRequest.SetRequest((void *)1706);	// year Benjamin Franklin was born
		task->fRequest.WaitForResults();
	}
}
