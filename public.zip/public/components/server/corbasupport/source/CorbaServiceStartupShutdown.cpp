//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/corbasupport/source/CorbaServiceStartupShutdown.cpp $
//  
//  Owner: Michael Burbidge
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

#include "VCPluginHeaders.h"

// ---- Interface Includes ----

#include "IStartupShutdownService.h"
#include "IIdleTask.h"
#include "ISession.h"

// ---- Implementation Includes ----

#include "CorbaSupportID.h"
#include "CPMUnknown.h"

// ---- Runtime Includes ----

#include <iostream>
#include <string>

//========================================================================================
// CLASS Corba
//========================================================================================

class CorbaStartupShutdown: public CPMUnknown<IStartupShutdownService>
{
public:
	typedef CPMUnknown<IStartupShutdownService> inherited;

	CorbaStartupShutdown(IPMUnknown *boss); 
	
	virtual void 	Startup();
	virtual void	Shutdown();
};

//========================================================================================
// IMPLEMTATION Corba
//========================================================================================

CREATE_PMINTERFACE(CorbaStartupShutdown, kCorbaStartupShutdownImpl)

//----------------------------------------------------------------------------------------
// CorbaStartupShutdown::CorbaStartupShutdown
//----------------------------------------------------------------------------------------

CorbaStartupShutdown::CorbaStartupShutdown(IPMUnknown *boss) :
	inherited(boss)
{
}

//----------------------------------------------------------------------------------------
// CorbaStartupShutdown::Startup
//----------------------------------------------------------------------------------------

void CorbaStartupShutdown::Startup()
{
	InterfacePtr<IIdleTask> idleTask((IIdleTask*) ::CreateObject (kCorbaIdleTaskBoss, IID_IIDLETASK));
	idleTask->InstallTask(10000);
}

//----------------------------------------------------------------------------------------
// CorbaStartupShutdown::Shutdown
//----------------------------------------------------------------------------------------

void CorbaStartupShutdown::Shutdown()
{
}
