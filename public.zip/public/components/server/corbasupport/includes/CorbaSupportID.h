//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/server/corbasupport/includes/CorbaSupportID.h $
//  
//  Owner: Robin_Briggs
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Contains IDs used by the generic page item plug-in
//  
//========================================================================================

#ifndef __CorbaSupportID__
#define __CorbaSupportID__

#include "CrossPlatformTypes.h"
#include "IDFactory.h"
#include "ScriptingID.h"
#define kCorbaSupportIDPrefix	RezLong(0x1F100)

// <Plugin ID>
DECLARE_PMID(kPlugInIDSpace, kCorbaSupportPluginID, kCorbaSupportIDPrefix + 1)

// <Class ID>
DECLARE_PMID(kClassIDSpace, kCorbaSupportScriptProviderBoss, 			kCorbaSupportIDPrefix + 0)
DECLARE_PMID(kClassIDSpace, kCorbaStartupShutdownBoss, 					kCorbaSupportIDPrefix + 1)
DECLARE_PMID(kClassIDSpace, kCorbaIdleTaskBoss, 						kCorbaSupportIDPrefix + 2)
DECLARE_PMID(kClassIDSpace, kCorbaInitializerBoss, 						kCorbaSupportIDPrefix + 3)

// <Interface ID>

// <Implementation ID>
DECLARE_PMID(kImplementationIDSpace, kCorbaStartupShutdownImpl, 		kCorbaSupportIDPrefix + 2)
DECLARE_PMID(kImplementationIDSpace, kCorbaIdleTaskImpl, 				kCorbaSupportIDPrefix + 3)
DECLARE_PMID(kImplementationIDSpace, kCorbaInitializerImpl, 			kCorbaSupportIDPrefix + 4)

// <Script Element ID>

#endif // __CorbaSupportID__
