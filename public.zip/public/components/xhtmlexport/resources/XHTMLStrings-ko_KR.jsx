//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-ko_KR.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'ko_KR';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = '취소';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/Dreamweaver(&D)...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'XHTML 내보내기(&R)';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Dreamweaver용으로 내보내기(&W)...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Dreamweaver에 사용할 XHTML 내보내기';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = '"%1"을(를) XHTML로 내보낼 수 없습니다.\n파일 "%2"을(를) 작성하지 못했습니다. 사용 가능한 충분한 공간이 없거나 이 위치에서 파일을 작성할 수 있는 권한이 없습니다.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = '"%1"을(를) XHTML로 내보낼 수 없습니다.\n폴더 "%2"을(를) 작성하지 못했습니다. 사용 가능한 충분한 공간이 없거나 이 위치에서 파일을 작성할 수 있는 권한이 없습니다.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = '"%1"을(를) XHTML로 내보낼 수 없습니다.\n파일 "%2"을(를) 삭제하지 못했습니다. 이 위치에서 파일을 삭제할 수 있는 권한이 없습니다.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = '내보내려면 누락된 스크립트 파일이 필요합니다.\n필요한 스크립트 파일 "%1"을(를) 열 수 없거나 누락되었습니다.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = '파일 이름이 잘못되었습니다.\n파일 이름 "%1"에 다음과 같은 잘못된 문자가 하나 이상 포함되어 있습니다.\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML 파일을 내보냈지만 한 가지 이상의 문제가 발생했습니다.';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = '연결된 이미지: %1 누락';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = '연결된 이미지: %1이(가) 최신 상태가 아님';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = '붙인 이미지: %1 건너뜀(연결된 이미지만 내보냄)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = '연결된 동영상: %1 누락';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = '지원되지 않는 동영상: %1 건너뜀(.SWF 동영상만 내보냄)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'XHTML 내보내기';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = '취소하려면 Esc를 누르거나 Cmd + 마침표를 누르십시오.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = '취소하려면 Esc를 누르십시오.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = '내보내기';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML 내보내기 옵션';
xhtmlExportStrings.GENERAL[xhtmllocale] = '일반';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = '글머리 기호 및 번호';
xhtmlExportStrings.SCOPE[xhtmllocale] = '내보내기';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '글머리 기호(&B):';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '번호(&N):';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = '순서가 없는 목록에 매핑';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = '순서가 있는 목록에 매핑';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = '정적인 순서가 있는 목록에 매핑';
xhtmlExportStrings.ASTEXT[xhtmllocale] = '텍스트로 변환';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '선택 항목(&S)';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '새 문서(&D)';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = '이미지';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '이미지 복사(&C):';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = '서버 패스에 연결';
xhtmlExportStrings.ORIGS[xhtmllocale] = '원본';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = '최적화';
xhtmlExportStrings.PATH[xhtmllocale] = '서버의 패스(&A):';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '파일 확장(&T):';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '서식(&F)';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '이미지 변환(&I):';
xhtmlExportStrings.AUTO[xhtmllocale] = '자동';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF 옵션';
xhtmlExportStrings.PALETTE[xhtmllocale] = '팔레트(&P):';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = '주 색상(디더 없음)';
xhtmlExportStrings.WEB[xhtmllocale] = '웹';
xhtmlExportStrings.SYSWIN[xhtmllocale] = '시스템(Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = '시스템(Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '인터레이스(&L)';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG 옵션';
xhtmlExportStrings.QUALITY[xhtmllocale] = '이미지 품질(&Q):';
xhtmlExportStrings.LOW[xhtmllocale] = '낮음';
xhtmlExportStrings.MEDIUM[xhtmllocale] = '중형';
xhtmlExportStrings.HIGH[xhtmllocale] = '높음';
xhtmlExportStrings.MAX[xhtmllocale] = '최대값';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '포맷 방법(&F):';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = '점진적';
xhtmlExportStrings.BASELINE[xhtmllocale] = '기준선';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = '고급';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS 옵션';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '빈 CSS 선언(&E)';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'CSS 없음(&O)';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '외부 CSS(&X):';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript 옵션';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '외부 JavaScript에 연결(&L):';