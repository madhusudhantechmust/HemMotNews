//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-pl_PL.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'pl_PL';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Anuluj';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Ekspo&rtuj XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Eksportuj do programu Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Eksportuj XHTML dla Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Nie powiodło się eksportowanie pliku %1 do formatu XHTML.\nNie można było utworzyć pliku %2. Przyczyną może być brak wolnego miejsca na dysku lub niewystarczające przyzwolenia użytkownika do tworzenia plików we wskazanym miejscu.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Nie powiodło się eksportowanie pliku %1 do formatu XHTML.\nNie można było utworzyć pliku %2. Przyczyną może być brak wolnego miejsca na dysku lub niewystarczające przyzwolenia użytkownika do tworzenia plików we wskazanym miejscu.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Nie powiodło się eksportowanie pliku %1 do formatu XHTML.\nNie można było usunąć pliku %2. Przyczyną może być brak wystarczających przyzwoleń użytkownika do usuwania plików we wskazanym miejscu.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Brakuje pliku skryptu, który jest niezbędny przy eksportowaniu.\nWymagany plik skryptu o nazwie %1 nie otwiera się lub nie istnieje.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Niedozwolona nazwa pliku.\nNazwa pliku („%1”) zawiera przynajmniej jeden z niedozwolonych znaków:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Plik XHTML został wyeksportowany, ale wykryto pewne problemy:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Liczba brakujących przyłączonych obrazów: %1';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Liczba nieaktualnych przyłączonych obrazów: %1';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Liczba pominiętych wklejonych obrazów: %1 (eksportowane są tylko przyłączone obrazy)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Liczba brakujących przyłączonych filmów: %1';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Liczba pominiętych nieobsługiwanych filmów: %1 (eksportowane są tylko filmy .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Eksportowanie pliku XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Aby anulować, naciśnij klawisz Esc lub klawisze Cmd + kropka.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Aby anulować, naciśnij klawisz Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Eksportuj';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Opcje eksportowania XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Ogólne';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Punktory i numeracja';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Eksportuj';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = 'Listy wy&punktowane:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = 'Listy &numerowane:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Przekonwertuj na listy nieuporządkowane';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Przekonwertuj na listy uporządkowane';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Przekonwertuj na statyczne listy uporządkowane';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Przekonwertuj na tekst';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Zaznaczenie';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokument';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Obrazy';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Kopiuj obrazy:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Utwórz łącze do ścieżki na serwerze';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Oryginał';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Zoptymalizowany';
xhtmlExportStrings.PATH[xhtmllocale] = 'Ścieżk&a na serwerze:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '&Rozszerzenie pliku';
xhtmlExportStrings.FORMATTED[xhtmllocale] = 'S&formatowane';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Konwersja obrazu:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatyczne';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Opcje formatu GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paleta:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptacyjna (bez rozstrząsania)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Internet';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Systemowa (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Systemowa (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Z przep&lotem';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Opcje formatu JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Jakość obrazu:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Niska';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Średnia';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Wysoka';
xhtmlExportStrings.MAX[xhtmllocale] = 'Najwyższa';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Metoda formatowania:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progresywna';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Standardowa';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Zaawansowane';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Opcje CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Puste deklaracje CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&Brak CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'Z&ewnętrzne style CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Opcje JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Łącze do zewnętrznego pliku JavaScript:';