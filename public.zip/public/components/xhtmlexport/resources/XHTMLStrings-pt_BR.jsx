//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-pt_BR.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'pt_BR';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Cancelar';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/&Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rtar XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Exportar para o Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Exportar XHTML para o Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Falha na exportação de “%1” como XHTML.\nNão foi possível criar o arquivo “%2”. Talvez não haja espaço disponível suficiente ou você não tenha permissão para criar arquivos neste local.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Falha na exportação de “%1” como XHTML.\nNão foi possível criar a pasta “%2”. Talvez não haja espaço disponível suficiente ou você não tenha permissão para criar arquivos neste local.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Falha na exportação de “%1” como XHTML.\nNão foi possível excluir o arquivo “%2”. Talvez você não tenha permissão para excluir arquivos neste local.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'A exportação requer um arquivo de script ausente.\nO arquivo de script necessário “%1” não pôde ser aberto ou está ausente.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Nome de arquivo inválido.\nO nome de arquivo “%1” contém um ou mais destes caracteres inválidos:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'O arquivo XHTML foi exportado, mas foram detectados um ou mais problemas:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Imagens vinculadas: %1 ausentes';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Imagens vinculadas: %1 desatualizadas';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Imagens coladas: %1 ignoradas (são exportadas somente imagens vinculadas)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Filmes vinculados: %1 ausentes';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Filmes não suportados: %1 ignorados (são exportados somente filmes .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Exportando XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Para cancelar, pressione Esc ou Cmd + ponto.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Para cancelar, pressione Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exportar';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Opções de exportação de XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Geral';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Marcadores e números';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exportar';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Marcadores:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Números:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Mapear para listas não ordenadas';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Mapear para listas ordenadas';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Mapear para listas ordenadas estáticas';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Converter em texto';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Seleção';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Documento';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Imagens';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Copiar imagens:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Vincular ao caminho do servidor';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Otimizado';
xhtmlExportStrings.PATH[xhtmllocale] = 'C&aminho no servidor:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Ex&tensão do arquivo:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formatado';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Conversão de &imagens:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automática';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Opções de GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paleta:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptável (sem pontilhado)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Sistema (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Sistema (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Entre&laçar';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Opções de JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Qualidade da imagem:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Baixa';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Média';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Alta';
xhtmlExportStrings.MAX[xhtmllocale] = 'Máxima';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Método de formatação:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressivo';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Linha de base';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avançado';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Opções de CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Declarações CSS vazias';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'S&em CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'CSS e&xterno:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Opções de JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = 'Vincu&lar ao JavaScript externo:';