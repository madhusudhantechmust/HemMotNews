//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-nl_NL.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'nl_NL';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Annuleren';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'XHTML expo&rteren';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Exporteren voor Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'XHTML exporteren voor Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Export van “%1” als is XHTML mislukt.\nKan bestand “%2” niet maken. Er is mogelijk niet genoeg ruimte beschikbaar of u hebt misschien geen rechten om bestanden te maken op deze locatie.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Export van “%1” als is XHTML mislukt.\nKan map “%2” niet maken. Er is mogelijk niet genoeg ruimte beschikbaar of u hebt misschien geen rechten om bestanden te maken op deze locatie.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Export van “%1” als is XHTML mislukt.\nKan bestand “%2” niet verwijderen. U hebt mogelijk geen rechten om bestanden te verwijderen van deze locatie.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Voor het exporteren is een ontbrekend scriptbestand vereist.\nHet vereiste scriptbestand “%1” kan niet worden geopend of ontbreekt.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Ongeldige bestandsnaam.\nDe bestandsnaam “%1” bevat een of meer van de volgende ongeldige tekens:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Het XHTML-bestand is geëxporteerd, maar er zijn een of meer problemen opgetreden:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Gekoppelde afbeeldingen: %1 ontbrekend';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Gekoppelde afbeeldingen: %1 verouderd';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Geplakte afbeeldingen: %1 overgeslagen (alleen gekoppelde afbeeldingen worden geëxporteerd)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Gekoppelde films: %1 ontbrekend';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Niet-ondersteunde films: %1 overgeslagen (alleen SWF-films worden geëxporteerd)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'XHTML exporteren';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Druk om te annuleren op de Escape-toets of op de Command-toets en de punt.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Druk om te annuleren op de Escape-toets.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exporteren';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Opties voor XHTML exporteren';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Algemeen';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Opsommingstekens en nummering';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exporteren';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Opsommingstekens:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Nummering:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Toewijzen aan niet-gesorteerde lijsten';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Toewijzen aan gesorteerde lijsten';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Toewijzen aan statische gesorteerde lijsten';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Omzetten in tekst';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Selectie';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Document';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Afbeeldingen';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = 'Afbeeldingen &kopiëren:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Koppelen aan serverpad';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Origineel';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Geoptimaliseerd';
xhtmlExportStrings.PATH[xhtmllocale] = 'P&ad op server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Bestandsex&tensie:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Opgemaakt';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Af&beelding omzetten:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatisch';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-opties';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palet:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Aangepast (geen dither)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Systeem (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Systeem (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Inter&liniëren';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-opties';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'K&waliteit afbeelding:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Laag';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Normaal';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Hoog';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximaal';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Opmaak&methode:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressief';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Basislijn';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Geavanceerd';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-opties';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = 'CSS-declaraties &leegmaken';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&Geen CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&xterne CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-opties';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Koppelen aan extern JavaScript:';