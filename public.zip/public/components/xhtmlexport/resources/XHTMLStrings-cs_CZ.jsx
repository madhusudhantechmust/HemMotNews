//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-cs_CZ.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'cs_CZ';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Zrušit';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rt XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Export pro Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Export XHTML pro Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Export „%1“ jako HTML se nezdařil.\nSoubor „%2“ nebylo možné vytvořit. Možná není dostatek místa nebo nemáte práva k vytváření souborů v tomto umístění.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Export „%1“ jako HTML se nezdařil.\nSložku „%2“ nebylo možné vytvořit. Možná není dostatek místa nebo nemáte práva k vytváření souborů v tomto umístění.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Export „%1“ jako HTML se nezdařil.\nSoubor „%2“ nebylo možné odstranit. Možná nemáte práva pro odstraňování souborů v tomto umístění.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Export vyžaduje soubor skriptu, který chybí.\nVyžadovaný soubor skriptu „%1“ nelze otevřít nebo chybí.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Neplatný název souboru.\nNázev souboru „%“ obsahuje jeden či více neplatných znaků:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Soubor XHTML byl vyexportován, ale byl zjištěn jeden nebo více problémů:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Připojené obrazy: %1 chybí';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Připojené obrazy: %1 neaktuálních';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Vložené obrazy: %1 přeskočeno (exportují se pouze připojené obrazy)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Připojené filmy: %1 chybí';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Nepodporované filmy: %1 přeskočeno (exportují se pouze filmy SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Exportuje se XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Chcete-li export zrušit, stiskněte Esc nebo Apple + tečku.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Chcete-li export zrušit, stiskněte Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Export';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Volby exportu XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Všeobecné';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Odrážky a čísla';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Export';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Odrážky:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = 'Čí&sla:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Mapovat na neuspořádané seznamy';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Mapovat na uspořádané seznamy';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Mapovat na statické uspořádané seznamy';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Převést na text';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Výběr';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokument';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Obrazy';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Kopírovat obrazy:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Odkaz na cestu na serveru';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Originál';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimalizovaný';
xhtmlExportStrings.PATH[xhtmllocale] = '&Cesta na serveru:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '&Přípona souboru:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formátovaný';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Převod obrazu:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automaticky';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Volby GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paleta:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptivní (bez rozkladu)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Webová';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Systémová (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Systémová (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Prok&ládaně';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Volby JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Kvalita obrazu:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Nízká';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Střední';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Vysoká';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximální';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Metoda formátování:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progresivní';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Základní';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Další volby';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Volby CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Prázdné deklarace CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Žád&né CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&xterní CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Volby JavaScriptu';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Odkaz na externí JavaScript:';