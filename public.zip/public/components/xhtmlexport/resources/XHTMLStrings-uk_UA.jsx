//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-uk_UA.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'uk_UA';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Скасувати';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Експ&ортувати XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Експортувати для Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Експортувати XHTML для Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Помилка експорту “%1” як XHTML.\nНе вдалося створити файл “%2”. Можливо бракує вільного місця або відсутні права на створення файлів в цій теці.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Помилка експорту “%1” як XHTML.\nНе вдалось створити теку “%2”. Можливо бракує вільного місця або відсутні права на створення файлів в цій теці.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Помилка експорту “%1” як XHTML.\nНе вдалося видалити файл “%2”. Можливо відсутні права на видалення файлів з цієї теки.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Для експорту необхідна наявність файлу сценарію, що наразі відсутній.\nНе вдається відкрити або відсутній необхідний файл сценарію “%1”.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Неприпустиме ім\'я файлу.\nІм\'я файлу “%1” містить один або кілька наступних недозволених символів:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Файл XHTML експортовано, але виникла одна або декілька помилок:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Зв\'язані зображення: немає %1';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Зв\'язані зображення: застарілі %1';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Вставлені зображення: %1 пропущено (експортовані тільки зв’язані зображення)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Зв\'язані фільми: немає %1';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Непідтримувані фільми: %1 пропущено (експортовані тільки фільми SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Експорт XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Щоб скасувати, натисніть клавішу Esc або Cmd + Точка.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Щоб скасувати, натисніть клавішу Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Експорт';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Параметри експорту XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Загальні';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Маркери та нумерація';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Експорт';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Маркери:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Нумерація:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Співвіднести з невпорядкованими списками';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Співвіднести із впорядкованими списками';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Співвіднести зі статичними впорядкованими списками';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Перетворити на текст';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Виділення';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Документ';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Зображення';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Копіювання зображень:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Посилання на шлях до сервера';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Оригінал';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Оптимізовано';
xhtmlExportStrings.PATH[xhtmllocale] = 'Ш&лях до сервера:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Ро&зширення файла:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Форматовано';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Перетворення &зображення:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Автоматично';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Параметри GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Палітра:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Адаптивна (без згладжування)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Веб';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Система (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Система (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Чергу&вати';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Параметри JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Якість зображення:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Низька';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Середня';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Висока';
xhtmlExportStrings.MAX[xhtmllocale] = 'Максимальна';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Метод форматування:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Прогресивний';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Стандартний';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Додаткові параметри';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Параметри CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Порожні декларації CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Б&ез CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'З&овнішній CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Параметри JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Посилання на зовнішній JavaScript:';