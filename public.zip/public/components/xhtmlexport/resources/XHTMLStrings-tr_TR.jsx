//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-tr_TR.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'tr_TR';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'İptal';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'XHTML\'yi &Dışa Aktar';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = '&Dreamweaver için Dışa Aktar...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'XHTML\'yi Dreamweaver için Dışa Aktar';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = '“%1” dosyası XHTML olarak dışa aktarılamadı.\n“%2” dosyası oluşturulamadı. Yeterli alan bulamayabileceğiniz gibi, burada dosya oluşturma izniniz de olmayabilir.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = '“%1” dosyası XHTML olarak dışa aktarılamadı.\n“%2” klasörü oluşturulamadı. Yeterli alan bulamayabileceğiniz gibi, burada dosya oluşturma izniniz de olmayabilir.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = '“%1” dosyası XHTML olarak dışa aktarılamadı.\n“%2” dosyası silinemedi. Burada dosya silme izniniz de olmayabilir.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Dışa aktarmak için eksik komut dosyaları gerekiyor.\nGerekli “%1” komut dosyası açılamıyor veya yok.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Geçersiz dosya adı.\n“%1” dosya adında bir veya daha fazla geçersiz karakter var:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML dosyası dışa aktarıldı; ancak bir veya daha fazla sorun algılandı:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Bağlı görüntüler: %1 eksik';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Bağlı görüntüler: %1 tarihi geçmiş';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Yapıştırılmış görüntüler: %1 atlanmış (sadece bağlı görüntüler dışa aktarılabilir)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Bağlı filmler: %1 eksik';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Desteklenmeyen filmler: %1 atlanmış (sadece .SWF filmler dışa aktarılabilir)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'XHTML dışa aktarılıyor';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'İptal etmek için Esc veya Cmd + Virgül tuşlarına basın.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'İptal etmek için Esc tuşuna basın.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Dışa Aktar';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML Dışa Aktarma Seçenekleri';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Genel';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Madde İşaretleri ve Numaralar';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Dışa Aktar';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Madde İşaretleri:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numaralar:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Sıralanmamış Listeleri Eşle';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Sıralanmış Listeleri Eşle';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Statik Sıralanmış Listeleri Eşle';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Metne Dönüştür';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Seçim';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Belge';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Görüntüler';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Görüntüleri Kopyala:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Sunucu Yoluna Bağla';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Orijinal';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'En İyileştirilmiş';
xhtmlExportStrings.PATH[xhtmllocale] = '&Sunucu Yolu:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '&Dosya Uzantısı:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formatlı';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Görüntü Dönüştürme:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Otomatik';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF Seçenekleri';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palet:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptif (titreme yok)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Sistem (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Sistem (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '&Tarama';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG Seçenekleri';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'Görüntü &Kalitesi:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Düşük';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Orta';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Yüksek';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maksimum';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Formatlama &Yöntemi:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'İlerleyici';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Satır Taban Çizgisi';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Gelişmiş';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS Seçenekleri';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Boş CSS Bildirimleri';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&CSS Yok';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '&Harici CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript Seçenekleri';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Harici JavaScript Bağı Kur:';