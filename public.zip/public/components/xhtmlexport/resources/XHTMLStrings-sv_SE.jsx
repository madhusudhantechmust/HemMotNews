//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-sv_SE.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'sv_SE';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Avbryt';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rtera XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Export för Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Exportera XHTML för Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Det uppstod ett fel när %1 skulle exporteras som XHTML.\nDet gick inte att skapa filen %2. Det kan bero på att det inte finns tillräckligt med ledigt utrymme eller på att du inte har behörighet att skapa filer på den här platsen.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Det uppstod ett fel när %1 skulle exporteras som XHTML.\nDet gick inte att skapa mappen %2. Det kan bero på att det inte finns tillräckligt med ledigt utrymme eller på att du inte har behörighet att skapa filer på den här platsen.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Det uppstod ett fel när %1 skulle exporteras som XHTML.\nDet gick inte att ta bort filen %2. Du har eventuellt inte behörighet att ta bort filer från den här platsen.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'En skriptfil som behövs för exporten saknas.\nDet gick inte att öppna den obligatoriska skriptfilen %1 eller så saknas den.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Ogiltigt filnamn.\nFilnamnet “%1” innehåller ett eller fler av de här ogiltiga tecknen:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML-filen exporterades men ett eller flera problem upptäcktes:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Länkade bilder: %1 saknas';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Länkade bilder: %1 är inaktuella';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Inklistrade bilder: %1 hoppades över (endast länkade bilder exporteras)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Länkade filmer: %1 saknas';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Filmer som inte kan användas: %1 hoppades över (endast .SWF-filmer exporteras)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Exporterar till XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Om du vill avbryta trycker du på Esc eller Kommando+punkt.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Om du vill avbryta trycker du på Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exportera';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML-exportalternativ';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Allmänt';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Punkter och numrering';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exportera';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Punkter:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numrering:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Avbilda till osorterade listor';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Avbilda till sorterade listor';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Avbilda till statiska sorterade listor';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Konvertera till text';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = 'M&arkering';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokument';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Bilder';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Kopiera bilder:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Länk till serversökvägen';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimerade';
xhtmlExportStrings.PATH[xhtmllocale] = '&Sökväg på servern:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Fil&tillägg:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formaterade';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'B&ildkonvertering:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatisk';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-alternativ';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palett:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Anpassad (ingen rastrering)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Webb';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'System (Windows)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'System (Mac OS)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'F&lätad';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-alternativ';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Bildkvalitet:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Låg';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Mellan';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Hög';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximal';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Formaterings&metod:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressiv';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Baslinje';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avancerad';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-alternativ';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Tomma CSS-deklarationer';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&Ingen CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&xtern CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-alternativ';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Länk till externt JavaScript-skript:';