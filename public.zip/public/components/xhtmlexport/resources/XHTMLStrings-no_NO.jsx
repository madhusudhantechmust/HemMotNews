//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-no_NO.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'no_NO';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Avbryt';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/&Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Ekspo&rter XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Eksporter for Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Eksporter XHTML for Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Eksport av %1 som XHTML mislyktes.\nKan ikke opprette filen %2. Det er ikke sikkert at det er nok ledig plass, eller du har kanskje ikke tillatelse til å opprette filer på denne plasseringen.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Eksport av %1 som XHTML mislyktes.\nKan ikke opprette mappen %2. Det er ikke sikkert at det er nok ledig plass, eller du har kanskje ikke tillatelse til å opprette filer på denne plasseringen.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Eksport av %1 som XHTML mislyktes.\nKan ikke slette filen %2. Du har kanskje ikke tillatelse til å slette filer på denne plasseringen.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Eksporten krever en skriptfil som mangler.\nDen nødvendige skriptfilen %1 kan ikke åpnes, eller den mangler.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Ugyldig filnavn.\nFilnavnet %1 inneholder ett eller flere av disse ugyldige tegnene: \n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML-filen ble eksportert, men ett eller flere problemer ble oppdaget:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Koblede bilder: %1 mangler';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Koblede bilder: %1 er foreldet';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Innlimte bilder: %1 er hoppet over (bare koblede bilder eksporteres)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Koblede filmer: %1 mangler';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Filmer som ikke støttes: %1 er hoppet over (bare filmer med filtypen SWF eksporteres)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Eksporterer XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Trykk på Esc eller Kommando + punktum for å avbryte.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Trykk på Esc for å avbryte.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Eksporter';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML-eksportvalg';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Generelt';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Punktmerking og nummerering';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Eksporter';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Punktmerking:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Nummerering:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Tilordne til usorterte lister';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Tilordne til sorterte lister';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Tilordne til statisk sorterte lister';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Konverter til tekst';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Utvalg';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokument';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Bilder';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Kopier bilder:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Koble til serverbane';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimalisert';
xhtmlExportStrings.PATH[xhtmllocale] = 'B&ane på server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Fil&type:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formatert';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Bildekonvertering:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatisk';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-valg';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palett:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Tilpasset (ingen spredning)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Internett';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'System (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'System (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Linje&sprang';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-valg';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Bildekvalitet:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Lav';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Middels';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Høy';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maksimal';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Formaterings&metode:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Gradvis';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Grunnlinje';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avansert';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-valg';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Tomme CSS-deklarasjoner';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'I&ngen CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&kstern CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-valg';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Koble til eksternt JavaScript:';