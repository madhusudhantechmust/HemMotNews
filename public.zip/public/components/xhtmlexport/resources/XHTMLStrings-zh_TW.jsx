//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-zh_TW.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'zh_TW';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = '取消';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / Dreamweaver(&D)...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'XHTML 轉存(&R)';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Dreamweaver 轉存(&W)...';				//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Dreamweaver XHTML 轉存';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = '轉存「%1」為 XHTML 失敗。\n無法建立檔案「%2」。可能是因為可用空間不足，或是您沒有在此位置建立檔案的權限。';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = '轉存「%1」為 XHTML 失敗。\n無法建立檔案夾「%2」。可能是因為可用空間不足，或是您沒有在此位置建立檔案的權限。';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = '轉存「%1」為 XHTML 失敗。\n無法刪除檔案「%2」。您可能沒有在此位置刪除檔案的權限。';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = '遺失轉存所需的指令碼檔案。\n所需的指令碼檔案「%1」無法開啟，或已經遺失。';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = '不合法的檔案名稱。\n檔案名稱「%1」內含一個或多個這些不合法的字元:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML 檔案已經轉存，但是偵測到一個或多個問題:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = '連結的影像:%1 遺失';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = '連結的影像:%1 已過期';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = '貼上的影像:%1 已略過 (僅已轉存連結的影像)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = '連結的影片:%1 遺失';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = '不支援的影片:%1 已略過 (僅已轉存 .SWF 影片)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = '正在轉存 XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = '如果要取消，請按 Esc 鍵或 Cmd + 句號鍵。';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = '如果要取消，請按 Esc 鍵。';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = '轉存';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML 轉存選項';
xhtmlExportStrings.GENERAL[xhtmllocale] = '一般';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = '項目符號和編號';
xhtmlExportStrings.SCOPE[xhtmllocale] = '轉存';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '項目符號(&B):';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '編號(&N):';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = '對應至非順序清單';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = '對應至順序清單';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = '對應至靜態順序清單';
xhtmlExportStrings.ASTEXT[xhtmllocale] = '轉換為文字';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '選取範圍(&S)';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '文件(&D)';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = '影像';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '拷貝影像(&C):';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = '連結至伺服器路徑';
xhtmlExportStrings.ORIGS[xhtmllocale] = '原稿';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = '最佳化';
xhtmlExportStrings.PATH[xhtmllocale] = '伺服器上的路徑(&A):';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '檔案副檔名(&T):';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '格式化(&F)';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '影像轉換(&I):';
xhtmlExportStrings.AUTO[xhtmllocale] = '自動';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF 選項';
xhtmlExportStrings.PALETTE[xhtmllocale] = '浮動視窗(&P):';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = '最適化 (無混色)';
xhtmlExportStrings.WEB[xhtmllocale] = '網頁';
xhtmlExportStrings.SYSWIN[xhtmllocale] = '系統 (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = '系統 (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '交錯(&L)';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG 選項';
xhtmlExportStrings.QUALITY[xhtmllocale] = '影像品質(&Q):';
xhtmlExportStrings.LOW[xhtmllocale] = '低';
xhtmlExportStrings.MEDIUM[xhtmllocale] = '中';
xhtmlExportStrings.HIGH[xhtmllocale] = '高';
xhtmlExportStrings.MAX[xhtmllocale] = '最高';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '格式化方式(&M):';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = '漸進式';
xhtmlExportStrings.BASELINE[xhtmllocale] = '基線';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = '進階';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS 選項';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '清空 CSS 宣告(&E)';
xhtmlExportStrings.NOCSS[xhtmllocale] = '無 CSS(&O)';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '外部 CSS(&X):';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript 選項';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '連結至外部 JavaScript(&L):';