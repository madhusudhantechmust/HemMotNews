//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-zh_CN.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'zh_CN';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = '取消';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / Dreamweaver(&D)...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = '导出 XHTML(&R)';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = '为 Dreamweaver 导出(&W)...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = '为 Dreamweaver 导出 XHTML';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = '未能将“%1”导出为 XHTML。\n无法创建文件“%2”。可能是磁盘空间不足，也可能是您没有在此位置创建文件的权限。';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = '未能将“%1”导出为 XHTML。\n无法创建文件夹“%2”。可能是磁盘空间不足，也可能是您没有在此位置创建文件的权限。';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = '未能将“%1”导出为 XHTML。\n无法删除文件“%2”。您可能没有在此位置删除文件的权限。';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = '导出操作需要缺失的脚本文件。\n无法打开所需的脚本文件“%1”或该文件已缺失。';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = '非法文件名。\n文件名“%1”包括这些非法字符中的一个或多个:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML 文件已导出，但检测到一个或多个问题:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = '链接的图像: %1 缺失';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = '链接的图像: %1 已过时';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = '粘贴的图像: %1 已跳过（只导出链接的图像）';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = '链接的影片: %1 缺失';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = '不受支持的影片: %1 已跳过（只导出 .SWF 影片）';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = '正在导出 XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = '要取消，按 Esc 或 Cmd + 句点。';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = '要取消，按 Esc。';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = '导出';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML 导出选项';
xhtmlExportStrings.GENERAL[xhtmllocale] = '常规';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = '项目符号和编号';
xhtmlExportStrings.SCOPE[xhtmllocale] = '导出';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '项目符号(&B):';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '编号(&N):';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = '映射到无序列表';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = '映射到有序列表';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = '映射到静态有序列表';
xhtmlExportStrings.ASTEXT[xhtmllocale] = '转换为文本';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '选区(&S)';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '文档(&D)';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = '图像';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '复制图像(&C):';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = '链接到服务器路径';
xhtmlExportStrings.ORIGS[xhtmllocale] = '原始';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = '优化';
xhtmlExportStrings.PATH[xhtmllocale] = '服务器上的路径(&A):';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '文件扩展名(&T):';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '格式(&F)';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '图像转换(&I):';
xhtmlExportStrings.AUTO[xhtmllocale] = '自动';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF 选项';
xhtmlExportStrings.PALETTE[xhtmllocale] = '调板(&P):';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = '随样性（无仿色）';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = '系统 (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = '系统 (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '交错(&L)';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG 选项';
xhtmlExportStrings.QUALITY[xhtmllocale] = '图像品质(&Q):';
xhtmlExportStrings.LOW[xhtmllocale] = '低';
xhtmlExportStrings.MEDIUM[xhtmllocale] = '中';
xhtmlExportStrings.HIGH[xhtmllocale] = '高';
xhtmlExportStrings.MAX[xhtmllocale] = '最大值';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '格式方法(&M):';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = '连续';
xhtmlExportStrings.BASELINE[xhtmllocale] = '基线';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = '高级';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS 选项';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '空 CSS 声明(&E)';
xhtmlExportStrings.NOCSS[xhtmllocale] = '无 CSS(&O)';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '外部 CSS(&X):';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript 选项';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '链接到外部 JavaScript(&L):';