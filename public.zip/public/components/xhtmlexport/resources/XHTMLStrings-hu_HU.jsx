//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-hu_HU.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'hu_HU';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Mégse';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rtálás XHTML-ként';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Exportálás a Dream&weaver számára...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Exportálás XHTML-ként a Dreamweaver számára';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'A(z) “%1” XHTML-ként való exportálása nem sikerült.\nNem hozható létre a következő fájl: “%2”. Lehetséges, hogy nem áll rendelkezésre elegendő lemezterület, vagy nincs jogosultsága fájlok létrehozására ezen a helyen.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'A(z) “%1” XHTML-ként való exportálása nem sikerült.\nNem hozható létre a következő mappa: “%2”. Lehetséges, hogy nem áll rendelkezésre elegendő lemezterület, vagy nincs jogosultsága fájlok létrehozására ezen a helyen.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'A(z) “%1” XHTML-ként való exportálása nem sikerült.\nNem törölhető a következő fájl: “%2”. Lehetséges, hogy nincs jogosultsága fájlok törlésére ezen a helyen.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Az exportáláshoz hiányzik egy szkriptfájl.\nA szükséges szkriptfájl (“%1”) nem nyitható meg, vagy hiányzik.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Érvénytelen fájlnév.\nA(z) „%1” fájlnévben szerepel egy vagy több a következő tiltott karakterek közül:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Az XHTML-fájl exportálása sikerült, de legalább egy problémát észlelt a program:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Hivatkozott képek: %1 hiányzik';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Hivatkozott képek: %1 elavult';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Beillesztett képek: %1 kihagyva (csak a hivatkozott képek exportálása)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Hivatkozott mozgóképek: %1 hiányzik';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Nem támogatott mozgóképek: %1 kihagyva (csak az .SWF mozgóképek exportálása)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'XHTML exportálása';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'A megszakításhoz nyomja le az Esc billentyűt vagy a Cmd + Pont kombinációt.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'A megszakításhoz nyomja le az Esc billentyűt.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exportálás';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML-exportálás beállításai';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Általános';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Listák és számok';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exportálás';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Listák:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Számok:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Hozzárendelés rendezetlen listákhoz';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Hozzárendelés rendezett listákhoz';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Hozzárendelés statikus rendezett listákhoz';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Átalakítás szöveggé';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Kijelölés';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokumentum';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Képek';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Képek másolása:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Kiszolgálói elérési út hivatkozása';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Eredeti';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimalizált';
xhtmlExportStrings.PATH[xhtmllocale] = '&Elérési út a kiszolgálón:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Fájlki&terjesztés:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formázott';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Képátalakítás:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatikus';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-beállítások';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paletta:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptív (nincs árnyalás)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Rendszer (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Rendszer (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Váltott &soros';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-beállítások';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'Kép&minőség:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Alacsony';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Közepes';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Magas';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximális';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Formázási &módszer:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progresszív';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Alap';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Speciális';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-beállítások';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = 'Ü&res CSS-deklarációk';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'N&incs CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '&Külső CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-beállítások';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Hivatkozás külső JavaScript-szrkiptre:';