//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-de_DE.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'de_DE';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Abbrechen';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/&Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'XHTML expo&rtieren';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Für Dream&weaver exportieren...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'XHTML für Dreamweaver exportieren';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Das Exportieren von “%1” als XHTML ist fehlgeschlagen.\nDie Datei “%2” konnte nicht erstellt werden. Entweder ist nicht genügend freier Speicherplatz vorhanden oder Sie verfügen nicht über die entsprechenden Zugriffsrechte, um in diesem Verzeichnis Dateien zu erstellen.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Das Exportieren von “%1” als XHTML ist fehlgeschlagen.\nDer Ordner “%2” konnte nicht erstellt werden. Entweder ist nicht genügend freier Speicherplatz vorhanden oder Sie verfügen nicht über die entsprechenden Zugriffsrechte, um in diesem Verzeichnis Dateien zu erstellen.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Das Exportieren von “%1” als XHTML ist fehlgeschlagen.\nDie Datei “%2” konnte nicht gelöscht werden. Möglicherweise verfügen Sie nicht über die entsprechenden Zugriffsrechte, um in diesem Verzeichnis Dateien zu löschen.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Für den Export wird eine nicht vorhandene Skriptdatei benötigt.\nDie erforderliche Skriptdatei “%1” konnte nicht geöffnet werden oder ist nicht vorhanden';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Unzulässiger Dateiname.\nDer Dateiname “%1” enthält eines oder mehrere dieser unzulässigen Zeichen:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Die XHTML-Datei wurde exportiert, es gab aber folgende Probleme:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Verknüpfte Bilder: %1 nicht vorhanden';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Verknüpfte Bilder: %1 veraltet';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Eingefügte Bilder: %1 übersprungen (nur verknüpfte Bilder werden exportiert)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Verknüpfte Filme: %1 nicht vorhanden';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Nicht unterstützte Filme: %1 übersprungen (nur SWF-Filme werden exportiert)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'XHTML wird exportiert';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Zum Abbrechen Esc oder Bfhl + Punkt drücken.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Zum Abbrechen Esc drücken.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exportieren';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML-Exportoptionen';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Allgemein';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Aufzählungszeichen und Nummerierung';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exportieren';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Aufzählungszeichen:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Nummerierung:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Nicht sortierten Listen zuordnen';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Sortierten Listen zuordnen';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Statisch sortierten Listen zuordnen';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'In Text konvertieren';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = 'A&uswahl';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokument';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Bilder';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Bilder kopieren:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Mit Serverpfad verknüpfen';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimiert';
xhtmlExportStrings.PATH[xhtmllocale] = '&Serverpfad:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '&Dateierweiterung:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formatiert';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Bild&umwandlung:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatisch';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-Optionen';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palette:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Flexibel (ohne Dithering)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'System (Windows)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'System (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '&Interlace';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-Optionen';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'Bild&qualität:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Niedrig';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Mittel';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Hoch';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximal';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'F&ormatmethode:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Mehrere Durchgänge';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Grundlinie';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Erweitert';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-Optionen';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Leere CSS-Klassendeklarationen';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Kein &CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&xterne CSS-Datei';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-Optionen';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = 'Mit externer &JavaScript-Datei verknüpfen:';