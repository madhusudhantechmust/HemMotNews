//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-ar_AE.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//
//  Purpose: US English localization
//
//========================================================================================

var xhtmllocale = 'ar_AE';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'إلغاء الأمر';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'فشلت عملية تصدير “%1” كـ XHTML.\nلا يمكن إنشاء الملف “%2”؛ ربما يكون هذا نتيجة لعدم توفر مساحة كافية أو من المحتمل أن لا تكون لديك صلاحيات إنشاء ملفات على هذا الموقع.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'فشلت عملية تصدير “%1” كـ XHTML.\nلا يمكن إنشاء المجلد “%2”؛ ربما يكون هذا نتيجة لعدم توفر مساحة كافية أو من المحتمل أن لا تكون لديك صلاحيات إنشاء ملفات على هذا الموقع.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'فشلت عملية تصدير “%1” كـ XHTML.\nلا يمكن حذف الملف “%2”؛ من المحتمل أن لا تكون لديك صلاحيات حذف ملفات من على هذا الموقع.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'عملية التصدير في حاجة إلى ملف نص تفاعلي.\nلا يمكن فتح ملف النص التفاعلي “%1” أو أنه مفقود.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'اسم ملف غير صحيح.\n يحتوي الملف “%1” على حرف أو أكثر من الحروف غير المصرح باستخدامها التالية: \n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'تم تصدير ملف XHTML ولكن تم اكتشاف مشكلة واحدة أو أكثر:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'الصور المرتبطة: %1 مفقودة';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'الصور المرتبطة: %1 قديمة جداً';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'الصور الملصوقة: %1 تم تجاهلها (تم تصدير الصور المرتبطة فقط)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'الأفلام المرتبطة: %1 مفقودة';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'أفلام غير مدعومة: %1 تم تجاهلها (تم تصدير الأفلام ذات امتداد .SWF فقط)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'تصدير XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'لإلغاء الأمر، اضغط مفتاح الهروب Esc أو اضغط على مفتاحي الأوامر Cmd + مفتاح النقطة.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'لإلغاء الأمر، اضغط مفتاح الهروب Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'تصدير';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'خيارات تصدير XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'عام';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'التعداد النقطي والتعداد الرقمي';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'تصدير';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = 'التعداد النق&طي:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = 'التعداد الرق&مي:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'تحويل إلى قوائم غير مرتبة';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'تحويل إلى قوائم مرتبة';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'تحويل إلى قوائم مرتبة غير متغيرة';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'تحويل إلى نص';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = 'ت&حديد';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = 'وثي&قة';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'صور';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = 'ن&سخ الصور:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'ربط إلى مسار الخادم';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'أصلي';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'محسن';
xhtmlExportStrings.PATH[xhtmllocale] = 'المسار على ال&خادم:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'ام&تداد الملف:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = 'م&نسق';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'ت&حويل الصورة:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'تلقائي';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'خيارات GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = 'ال&لوحة:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'متكيف (بدون محاكاة)';
xhtmlExportStrings.WEB[xhtmllocale] = 'الويب';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'نظام التشغيل (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'نظام التشغيل (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'ت&شابك';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'خيارات JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'جو&دة الصورة:';
xhtmlExportStrings.LOW[xhtmllocale] = 'منخفض';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'متوسط';
xhtmlExportStrings.HIGH[xhtmllocale] = 'عالي';
xhtmlExportStrings.MAX[xhtmllocale] = 'حد أقصى';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'أسلوب ال&تنسيق:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'التقدم';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'الخط الأساسي';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'متقدم';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'خيارات CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = 'إ&خلاء تعريفات CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'ب&دون CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'CSS &خارجية:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'خيارات جافا سكريبت';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = 'ربط إلى جافاسكريبت خا&رجي:';