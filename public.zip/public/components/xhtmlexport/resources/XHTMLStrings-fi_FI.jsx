//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-fi_FI.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'fi_FI';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Peruuta';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/&Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Vie &XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Vie Dream&weaver -ohjelmaan...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Vie XHTML Dreamweaver-ohjelmaan';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Viedään %1, sillä XHTML epäonnistui.\nTiedoston %2 luonti epäonnistui. Käytettävissä ei ehkä ole riittävästi tilaa tai sinulla ei ole oikeutta luoda tiedostoja tähän sijaintiin.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Viedään %1, sillä XHTML epäonnistui.\nKansion %2 luonti epäonnistui. Käytettävissä ei ehkä ole riittävästi tilaa tai sinulla ei ole oikeutta luoda tiedostoja tähän sijaintiin.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Viedään %1, sillä XHTML epäonnistui.\nTiedoston %2 poistaminen epäonnistui. Sinulla ei ehkä ole oikeutta poistaa tiedostoja tästä sijainnista.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Vienti edellyttää puuttuvaa komentosarjatiedostoa.\nTarvittavaa komentosarjatiedostoa %1 ei voi avata tai se puuttuu.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Virheellinen tiedostonimi.\nTiedostonimi %1 sisältää ainakin yhden seuraavista merkeistä, joita ei sallita:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML-tiedosto vietiin, mutta havaittiin ainakin yksi virhe:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Linkitetyt kuvat: %1 puuttuu';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Linkitetyt kuvat: %1 vanhentunut';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Liitetyt kuvat: %1 ohitettu (vain linkitetyt kuvat viedään)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Linkitetyt kuvat: %1 puuttuu';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Elokuvat, joita ei tueta: %1 ohitettu (vain .SWF-elokuvat viedään)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Viedään XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Peruuta painamalla Esc-näppäintä tai komento- ja pistenäppäintä.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Peruuta painamalla Esc-näppäintä.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Vie';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML-vientiasetukset';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Yleiset';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Luettelomerkit ja numerointi';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Vie';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Luettelomerkit';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numerot:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Osoita järjestämättömiin luetteloihin';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Osoita järjestettyihin luetteloihin';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Osoita pysyviin järjestettyihin luetteloihin';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Muunna tekstiksi';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Valinta';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Julkaisu';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Kuvat';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Kuvien kopiointi:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Palvelinpolun linkki';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Alkuperäinen';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimoitu';
xhtmlExportStrings.PATH[xhtmllocale] = 'P&alvelimen polku:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = '&Tiedostotunniste:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Muotoiltu';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Kuvien &muuntaminen:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automaattinen';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-asetukset';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paletti:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Sovitettu (ei sirontaa)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Järjestelmä (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Järjestelmä (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '&Lomita';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-asetukset';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Kuvanlaatu:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Matala';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Normaali';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Korkea';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maksimi';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Muotoilumenetelmä:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Etenevä';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Perusviiva';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Lisäasetukset';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-asetukset';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = 'T&yhjennä CSS-määrittelyt';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&Ei CSS-määrittelyjä';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '&Ulkoinen CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-asetukset';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Ulkoisen JavaScriptin linkki:';