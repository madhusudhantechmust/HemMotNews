//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-ru_RU.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'ru_RU';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Отмена';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Экс&порт XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Экспорт для Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Экспорт XHTML для Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Ошибка экспорта %1 в формате XHTM.\nНе удалось создать файл %2. Возможно, недостаточно места на диске или отсутствует разрешение на создание файлов в этом местонахождении.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Ошибка экспорта %1 в формате XHTM.\nНе удалось создать папку %2. Возможно, недостаточно места на диске или отсутствует разрешение на создание файлов в этом местонахождении.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Ошибка экспорта %1 в формате XHTM.\nНе удалось удалить файл %2. Возможно, отсутствует разрешение на удаление файлов в этом местонахождении.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Отсутствует необходимый для экспорта файл сценария.\nФайл %1 не может быть открыт или отсутствует.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Недопустимое имя файла.\nИмя файла "%1" содержит один или несколько недопустимых символов:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Файл был экспортирован в формате XHTML, но во время экспорта произошли следующие ошибки:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Связанные изображения: %1 отсутствует';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Связанные изображения: %1 имеет некорректную дату';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Вставленные изображения: %1 пропущено (экспортируются только связанные изображения)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Связанные видеофрагменты: %1 отсутствует';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Неподдерживаемые видеофрагменты: %1 пропущено (экспортируются только видеофрагменты SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Идет экспорт XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Для отмены нажмите ESC или комбинацию клавиш CMD и Точка.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Для отмены нажмите клавишу ESC.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Экспорт';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Параметры экспорта XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Общие';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Маркеры и числа';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Экспорт';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Маркеры:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Числа:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Связать с неупорядоченными списками';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Связать с упорядоченными списками';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Связать со статическими упорядоченными списками';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Преобразовать в текст';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Выделение';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Документ';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Изображения';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Копировать изображения:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Связать с путем на сервере';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Исходное';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Оптимизированное';
xhtmlExportStrings.PATH[xhtmllocale] = 'П&уть на сервере:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Ра&сширение имени файла:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Форматированное';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Преобразование изображения:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Автоматически';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Параметры GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = 'П&алитра:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Адаптивно (без дизеринга)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Система (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Система (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Черес&строчно';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Параметры JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Качество изображений:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Низкое';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Среднее';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Высокое';
xhtmlExportStrings.MAX[xhtmllocale] = 'Максимальное';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Способ форматирования:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Последовательно';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'По базовой линии текста';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Дополнительно';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Параметры CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Пустые объявления CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Бе&з CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'В&нешние стили CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Параметры JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Связать с внешним кодом JavaScript:';