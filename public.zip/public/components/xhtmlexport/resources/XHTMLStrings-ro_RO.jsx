//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-ro_RO.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//
//  Purpose: US English localization
//
//========================================================================================

var xhtmllocale = 'ro_RO';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Anulare';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/&Dreamweaver...';


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Exportul elementului "%1" ca XHTML a eşuat.\nNu s-a putut crea fişierul "%2". Este posibil să nu existe suficient spaţiu disponibil, sau să nu deţineţi permisiuni pentru crearea de fişiere în această locaţie.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Exportul elementului "%1" ca XHTML a eşuat.\nNu s-a putut crea dosarul "%2". Este posibil să nu existe suficient spaţiu disponibil, sau să nu deţineţi permisiuni pentru crearea de fişiere în această locaţie.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Exportul elementului "%1" ca XHTML a eşuat.\nNu s-a putut şterge fişierul "%2". Este posibil să nu deţineţi permisiunea de a şterge fişiere din această locaţie.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Exportul necesită un fişier de script care lipseşte.\nFişierul de script necesar "%1" nu a putut fi deschis sau lipseşte.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Nume de fişier ilegal.\nNumele de fişier "%1" conţine cel puţin unul dintre următoarele caractere ilegale:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Fişierul XHTML a fost exportat dar a fost detectată cel puţin o problemă:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Imagini legate: %1 lipsesc';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Imagini legate: %1 nu sunt actualizate';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Imagini lipite: %1 au fost omise (sunt exportate numai imaginile legate)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Filme legate: %1 lipsesc';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Filme neacceptate: %1 au fost omise (sunt exportate numai filmele .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Se exportă elementul XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Pentru anulare, apăsaţi Esc sau Cmd + punct.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Pentru anulare, apăsaţi Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Export';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Opţiuni de export XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'General';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Marcatori şi numere';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Export';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Marcatori:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numere:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Mapare la liste neordonate';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Mapare la liste ordonate';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Mapare la liste ordonate static';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Conversie în text';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Selecţie';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Document';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Imagini';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Copiere imagini:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Legătură la calea de pe server';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimizat';
xhtmlExportStrings.PATH[xhtmllocale] = 'C&ale pe server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Extensie fişier:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formatat';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Conversie &imagine:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automat';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Opţiuni GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paletă:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptivă (fără cuantizare)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Sistem (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Sistem (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Întreţes&ere';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Opţiuni JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Calitate imagine:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Scăzută';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Medie';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Ridicată';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximă';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Metodă de &formatare:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progresivă';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Linie de bază';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avansată';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Opţiuni CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Declaraţii CSS goale';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Fă&ră CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'CSS e&xtern:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Opţiuni JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Legătură la JavaScript extern:';
