//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-it_IT.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'it_IT';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Annulla';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Espo&rta XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Esporta per Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Esporta XHTML per Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Esportazione di “%1” in XHTML non riuscita.\nImpossibile creare il file “%2”. Lo spazio su disco potrebbe non essere sufficiente oppure non disponete dell\'autorizzazione necessaria per creare file in questa posizione.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Esportazione di “%1” in XHTML non riuscita.\nImpossibile creare la cartella “%2”. Lo spazio su disco potrebbe non essere sufficiente oppure non disponete dell\'autorizzazione necessaria per creare file in questa posizione.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Esportazione di “%1” in XHTML non riuscita.\nImpossibile eliminare il file “%2”. È possibile che non disponiate delle autorizzazioni necessarie per eliminare file da questa posizione.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'L\'esportazione richiede un file script mancante.\nImpossibile aprire il file script “%1” oppure il file è mancante.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Nome file non valido.\nIl nome file “%1” contiene uno o più dei seguenti caratteri non validi:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Il file XHTML è stato esportato ma sono stati rilevati uno o più problemi:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Immagini collegate: %1 mancante(i)';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Immagini collegate: %1 non aggiornata(e)';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Immagini incollate: %1 ignorata(e) (vengono esportate solo le immagini collegate)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Filmati collegati: %1 mancante(i)';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Filmati non supportati: %1 ignorato(i) (vengono esportati solo i filmati .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Esportazione XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Per annullare, premete Esc o Cmd + . (punto).';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Per annullare, premete Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Esporta';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Opzioni esportazione XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Generali';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Elenchi puntati e numerati';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Esporta';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Punti elenco:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numeri:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Mappa su elenchi non ordinati';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Mappa su elenchi ordinati';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Mappa su elenchi ordinati statici';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Converti in testo';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Selezione';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Documento';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Immagini';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Copia immagini:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Collega a percorso su server';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Originale';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Ottimizzata';
xhtmlExportStrings.PATH[xhtmllocale] = 'P&ercorso su server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Es&tensione file:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formattate';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'Conversione &immagini:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatica';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Opzioni GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palette:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adattata (nessun dithering)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Sistema (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Sistema (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Inter&lacciamento';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Opzioni JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Qualità immagine:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Bassa';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Media';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Alta';
xhtmlExportStrings.MAX[xhtmllocale] = 'Massima';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Metodo formato:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressivo';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Linea di base';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avanzate';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Opzioni CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Svuota dichiarazioni CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Ness&un CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '&CSS esterno:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Opzioni JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = 'Co&llega a JavaScript esterno:';