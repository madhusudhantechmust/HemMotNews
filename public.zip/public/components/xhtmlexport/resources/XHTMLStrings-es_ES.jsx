//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-es_ES.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'es_ES';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Cancelar';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rtar XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Exportar para Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Exportar XHTML para Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Error al exportar “%1” como XHTML.\nNo se ha podido crear el archivo “%2”. Puede que no haya espacio disponible suficiente o puede que no tenga permiso para crear archivos en esta ubicación.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Error al exportar “%1” como XHTML.\nNo se ha podido crear la carpeta “%2”. Puede que no haya espacio disponible suficiente o puede que no tenga permiso para crear archivos en esta ubicación.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Error al exportar “%1” como XHTML.\nNo se ha podido eliminar el archivo “%2”. Puede que no tenga permiso para eliminar archivos en esta ubicación.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'La exportación requiere un archivo de script no disponible.\nNo se ha podido abrir el archivo de script requerido “%1” o no está disponible.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Nombre de archivo no válido.\nEl nombre de archivo “%1” contiene uno o varios caracteres no válidos:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Se ha exportado el archivo XHTML pero se han detectado uno o más problemas:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Imágenes vinculadas: %1 no disponibles';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Imágenes vinculadas: %1 no actualizadas';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Imágenes pegadas: %1 omitidas (sólo se exportan las imágenes vinculadas)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Películas vinculadas: %1 no disponibles';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Películas no admitidas: %1 omitidas (sólo se exportan las películas .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Exportando XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Para cancelar, pulse Esc o Cmd + Punto.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Para cancelar, pulse Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exportar';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Opciones de exportación XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'General';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Viñetas y números';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exportar';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Viñetas:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Números:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Asignar a listas desordenadas';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Asignar a listas ordenadas';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Asignar a listas ordenadas estáticas';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Convertir en texto';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Selección';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Documento';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Imágenes';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Copiar imágenes:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Vincular a ruta de servidor';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Originales';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimizadas';
xhtmlExportStrings.PATH[xhtmllocale] = 'R&uta en el servidor:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Ex&tensión de archivo:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = 'Con &formato';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'C&onversión de imagen:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automática';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Opciones de GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Paleta:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptada (sin simulación)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Sistema (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Sistema (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Entre&lazar';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Opciones de JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'C&alidad de imagen:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Baja';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Media';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Alta';
xhtmlExportStrings.MAX[xhtmllocale] = 'Máxima';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&Método de formato:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progresivo';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Línea de base';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avanzado';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Opciones de CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Vaciar declaraciones CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Si&n CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'CSS e&xterno:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Opciones de JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Vincular a JavaScript externo:';