//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-fr_FR.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'fr_FR';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Annuler';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML/&Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rter au format XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Exporter pour Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Exporter au format XHTML pour Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Echec de l’exportation de “%1” au format XHTML.\nImpossible de créer le fichier “%2”. L’espace disponible est peut-être insuffisant ou vous n’êtes peut-être pas autorisé à créer des fichiers à cet emplacement.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Echec de l’exportation de “%1” au format XHTML.\nImpossible de créer le dossier “%2”. L’espace disponible est peut-être insuffisant ou vous n’êtes peut-être pas autorisé à créer des fichiers à cet emplacement.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Echec de l’exportation de “%1” au format XHTML.\nImpossible de supprimer le fichier “%2”. Vous n’êtes peut-être pas autorisé à supprimer des fichiers de cet emplacement.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'L’exportation requiert un fichier de script introuvable.\nLe fichier de script “%1” n’a pas pu être ouvert ou est manquant.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Nom de fichier non autorisé.\nLe nom de fichier “%1” contient au moins un des caractères non autorisés suivants :\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Le fichier XHTML a été exporté mais un ou plusieurs problèmes ont été détectés :';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Images liées : %1 introuvable';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Images liées : %1 obsolète';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Images collées : %1 ignoré (seules les images liées sont exportées)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Vidéos liées : %1 introuvable';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Vidéos non prises en charge : %1 ignoré (seuls les fichiers .swf sont exportés)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Exportation XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Pour annuler, appuyez sur Echap ou sur Cmde+Point.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Pour annuler, appuyez sur Echap.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Exporter';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Options d’exportation XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Général';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Puces et numéros';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Exporter';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = 'P&uces :';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numéros :';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Faire correspondre à des listes non triées';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Faire correspondre à des listes triées';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Faire correspondre à des listes triées statiques';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Convertir en texte';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Sélection';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Document';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Images';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Copier des images :';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Lier au chemin d’accès au serveur';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Originales';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimisées';
xhtmlExportStrings.PATH[xhtmllocale] = 'C&hemin d’accès sur le serveur :';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Ex&tension de fichier :';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Mises en forme';
xhtmlExportStrings.CONVERSION[xhtmllocale] = 'C&onversion d’image :';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatique';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Options GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palette :';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptative (sans simulation)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Système (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Système (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '&Entrelacement';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Options JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = '&Qualité de l’image :';
xhtmlExportStrings.LOW[xhtmllocale] = 'Minimale';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Moyenne';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Elevée';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximale';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Mé&thode de mise en forme :';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressive';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Ligne de base';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avancé';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Options CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = 'Déclarations CSS &vides';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'P&as de CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'CSS e&xterne :';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Options de script JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Lier à un script JavaScript externe :';