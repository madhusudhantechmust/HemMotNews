//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-ja_JP.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'ja_JP';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'キャンセル';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML・Dreamweaver(&D)...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'XHTML を書き出し(&R)';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Dreamweaver 用に書き出し(&W)...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'XHTML を Dreamweaver 用に書き出し...';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = '「%1」の XHTML 形式での書き出しに失敗しました。\nファイル「%2」を作成できませんでした。空き容量が不足しているか、この場所にファイルを作成するための権限がない可能性があります。';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = '「%1」の XHTML 形式での書き出しに失敗しました。\nフォルダ「%2」を作成できませんでした。空き容量が不足しているか、この場所にファイルを作成するための権限がない可能性があります。';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = '「%1」の XHTML 形式での書き出しに失敗しました。\nファイル「%2」を削除できませんでした。この場所にあるファイルを削除するための権限がない可能性があります。';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = '書き出しに必要なスクリプトファイルがありません。\n必要なスクリプトファイル「%1」が開けないか、または見つかりません。';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = '不正なファイル名です。\nファイル名「%1」には、次の不正な文字が 1 つ以上含まれています :\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML ファイルは書き出されましたが、1 つ以上の問題が検出されました :';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'リンクされた画像 : %1 個見つかりません';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'リンクされた画像 : %1 個が期限切れです';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'ペーストされた画像 : %1 個スキップされました (リンクされた画像のみ書き出されます)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'リンクされたムービー : %1 個見つかりません';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'サポートされていないムービー : %1 個スキップされました (.SWF ムービーのみ書き出されます)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'XHTML を書き出し中';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'キャンセルするには、Esc キーまたは Command+ ピリオドを押します。';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'キャンセルするには、Esc キーを押します。';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = '書き出し';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML 書き出しオプション';
xhtmlExportStrings.GENERAL[xhtmllocale] = '一般';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = '箇条書き';
xhtmlExportStrings.SCOPE[xhtmllocale] = '書き出し';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '記号(&B) :';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '番号(&N) :';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = '番号なしリストにマップ';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = '番号付きリストにマップ';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = '静的番号付きリストにマップ';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'テキストに変換';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '選択範囲(&S)';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = 'ドキュメント(&D)';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = '画像';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '画像をコピー(&C) :';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'サーバパスにリンク';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'オリジナル';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = '最適化';
xhtmlExportStrings.PATH[xhtmllocale] = 'サーバ上のパス(&A) :';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'ファイル拡張子(&T) :';
xhtmlExportStrings.FORMATTED[xhtmllocale] = 'フォーマット(&F)';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '画像変換(&I) :';
xhtmlExportStrings.AUTO[xhtmllocale] = '自動';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF オプション';
xhtmlExportStrings.PALETTE[xhtmllocale] = 'パレット(&P) :';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = '使用中の色に合わせて割り付ける (ディザなし)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'システム (Windows)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'システム (Macintosh)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'インターレース(&L)';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG オプション';
xhtmlExportStrings.QUALITY[xhtmllocale] = '画質(&Q) :';
xhtmlExportStrings.LOW[xhtmllocale] = '低';
xhtmlExportStrings.MEDIUM[xhtmllocale] = '中';
xhtmlExportStrings.HIGH[xhtmllocale] = '高';
xhtmlExportStrings.MAX[xhtmllocale] = '最高';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'フォーマット(&M) :';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'プログレッシブ';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'ベースライン';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = '詳細';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS オプション';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '空の CSS 宣言(&E)';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'CSS なし(&O)';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = '外部 CSS(&X) :';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript オプション';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '外部 JavaScript にリンク(&L) :';
