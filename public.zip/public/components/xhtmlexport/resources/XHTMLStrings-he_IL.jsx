//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-he_IL.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//
//  Purpose: US English localization
//
//========================================================================================

var xhtmllocale = 'he_IL';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'בטל';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'ייצוא “%1” כ- XHTML נכשל.\nלא ניתן ליצור את הקובץ “%2”. ייתכן שאין מספיק זיכרון זמין, או שאין לכם הרשאה ליצירת קבצים במיקום זה.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'ייצוא “%1” כ- XHTML נכשל.\nלא ניתן ליצור את התיקייה “%2”. ייתכן שאין מספיק זיכרון זמין, או שאין לכם הרשאה ליצירת קבצים במיקום זה.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'ייצוא “%1” כ- XHTML נכשל.\nלא ניתן למחוק את הקובץ “%2”. ייתכן שאין לכם הרשאה למחיקת קבצים במיקום זה.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'הייצוא דורש קובץ סקריפט חסר.\nלא ניתן לפתוח את קובץ הסקריפט הדרוש “%1” או שהוא חסר.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'שם קובץ לא חוקי.\nשם הקובץ “%1” כולל אחד או יותר מהתווים הלא-חוקיים הבאים:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'ייצוא קובץ XHTML בוצע בהצלחה, אך התגלתה בעיה אחת או יותר:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'תמונות מקושרות: %1 חסרה/ות';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'תמונות מקושרות: %1 לא מעודכנת/ות';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'תמונות שהודבקו: %1 לא נכללה/ו (בוצע ייצוא רק של תמונות מקושרות)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'סרטים מקושרים: %1 חסר/ים';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'סרטים לא נתמכים: %1 לא נכלל/ו (בוצע ייצוא רק של סרטי .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'מייצא XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'לביטול, הקישו Esc או Cmd + נקודה.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'הקישו Esc לביטול.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'ייצוא';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'אפשרויות ייצוא XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'כללי';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'תבליטים ומספור';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'ייצוא';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&תבליטים:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&מספור:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'מפה לרשימות לא מסודרות';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'מפה לרשימות מסודרות';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'מפה לרשימות מסודרות סטטיות';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'המר למלל';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&בחירה';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&מסמך';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'תמונות';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&העתק תמונות:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'קישור לנתיב שרת';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'מקור';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'ממוטב';
xhtmlExportStrings.PATH[xhtmllocale] = '&נתיב לשרת:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'סיומת& קובץ:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&מעוצב';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&המרת תמונה';
xhtmlExportStrings.AUTO[xhtmllocale] = 'אוטומטי';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'אפשרויות GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&חלונית:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'מותאם (ללא מיזוג)';
xhtmlExportStrings.WEB[xhtmllocale] = 'אינטרנט';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'מערכת (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'מערכת (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = '&שזירה';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'אפשרויות JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'איכות &תמונה:';
xhtmlExportStrings.LOW[xhtmllocale] = 'נמוכה';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'בינונית';
xhtmlExportStrings.HIGH[xhtmllocale] = 'גבוהה';
xhtmlExportStrings.MAX[xhtmllocale] = 'מרבית';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = '&שיטת תבנית:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'מודרג';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'קו בסיס';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'מתקדם';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'אפשרויות CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&ריקון הצהרות CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&ללא CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'CSS &חיצוני:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'אפשרויות JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&קישור ל- JavaScript חיצוני:';