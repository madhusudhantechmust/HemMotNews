//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-da_DK.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'da_DK';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Annuller';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Ekspo&rter XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Eksporter til Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Export XHTML til Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Eksport af "%1" som XHTML mislykkedes.\nFilen "%2" kunne ikke oprettes. Der er muligvis ikke nok ledig plads, eller du har muligvis ikke rettigheder til at oprette filer på denne placering.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Eksport af "%1" som XHTML mislykkedes.\nMappen "%2" kunne ikke oprettes. Der er muligvis ikke nok ledig plads, eller du har muligvis ikke rettigheder til at oprette filer på denne placering.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Eksport af "%1" som XHTML mislykkedes.\nFilen "%2" kunne ikke slettes. Du har muligvis ikke rettigheder til at slette filer i denne placering.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Eksport kræver en script-fil, der mangler.\nDen påkrævede script-fil "%1" kunne ikke åbnes eller mangler.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Ugyldigt filnavn.\nFilnavnet "%1" indeholder et eller flere af disse ugyldige tegn:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'XHTML-filen blev eksporteret, men der opstod et eller flere problemer:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Lænkede billeder: %1 mangler';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Lænkede billeder: %1 forældet';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Indsatte billeder: %1 sprunget over (kun lænkede billeder eksporteres)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Lænkede film: %1 mangler';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Ikke-understøttede film: %1 sprunget over (kun .SWF-film eksporteres)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Eksporterer XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Tryk på Esc eller Cmd + punktum for at annullere.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Tryk på Esc for at annullere.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Eksport';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML-eksportindstillinger';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Generelt';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Punkttegn og nummerering';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Eksport';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Punkttegn:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numre:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Knyt til usorterede lister';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Knyt til sorterede lister';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Knyt til statisk sorterede lister';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Konverter til tekst';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Markering';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Dokument';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Billeder';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Kopier billeder:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Lænke til serversti';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimeret';
xhtmlExportStrings.PATH[xhtmllocale] = '&Sti på server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Filt&ype:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formateret';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Billedkonvertering:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatisk';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF-indstillinger';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palet:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptiv (ingen rastersimulering)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'System (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'System (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Inter&lace';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG-indstillinger';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'Billed&kvalitet:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Lav';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Middel';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Høj';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maksimum';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Format&metode:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressiv';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Grundlinje';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Avanceret';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS-indstillinger';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Tøm CSS-deklarationer';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'Ing&en CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&kstern CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript-indstillinger';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Lænke til eksternt JavaScript:';