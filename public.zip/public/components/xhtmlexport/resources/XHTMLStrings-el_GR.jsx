//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/resources/XHTMLStrings-el_GR.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//
//  Purpose: US English localization
//
//========================================================================================

var xhtmllocale = 'el_GR';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Άκυρο';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Η εξαγωγή του “%1” ως XHTML απέτυχε.\nΔεν ήταν δυνατή η δημιουργία του αρχείου “%2”. Ίσως να μην υπάρχει αρκετός χώρος διαθέσιμος ή δεν έχετε επαρκή δικαιώματα για τη δημιουργία αρχείων σε αυτή την τοποθεσία.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Η εξαγωγή του “%1” ως XHTML απέτυχε.\nΔεν ήταν δυνατή η δημιουργία του φακέλου “%2”. Ίσως να μην υπάρχει αρκετός χώρος διαθέσιμος ή δεν έχετε επαρκή δικαιώματα για τη δημιουργία αρχείων σε αυτή την τοποθεσία.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Η εξαγωγή του “%1” ως XHTML απέτυχε.\nΔεν ήταν δυνατή η διαγραφή του αρχείου “%2”. Ίσως να μην έχετε επαρκή δικαιώματα για τη διαγραφή αρχείων σε αυτή την τοποθεσία.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Για την εξαγωγή απαιτείται ένα αρχείο script το οποίο λείπει.\nΤο άνοιγμα του απαιτούμενου αρχείου script “%1” δεν ήταν δυνατό ή το αρχείο λείπει.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Illegal filename.\nΤο όνομα αρχείου “%1” περιέχει έναν ή περισσότερους από τους παρακάτω μη επιτρεπόμενους χαρακτήρες:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'Η εξαγωγή του αρχείου XHTML πραγματοποιήθηκε, αλλά εντοπίστηκαν ένα ή περισσότερα προβλήματα:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Συνδεδεμένες εικόνες: Η εικόνα %1 λείπει';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Συνδεδεμένες εικόνες: Η εικόνα %1 δεν είναι ενημερωμένη';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Επικολλημένες εικόνες: Η εικόνα %1 παραλείφθηκε (είναι δυνατή η εξαγωγή μόνο συνδεδεμένων εικόνων)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Συνδεδεμένες ταινίες: Η ταινία %1 λείπει';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Μη υποστηριζόμενες ταινίες: Η ταινία %1 παραλείφθηκε (είναι δυνατή η εξαγωγή μόνο ταινιών .SWF)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Εξαγωγή XHTML σε εξέλιξη';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'Για ακύρωση, πατήστε Esc ή Cmd + τελεία.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'Για ακύρωση, πατήστε Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Εξαγωγή';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'Επιλογές εξαγωγής XHTML';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'Γενικά';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Κουκκίδες και αριθμοί';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Εξαγωγή';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Κουκκίδες:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Αριθμοί:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Αντιστοίχηση σε μη ταξινομημένες λίστες';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Αντιστοίχηση σε ταξινομημένες λίστες';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Αντιστοίχηση σε στατικές ταξινομημένες λίστες';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Μετατροπή σε κείμενο';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Επιλογή';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = 'Έγγρ&αφο';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Εικόνες';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Αντιγραφή εικόνων:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Σύνδεση σε διαδρομή server';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Πρωτότυπη';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Βελτιστοποιημένη';
xhtmlExportStrings.PATH[xhtmllocale] = 'Δ&ιαδρομή στον server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'Επέκταση &αρχείου:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Μορφοποιημένη';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Μετατροπή εικόνας:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Αυτόματη';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'Επιλογές GIF';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Παλέτα:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Προσαρμοσμένη (χωρίς ανάμειξη)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'Σύστημα (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'Σύστημα (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Σύμ&πλεξη';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'Επιλογές JPEG';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'Ποιότητα &εικόνας:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Χαμηλή';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Μεσαία';
xhtmlExportStrings.HIGH[xhtmllocale] = 'Υψηλή';
xhtmlExportStrings.MAX[xhtmllocale] = 'Μέγιστη';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Μέθοδος μ&ορφοποίησης:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Προοδευτική';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Γραμμή βάσης';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Για προχωρημένους';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'Επιλογές CSS';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Κενές δηλώσεις CSS';
xhtmlExportStrings.NOCSS[xhtmllocale] = '&Χωρίς CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'Εξ&ωτερικό CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'Επιλογές JavaScript';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Σύνδεση σε εξωτερικό JavaScript:';