//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/XHTMLExport.jsx $
//  
//  Owner: Jonathan W. Brown
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Export all or a list of items of a document to XHTML
//  
//========================================================================================

//===========================
//  Include libraries
//===========================

#show include
#include "includes/XHTMLUtils.jsx"
#include "includes/NoUIProgressBar.jsx"
#include "includes/XHTMLOptions.jsx"
#include "includes/XHTMLItemSorter.jsx"
#include "includes/XHTMLOutputBuffer.jsx"
#include "includes/XHTMLStyleList.jsx"
#include "includes/XHTMLStoryContext.jsx"
#include "includes/XHTMLDocumentContext.jsx"
#include "includes/XHTMLStrings.jsx"
#include "includes/XHTMLStrings-en_US.jsx"

//------------------------------------------------------------------------------
// Constructor
//------------------------------------------------------------------------------

function XHTMLExporter(scriptFilePath)
{
	// if the export fails this will contain the error object
	this.error = undefined;
	
	// if the export succeeds these will contain any warnings
	this.missingImageLinks = undefined;
	this.missingMovieLinks = undefined;
	this.outOfDateLinks = undefined;
	this.numImagesDroppedOut = undefined;
	this.numMoviesDroppedOut = undefined;
	
	// this must contain a file object referencing this script file
	// XHTMLExporter needs this to be able to load resources
	this.scriptFilePath = scriptFilePath;
	
	// this is a utf-8 encoded string that contains a snippet of XHTML
	// with some optional placeholders that will be used to embed SWF files.
	// if this is undefined the script will load it from the template file
	// resources/swf_template.html
	// the placeholders are:
	//		${swf}				the local URL of the file
	//		${width}			the width of the SWF as placed in InDesign
	//		${height}			the height of the SWF as placed in InDesign
	this.swfTemplate = undefined;
	
	// the progress bar
	this.pBar = undefined;
	// the active html export options
	this.options = undefined;
	// keeps track of all css classes used
	this.classes = undefined;
	// keeps track of all story uids so that we don't export the same story twice
	this.exportedStories = undefined;
	// keeps track of all images so that we don't copy/convert the same image twice
	this.exportedImages = undefined;
	// keeps track of the ids used during the export
	this.idGenerator = undefined;
	
	// the images folder
	this.imagesfolder = undefined;
	this.imagesURL = undefined;
	
	// current document
	this.docContext = undefined;

	// keeping track of current story context
	this.currentStoryStack = [];

	// keep track of all the styles
	this.objStyleList = undefined;
	this.paraStyleList = undefined;
	this.charStyleList = undefined;
	this.listList = undefined;
	this.tableStyleList = undefined;
	this.cellStyleList = undefined;
	
	// stack of preferenceContexts that need to be restored after the export is done
	this.prefsContexts = [];
	
	// suppress hyperlinks to other documents
	// notice that you will need to postprocess the list of hyperlinks in the
	// document context to prepend the urls with the proper document name
	this.suppressCrossDocLinks = true;
} // XHTMLExporter

// this object requires a certain version of the scripting DOM
XHTMLExporter.prototype.requiredDOMVersion = 6.0;

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.doExport
// Call this to export items to XHTML
//
//	Arguments:
// document is the document to export from
// items is an array of things to export (must all be items from document)
// 		it can contain page items, stories, images, 
// 		text ranges (insertion points, lines, characters, paragraphs),
//		and/or cell ranges
//		if items is undefined or an empty array we 
//		export all page items of document instead
// opts is an XHTMLOptions object
// file is a File object determining where to save the XHTML file
// progressBar is an optional object of class ProgressBar
//
//	returns true if the export succeeded
//		you may want to check the properties missingLinks,
// 		numImagesDroppedOut and outOfDateLinks for any warnings that were 
//		encountered during export
//	returns false if the export failed
//		you may want to check the property error which in this case
//		contains an Error object detailing the error that caused the failure.
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.doExport = function(document, items, opts, file, progressBar) {
	var success = true;
	
	this.initialize();
	
	success = this.prepareExport(document, items, opts, file, progressBar)
	if(success) {
		// first generate the body, so that we know which classes to put into the CSS section
		this.pBar.newSection(1, '', .99);
		if(success) {
			success = this.exportBody();
		}
		this.pBar.sectionCompleted();
	
		this.pBar.newSection(1, '', .05);
		if(success) {
			success = this.finalizeExport();
		}
		this.pBar.sectionCompleted();
		
		this.pBar.newSection(1, '', .05);
		if(success) {
			success = this.saveExportFile();
		}
		this.pBar.sectionCompleted();
	}
	
	this.cleanup();
	
	return (this.error == undefined);
} // XHTMLExporter.prototype.doExport


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.initialize
// Is called by doExport 
// Set/Reset member variables
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.initialize = function() {
	this.prefsContexts = [];
	
	this.error = undefined;
	this.missingImageLinks = [];
	this.missingMovieLinks = [];
	this.outOfDateLinks = [];
	this.numImagesDroppedOut = 0;
	this.numMoviesDroppedOut = 0;
	
	this.classes = {};
	this.exportedStories = {};
	this.exportedImages = {};
	this.idGenerator = new XHTMLExporterIDGenerator();
	
	this.docContext = undefined;
	this.imagesfolder = undefined;
	this.imagesURL = undefined;
	this.imagesExtension = undefined;
	this.currentStoryStack = [];

	this.objStyleList = new XHTMLStyleList(XHTMLStyleList.objStyleConverter);
	this.paraStyleList = new XHTMLStyleList(XHTMLStyleList.paraStyleConverter);
	this.charStyleList = new XHTMLStyleList(XHTMLStyleList.charStyleConverter);
	this.listList = new XHTMLStyleList(XHTMLStyleList.listConverter);
	this.tableStyleList = new XHTMLStyleList(XHTMLStyleList.tableStyleConverter);
	this.cellStyleList = new XHTMLStyleList(XHTMLStyleList.cellStyleConverter);
	
	this.headbuffer = undefined;
	this.bodybuffer = undefined;
	
	// reserve hardcoded div classes
	this.objStyleList.reserveClass('story');
	this.objStyleList.reserveClass('footnotes');
	this.objStyleList.reserveClass('footnote');
	this.objStyleList.reserveClass('group');
	this.objStyleList.reserveClass('image');
	
	if (this.scriptFilePath == undefined)
	{
		try
		{
			this.scriptFilePath = app.activeScript.path;
		}
		catch(e)
		{
			// we are running from the ESTK
			this.scriptFilePath = File(e.fileName).path;
		}
	}
} // initialize


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.prepareExport
// Is called by doExport 
// Validates the export parameters and prepares for the export
// Returns false on failure
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.prepareExport = function(document, items, opts, file, progressBar) {
	// set up InDesign's scripting preferences
	var scriptPrefsContext = new XHTMLUtils.prefsContext(app.scriptPreferences);
	scriptPrefsContext.setPreference('version', this.requiredDOMVersion);
	this.prefsContexts.push(scriptPrefsContext);

	try {
		// make sure that the measurement uints are set to points
		var viewPrefs = document.viewPreferences;
		if((viewPrefs.horizontalMeasurementUnits != MeasurementUnits.points) || 
			(viewPrefs.verticalMeasurementUnits != MeasurementUnits.points)) {
				var viewPrefsContext = new XHTMLUtils.prefsContext(viewPrefs);
				viewPrefsContext.setPreference('horizontalMeasurementUnits', MeasurementUnits.points);
				viewPrefsContext.setPreference('verticalMeasurementUnits', MeasurementUnits.points);
				// by pushing the viewPrefsContext on the prefsContexts stack we
				// make sure that the old settings are getting restored once we are done
				this.prefsContexts.push(viewPrefsContext);
		}
	
		// get output file name and make sure it is legal
		this.filename = XHTMLUtils.nameWithoutExt(file.displayName);
		if(!XHTMLUtils.isLegalFileName(this.filename)) {
			throw new XHTMLError(xhtmlExportStrings.ILLEGALFILENAMEERROR, this.filename);
		} 
		
		// save off the export options to be used for this export
		this.options = opts;
		this.file = file;
		
		// make sure that the options are synchronized with the web
		// image conversion preferences in the document
		opts.resolveWithWebExportSettings(document);
		
		// establish what items we have to export
		this.exportItems = this.getExportList(document, items);
	
		// set up output buffers
		// we use two seperate buffers since we generate the header
		// after we are done with the body
		this.headbuffer = new XHTMLOutputBuffer();
		this.bodybuffer = new XHTMLOutputBuffer(this.classes);
		this.bodybuffer.suppressClassAttributes = (this.options.styleHandling == XHTMLExportOptions.noStyles);
		this.bodybuffer.level = 1;
		this.headbuffer.outpath = this.bodybuffer.outpath = file.path;
	
		// get info about the document
		this.docContext = new XHTMLDocumentContext(document, this.idGenerator.newID(this.filename), this.idGenerator, this.suppressCrossDocLinks);
	
		// prepare the images folder
		this.prepareImagesFolder(file);
	
		// create dummy progressbar if necessary
		if(progressBar == undefined) {
			this.pBar = new NoUIProgressBar();
		} else {
			this.pBar = progressBar;
		}
	} catch(x) {
		// catch any error that occurs
		this.error = x;
	}
	return (this.error == undefined);
} // prepareExport


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.exportBody
// Is called by doExport 
// Iterates over the list of export items and fills in the body
//	export buffer
// Returns false on failure
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.exportBody = function() {
	try {
		this.bodybuffer.openElementContext('body');
		this.processItems(this.bodybuffer, this.exportItems, '', this.docContext.docid);
		this.bodybuffer.closeElementContext('body');
	} catch(x) {
		// catch any error that occurs
		this.error = x;
	}
	return (this.error == undefined);
} // exportBody


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.finalizeExport
// Is called by doExport 
// Fills in the header export buffer
// Returns false on failure
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.finalizeExport = function() {
	try {
		this.finalizeXHTML(this.bodybuffer);
		this.createHeader(this.headbuffer, this.filename);
	} catch(x) {
		// catch any error that occurs
		this.error = x;
	}
	return (this.error == undefined);
} // finalizeExport


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.saveExportFile
// Is called by doExport 
// Saves out header and body into the file specified during prepare
// Returns false on failure
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.saveExportFile = function() {
	try {
		this.save(this.file, this.headbuffer, this.bodybuffer);
	} catch(x) {
		// catch any error that occurs
		this.error = x;
	}
	return (this.error == undefined);
} // saveExportFile


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.cleanup
// Is called by doExport 
// Needs to get called even if export fails
//------------------------------------------------------------------------------
	
XHTMLExporter.prototype.cleanup = function() {
	// restore any preferences we might have changed
	while(this.prefsContexts.length > 0) {
		this.prefsContexts.pop().restoreOldValues();
	}
	
	// close the progress bar
	if(this.pBar != undefined) {
		this.pBar.close();
	}
	
	// convert error to standard Error object
	if(this.error != undefined) {
		if('errorString' in this.error) {
			this.error = new Error(this.error.errorString);
		}
	}
} // cleanup


//------------------------------------------------------------------------------
// END OF PUBLIC SECTION
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.getExportList
// Establish and return a sorted list of items to export
//------------------------------------------------------------------------------

XHTMLExporter.prototype.getExportList = function(document, items) {
	// determine and filter the list of items to export
	var exportWholeDocument = (items == undefined || items.length == 0);
	var exportList = (exportWholeDocument ? this.filterItems(this.allContainersInDocument(document), exportWholeDocument) : this.filterItems(items, exportWholeDocument));

	// sort the list of items to export
	if(exportList.length > 0) {
		if(document.documentPreferences.pageBinding == PageBindingOptions.rightToLeft) {
			XHTMLItemSorter.sortVertically(exportList, exportWholeDocument);
		} else {
			XHTMLItemSorter.sortLeftToRight(exportList, exportWholeDocument);
		}
	}
	return exportList;
}

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.prepareImagesFolder
//------------------------------------------------------------------------------

XHTMLExporter.prototype.prepareImagesFolder = function(file) {
	// prepare the images folder and URL
	if(this.options.imageHandling == XHTMLExportOptions.linkToServerPath){
		this.imagesURL = XHTMLUtils.encodeUserSuppliedURL(this.options.serverPath);
		if(this.imagesURL.length > 0 && this.imagesURL[this.imagesURL.length - 1] != '/') {
			this.imagesURL += '/';
		}
		this.imageExtension = XHTMLUtils.encodeUserSuppliedURL(this.options.imageExtension);
		if(this.imageExtension.length > 0 && this.imageExtension[0] != '.') {
			this.imageExtension = '.' + this.imageExtension;
		}
	} else {
		var folderbasename = (this.filename + ' web images').replace(/\s/g, '-'); // replace spaces with dashes
		var foldername = folderbasename;
		this.imagesfolder = Folder(file.path + '/' + foldername + '/');
		if(this.imagesfolder.exists) {
			if(file.exists) {
				// the output file exists as well, so this is an update
				// delete all files within the folder
				// we do not delete any folders within the folder
				var files = this.imagesfolder.getFiles();
				for (var i in files) {
					if(!files[i].remove())
					throw new XHTMLError(xhtmlExportStrings.DELETEFILEERROR, this.docContext.doc.name, files[i].displayName);
				}
			} else {
				// find a unique name for the images folder
				var i = 0;
				while (this.imagesfolder.exists) {
					i++;
					foldername = folderbasename + '-' + i;
					this.imagesfolder = Folder(file.path + '/' + foldername + '/');
				}
			}
		}
		this.imagesURL = encodeURIComponent(foldername) + '/';
	}
}

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.save
// Save the body and header buffers to file
//------------------------------------------------------------------------------

XHTMLExporter.prototype.save = function(file, head, body) {
	var success = file.open('w');
	if(!success) {
		throw new XHTMLError(xhtmlExportStrings.FILEERROR, this.docContext.doc.name, file.displayName);
	}
	
	file.encoding = 'UTF-8';
		
	try {
		var buffers = head.getbuffers();
		for(var i in buffers) {
			success = file.write(buffers[i]);
			if(!success) {
				throw new XHTMLError(xhtmlExportStrings.FILEERROR, this.docContext.doc.name, file.displayName);
			}
		} 
	
		buffers = body.getbuffers();
		for(var i in buffers) {
			success = file.write(buffers[i]);
			if(!success) {
				throw new XHTMLError(xhtmlExportStrings.FILEERROR, this.docContext.doc.name, file.displayName);
			}
		}
	} catch (x) {
		// try to close the file
		file.close();
		throw x;
	}
	success = file.close();
	if(!success) {
		throw new XHTMLError(xhtmlExportStrings.FILEERROR, this.docContext.doc.name, file.displayName);
	}
} // XHTMLExporter.prototype.save


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.createHeader
//------------------------------------------------------------------------------

XHTMLExporter.prototype.createHeader = function(buffer, filename) {
	var encoding = 'utf-8';
 	// no prolog if we are using utf8 to avoid setting IE into quirks mode
	//buffer.writeln('<?xml version="1.0" encoding="' + encoding + '"?>');
	buffer.writeln("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
	buffer.openElementContext('html','', 'xmlns="http://www.w3.org/1999/xhtml"');
	buffer.openElementContext('head');
	buffer.writeElement('', 'meta', '', 'http-equiv="content-type" content="text/html;charset=' + encoding + '"');
	buffer.writeElement(this.cleantext(filename), 'title');
	
	// CSS styles
	switch (this.options.styleHandling) {
		case XHTMLExportOptions.emptyStyles:
			buffer.writeln('<style type="text/css" media="screen"><!--');
			buffer.indent();
				
				// sort class list
			var classlist = [];
			for(var cls in this.classes) {
				classlist.push(cls);
			}
			classlist.sort();
				
			// write out the list
			for(var i in classlist) {
				buffer.writeln(classlist[i] + ' {}');
			}

			buffer.unindent();
			buffer.writeln('--></style>');			
		break;
		case XHTMLExportOptions.extStyleSheet:
			buffer.writeln('<link href="' + XHTMLUtils.encodeUserSuppliedURL(this.options.styleSheet) + '" rel="stylesheet" type="text/css" />');
		break;
	}
	
	// JavaScripts
	if(this.options.linkToJavaScript) {
		buffer.writeln('<script type="text/javascript" src="' + XHTMLUtils.encodeUserSuppliedURL(this.options.javaScriptURL) + '"></script>');
	}
	
	buffer.closeElementContext('head');
}



//------------------------------------------------------------------------------
// XHTMLExporter.prototype.finalizeXHTML
//------------------------------------------------------------------------------

XHTMLExporter.prototype.finalizeXHTML = function(buffer) {
	buffer.closeElementContext('html');
} // XHTMLExporter.prototype.finalizeXHTML

//------------------------------------------------------------------------------
// Methods that walk the dom and process the data
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processItems
// Process a list of items. Wraps items in a div if either cls is provided
// or the number or elements is greater than 1 and we are not inside a paragraph
//------------------------------------------------------------------------------

// helper method that counts the elements that would get generated
// if items are exported, stops counting at stopAtCount
XHTMLExporter.prototype.countElements = function(items, stopAtCount) {
	var count = items.length;
	var elemCount = 0;
	
	for(var i = 0; i < count && elemCount < stopAtCount; i++) {
		var item = items[i];
		switch(item.constructor.name) {
			case "Story":
			case "TextPath":
			case "PDF":
			case "Image":
			case "PICT":
			case "WMF":
			case "EPS":
			case "ImportedPage":
			case "Movie":
			case "Table":
			case "Cell":
			case "Text":
			case "TextStyleRange":
			case "Word":
			case "Paragraph":
			case "Character":
			case "TextColumn":
			case "Line":
				elemCount++;
			break;
			case "TextFrame":
				elemCount++;
				if('textPaths' in item) {
					elemCount += item.textPaths.length;
				}
			break;
			case "Rectangle":
			case "Polygon":
			case "Oval":
			case "GraphicLine":
			case "Group":
				var children =  XHTMLExporter.getChildren(item);
				elemCount += this.countElements(children, stopAtCount - elemCount)
			break;
		}
	}
	
	return elemCount;
}

// helper method to figure out whether a list of items would result
// into more than one elements
XHTMLExporter.prototype.generatesMoreThanOneElement = function(items) {
	return this.countElements(items, 2) > 1;
}


XHTMLExporter.prototype.processItems = function(buffer, items, cls, id) {
	// figure out whether we need to wrap these items into a div
	var isgroup = (!XHTMLUtils.isEmptyString(cls)) || (!XHTMLUtils.isEmptyString(id)) || ((!this.isInline()) && (items.length > 1));
	if(isgroup && XHTMLUtils.isEmptyString(cls) && XHTMLUtils.isEmptyString(id)) {
		// avoid empty or single item groups
		isgroup = this.generatesMoreThanOneElement(items);
	}
	
	if(isgroup) {
		if(XHTMLUtils.isEmptyString(id)) {
			buffer.openElementContext('div', XHTMLUtils.isEmptyString(cls) ? 'group' : cls);
		} else {
			buffer.openElementContext('div', '', 'id="' + id + '"');
		}
	}
	
	var item;
	var iter = new XHTMLProgressIterator(items, this.pBar);
	while((item = iter.next()) != null) {
		switch (item.constructor.name) {
			case "Text":
			case "TextStyleRange":
			case "Word":
			case "Paragraph":
			case "Character":
			case "TextColumn":
			case "Line":
				this.processTextRange(buffer, item);
			break;
			case "Story":
				this.processStory(buffer, item);
			break;
			case "TextPath":
				this.processStory(buffer, item.parentStory);
			break;
			case "TextFrame":
			case "Rectangle":
			case "Polygon":
			case "Oval":
			case "GraphicLine":
			case "Group":
				this.processContainer(buffer, item);
			break;
			case "PDF":
			case "Image":
			case "PICT":
			case "WMF":
			case "EPS":
			case "ImportedPage":
				this.processImage(buffer, item);
			break;
			case "Movie":
				this.processMovie(buffer, item);
			break;
			case "Table":
				this.processTable(buffer, item);
			break;
			case "Cell":
				this.processTable(buffer, item.parent, item);
			break;
		}
	}
	if(isgroup) {
		buffer.closeElementContext('div');
	}
}

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processContainer
//------------------------------------------------------------------------------

// helper method to deal with collection objects
XHTMLExporter.addToList = function(items, list) {
	var count = items.length;
	for (var i = 0; i < count; i++)
		list.push(items[i]);
}

// helper method to collect all children of a page item
XHTMLExporter.getChildren = function(parent) {
	var list = [];
	XHTMLExporter.addToList(parent.groups, list);
	XHTMLExporter.addToList(parent.rectangles, list);
	XHTMLExporter.addToList(parent.ovals, list);
	XHTMLExporter.addToList(parent.polygons, list);
	XHTMLExporter.addToList(parent.textFrames, list);
	XHTMLExporter.addToList(parent.graphicLines, list);
	if('movies' in parent) {
		XHTMLExporter.addToList(parent.movies, list);
	}
	if('images' in parent) {
		XHTMLExporter.addToList(parent.images, list);
		XHTMLExporter.addToList(parent.epss, list);
		XHTMLExporter.addToList(parent.pdfs, list);
		XHTMLExporter.addToList(parent.wmfs, list);
		XHTMLExporter.addToList(parent.picts, list);
	}
	if('importedPages' in parent) {
		XHTMLExporter.addToList(parent.importedPages, list);
	}
	if('textPaths' in parent) {
		XHTMLExporter.addToList(parent.textPaths, list);
	}
	
	return list;
}

XHTMLExporter.prototype.processContainer = function(buffer, item) {
	// get the list of items
	if(item.constructor.name == "TextFrame") {
		var items = [];
		XHTMLExporter.addToList(item.textPaths, items);
		items.push(item.parentStory);
	} else {
		var items = XHTMLExporter.getChildren(item);
	}
	
	items = this.filterItems(items, true);
	
	if(items.length > 0) {
		// sort items
		if(items.length > 1) {	
			if(this.docContext.doc.documentPreferences.pageBinding == PageBindingOptions.rightToLeft) {
				XHTMLItemSorter.sortVertically(items, false);
			} else {
				XHTMLItemSorter.sortLeftToRight(items, false);
			}
		}
		
		// figure out whether we can process the items now or need to postpone them for later processing
		var firstItemType = items[0].constructor.name;
		var isSingleImage = items.length == 1 && ((firstItemType == "Image") || 
								(firstItemType == "PDF") || (firstItemType == "EPS") || 
								(firstItemType == "WMF") || (firstItemType == "PICT") ||
								(firstItemType == "ImportedPage"));
		var postponeItems = this.isInline() && !isSingleImage;
	
		var currentStory = this.currentStoryContext();
		if(postponeItems) {
			// need to postpone processing until the current paragraph is done
			currentStory.inlineQueue.push(items);
		} else {	// process items right away
			var currentPara = (currentStory == undefined) ? undefined : currentStory.currentPara;
			if(isSingleImage && currentPara != undefined && currentPara.nestedInlinesLevel == 0) {
				// make sure that the current paragraph is open
				// but only if we are not nested inside another inline
				currentStory.openParagraph(buffer);
			}
			if(currentPara != undefined) {
				//prevent nested inline image from opening the paragraph 
				currentPara.nestedInlinesLevel++;
			}
			this.processItems(buffer, items);
			if(currentPara != undefined) {
				currentPara.nestedInlinesLevel--;
			}
		}
	}
} // XHTMLExporter.prototype.processContainer

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processTableCell
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processTableCell = function(buffer, table, tableid, cellInfo) {
	// get column span and row span for merged cells
	var attr = '';
	if (cellInfo.colSpan > 1) {
		attr += ' colspan="' + cellInfo.colSpan + '"';
	}
	if (cellInfo.rowSpan > 1) {
		attr += ' rowspan="' + cellInfo.rowSpan + '"';
	}
	
	// figure out tag and class attribute
	var mapping = this.cellStyleList.getClassAndTag(cellInfo.style);
	var tag = mapping.tag;
	var cls = mapping.cssclass;
	
	buffer.openElementContext(tag, cls, attr);

	if(cellInfo.contents.length > 0) {
		// process the paragraphs within the story context
		var contextID = tableid + '-' + cellInfo.id.toString();
		
		// omitting the tag and cls parameters in the call to  
		// processSoryContext establishes a story context without 
		// creating a corresponding <div> element
		var cell = table.cells.itemByID(cellInfo.id);
		this.processStoryContext(buffer, contextID, cell, undefined, undefined, cell.paragraphs, cell.textStyleRanges, cellInfo.contents, 0, cellInfo.contents.length);
	}
	
	buffer.closeElementContext(tag);
} // XHTMLExporter.prototype.processTableCell


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processTableRow
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processTableRow = function(buffer, table,  tableid, cells, columnStart, columnCount, maxRowSpan) {	
	var cellCount = cells.length;
	var lastColumn = columnStart + columnCount - 1;
	
	// export this row if it contains cells
	if (cellCount > 0) {
		var element = 'tr';
		buffer.openElementContext(element);
		
		this.pBar.newSection(cellCount, '', 1)
		for (var i = 0; i < cellCount; i++) {
			if(cells[i].rowSpan > maxRowSpan) {
				cells[i].rowSpan = maxRowSpan;
			}
			var maxColSpan = (lastColumn - cells[i].column) + 1;
			if(cells[i].colSpan > maxColSpan) {
				cells[i].colSpan = maxColSpan;
			}
			this.processTableCell(buffer, table, tableid, cells[i]);
			this.pBar.sectionStepCompleted();
		}
		this.pBar.sectionCompleted();
		
		buffer.closeElementContext(element);
	}
} // XHTMLExporter.prototype.processTableRow



//------------------------------------------------------------------------------
// XHTMLExporter.prototype.getCellRange
// Gather all data we need for the range of cells and return in an array
//------------------------------------------------------------------------------

XHTMLExporter.prototype.getCellRange = function(table, rowStart, rowCount, columnStart, columnCount) {
	var rangeStartString = '' + columnStart + ':' + rowStart;
	var rangeEndString = '' + (columnStart + columnCount -1) + ':' + (rowStart + rowCount -1);
	var everyCell = table.cells.itemByRange(rangeStartString, rangeEndString).cells.everyItem();
	var styles = everyCell.appliedCellStyle;
	var colSpans = everyCell.columnSpan;
	var rowSpans = everyCell.rowSpan;
	var contents = everyCell.contents;
	var ids = everyCell.id;
	var names = everyCell.name;
	
	var cells = [];
	var count = names.length;
	if(count != styles.length || count != styles.length || count != colSpans.length || count != rowSpans.length ||
		count != contents.length || count != ids.length) {
			alert('Something is wrong');
	}
	for (var i = 0; i < count; i++) {
		var coordinates = names[i].split(':');
		var row = parseInt(coordinates[1]);
		var col = parseInt(coordinates[0]);
		if(col < columnStart) {
			col = columnStart;
		}
		var cellInfo = { style: styles[i], colSpan: colSpans[i], rowSpan: rowSpans[i], contents: contents[i],
							id: ids[i], column: col };
		if(cells[row] == undefined) {
			cells[row] = [cellInfo];
		} else {
			cells[row].push(cellInfo);
		}
	}
	
	return cells;
}

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processTableSection
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processTableSection = function(buffer, tag, table, tableid, rowStart, rowCount, columnStart, columnCount) {
	// get cells:
	var cells = this.getCellRange(table, rowStart, rowCount, columnStart, columnCount);
	
	buffer.openElementContext(tag);
	
	this.pBar.newSection(rowCount, '', 1);
	var lastRow = rowStart + rowCount - 1;
	for (var i = rowStart; i <= lastRow; i++) {
		this.processTableRow(buffer, table, tableid, cells[i], columnStart, columnCount, (lastRow - 1) + 1);
		this.pBar.sectionStepCompleted();
	}
	this.pBar.sectionCompleted();
	
	buffer.closeElementContext(tag);
} // XHTMLExporter.prototype.processTableSection

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processTable
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processTable = function(buffer, table, cell) {
	// figure out tag and class attribute
	var tableid = table.id.toString();
	var style = table.appliedTableStyle;
	var mapping = this.tableStyleList.getClassAndTag(style);
	var tag = mapping.tag;
	var cls = mapping.cssclass;
	
	// determine the size of the table and its components
	var headerCount = table.headerRowCount;
	var	headerStart = 0;
	var bodyCount = table.bodyRowCount;
	var	bodyStart = headerCount;
	var footerCount = table.footerRowCount;
	var	footerStart = bodyStart + bodyCount;
	var columnCount = table.columnCount;
	var	columnStart = 0;

	// the following block adjusts the values above when we
	// export a selection within the table
	if (cell != undefined) {
		var cellRows = cell.rows;
		var cellColumns = cell.columns;
		
		var rowCount = cellRows.count();
		columnCount = cellColumns.count();
		if (columnCount == 0 || rowCount == 0) {
			return;
		}
				
		columnStart = cellColumns[0].index;
		var rowStart = cellRows[0].index;
		
		// check header rows
		var tempHeaderCount = 0;
		if (rowStart < bodyStart) {
			// the selection includes header cells
			headerStart = rowStart;
			tempHeaderCount = bodyStart - rowStart;
			if (tempHeaderCount > rowCount) {
				tempHeaderCount = rowCount;
			}
			// move on to the body section
			rowStart = bodyStart;
			rowCount -= tempHeaderCount;
		}
		
		// check body rows
		if (rowCount > 0 && rowStart < footerStart) {
			// the selection includes body cells
			bodyStart = rowStart;
			bodyCount = footerStart - rowStart;
			if (bodyCount > rowCount) {
				bodyCount = rowCount;
			}
					
			// move on to the footer section
			rowStart = footerStart;
			rowCount -= bodyCount;
		} else {
			bodyCount = 0;	// no body rows are selected, we will export an empty body row later
		}
		
		// check footer rows
		var tempFooterCount = 0;
		if (rowCount > 0)
		{
			// there are rows left, so the selection must include footer cells
			footerStart = rowStart;
			tempFooterCount = rowCount;
		}
		
		if (bodyCount == 0 || tempHeaderCount > 0 || tempFooterCount > 0) {
			// if only body rows are selected, export the corresponding header and footer rows as well
			headerCount = tempHeaderCount;
			footerCount = tempFooterCount;
		}
	}
	
	buffer.openElementContext(tag, cls);

	// export header rows
	if (headerCount > 0) {
		this.processTableSection(buffer, 'thead', table, tableid, headerStart, headerCount, columnStart, columnCount);
	}
		
	// footer rows must appear after header rows and before body rows	
	if (footerCount > 0) {
		this.processTableSection(buffer, 'tfoot', table, tableid,  footerStart, footerCount, columnStart, columnCount);
	}
		
	// export body rows
	if (bodyCount > 0) {
		this.processTableSection(buffer, 'tbody', table, tableid, bodyStart, bodyCount, columnStart, columnCount);
	}
	else {
		// export an empty body row if no boy rows are selected since a table must have at least one body row
		buffer.openElementContext('tbody');
		buffer.openElementContext('tr');
		for (var i = 0; i < columnCount; i++) {
			buffer.openElementContext('td');
			buffer.closeElementContext('td');
		}
		buffer.closeElementContext('tr');
		buffer.closeElementContext('tbody');
	}
		
	buffer.closeElementContext(tag);
} // XHTMLExporter.prototype.processTable


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.checkImageFolder
//------------------------------------------------------------------------------

XHTMLExporter.prototype.checkImageFolder = function() {
	if(!this.imagesfolder.exists) {
		if(!this.imagesfolder.create()) {
			throw new XHTMLError(xhtmlExportStrings.CREATEFOLDERERROR, this.docContext.doc.name, this.imagesfolder.displayName);
		}
	}
}

//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processImage
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processImage = function(buffer, image) {
	var link = image.itemLink;
	if(image.parent.constructor.name == 'Movie') {
		// this is the poster image of a movie
		this.processMovie(buffer, image.parent)
	} else if(link != undefined && link != null) {
		var status = link.status;
		var origfilepath = link.filePath;
		var origfile = File(origfilepath);
		var filename = undefined; // the name of the exported image file
		
		if(this.options.imageHandling == XHTMLExportOptions.linkToServerPath) {
			if(status == LinkStatus.linkMissing || status == LinkStatus.linkEmbedded) {
				var basename = encodeURIComponent(XHTMLUtils.nameWithoutExt(link.name.replace(/\//g,':')));
			} else {
				var basename = encodeURIComponent(XHTMLUtils.nameWithoutExt(origfile.displayName));
			}
			filename = basename + this.imageExtension;
		} else {
			var copyformattedimages = ((this.options.imageHandling == XHTMLExportOptions.copyOptimized) && this.options.formatted);
		
			if(!copyformattedimages) {
				// check whether we have exported this image before
				filename = this.exportedImages[origfilepath];
			}
			
			if(filename == undefined && !origfile.exists && this.options.imageHandling == XHTMLExportOptions.copyOriginal) {
				// handle missing link
				this.missingImageLinks.push(origfile);
				filename = origfile.displayName;
				if(!copyformattedimages) {
					this.exportedImages[origfilepath] = filename;
				}
			}
		
			if(filename == undefined) {
				// link isn't missing and we haven't copied this file yet
				this.checkImageFolder();
				try {
					var newfile = image.exportForWeb(this.imagesfolder)[0];
					if(XHTMLUtils.isEmptyString(newfile)) {
						throw new Error();
					}
				} catch (x) {
					throw new XHTMLError(xhtmlExportStrings.FILEERROR, this.docContext.doc.name, origfile.displayName);
				}
				
				// check for out of date links
				if(this.options.imageHandling == XHTMLExportOptions.copyOptimized) {
					if(status == LinkStatus.linkOutOfDate) {
						this.outOfDateLinks.push(origfile);
					}
				}
				
				filename = File(newfile).displayName;
				if(!copyformattedimages) {
					this.exportedImages[origfilepath] = filename;
				}
			}
		}
		
		// figure out style
		var imgclass = this.objStyleList.getClassAndTag(image.appliedObjectStyle).cssclass;
		var frameclass = this.objStyleList.getClassAndTag(image.parent.appliedObjectStyle).cssclass;
			
		// write the img element
		var path = this.imagesURL + encodeURIComponent(filename);
		if(status == LinkStatus.linkMissing || status == LinkStatus.linkEmbedded) {
			// origfile.displayName contains the whole path in case of missing or embedded
			// links so we just take a generic string in this case
			var alt = "missing image file";
		} else {
			var alt = origfile.displayName;
		}
		var attributes = 'src="' + path + '" alt="' + XHTMLUtils.entitytizeAttributeValue(alt) + '"';
		if(this.isInline()) {
			if(!XHTMLUtils.isEmptyString(frameclass)) {
				buffer.openElementInline('span', frameclass);
			}
			buffer.writeElementInline('', 'img', XHTMLUtils.isEmptyString(imgclass) ? frameclass : imgclass, attributes);
			if(!XHTMLUtils.isEmptyString(frameclass)) {
				buffer.closeElementInline('span');
			}
		} else {
			buffer.openElementContext('div', XHTMLUtils.isEmptyString(frameclass) ? 'image' : frameclass);
			buffer.writeElement('', 'img', imgclass, attributes);
			buffer.closeElementContext('div');
		}
	} else {
		this.numImagesDroppedOut++;
	}
} // XHTMLExporter.prototype.processImage


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processMovie
//------------------------------------------------------------------------------

XHTMLExporter.prototype.loadSWFTemplate = function() {
	var templateFile = new File(this.scriptFilePath + "/resources/swf_template.html");
	
	if(templateFile.exists) {
		// read template
		templateFile.open();
		this.swfTemplate = templateFile.read();
		templateFile.close();
		// remove comments and gratitous line breaks
		this.swfTemplate = this.swfTemplate.replace(/[\n\r]+/g, '\n');
		this.swfTemplate = this.swfTemplate.replace(/^#.*\n/mg, '');
		
	} else {
		throw new XHTMLError(xhtmlExportStrings.LOADSCRIPTERROR, templateFile.displayName);
	}
}

XHTMLExporter.prototype.processMovie = function(buffer, movie) {
	// figure out whether it is a web based movie or a local file
	try {
		var isLocalFile = false;
		var fileSpecifier = XHTMLUtils.encodeUserSuppliedURL(movie.url);
		var moviename = movie.url.split('/').pop();
	} catch (x) {
		var isLocalFile = true;
		var fileSpecifier = movie.filePath;
		var status = movie.itemLink.status;
		if(status == LinkStatus.linkMissing || status == LinkStatus.linkEmbedded) {
			var moviename = movie.name.replace(/\//g,':');
		} else {
			var moviename = File(fileSpecifier).displayName;
		}
	}
	
	if(!XHTMLUtils.isEmptyString(fileSpecifier) && XHTMLUtils.getExtension(fileSpecifier).toLowerCase() == 'swf') {
		var moviebasename = XHTMLUtils.nameWithoutExt(moviename);
		var extension = XHTMLUtils.getExtension(moviename);

		if(isLocalFile) {
			// local movie file
			var movieFile = new File(fileSpecifier);
			if(this.options.imageHandling == XHTMLExportOptions.linkToServerPath) {
				fileSpecifier =  this.imagesURL + encodeURIComponent(moviename);
			} else {
				var filename = this.exportedImages[fileSpecifier];
				if(filename == undefined) {
					// we haven't copied this movie yet
					this.checkImageFolder();
					if(!movieFile.exists) {
						this.missingMovieLinks.push(movieFile);
						filename = movieFile.displayName;
					} else {
						// handle case when different movie files with same name exist
						var folderpath = this.imagesfolder.fullName + '/';
						var number = 0;
						filename = moviename;
						while(File(folderpath + filename).exists) {
							number++;
							filename = moviebasename + '-' + number + '.' + extension;
						}
						this.exportedImages[fileSpecifier] = filename;
						if (!movieFile.copy(folderpath + filename)) {
							throw new XHTMLError(xhtmlExportStrings.FILEERROR, this.docContext.doc.name, unescape(movieFile.displayName));
						}
					}
				}
				fileSpecifier = this.imagesURL + encodeURIComponent(filename);
			}
		}
	
		if(!XHTMLUtils.isEmptyString(fileSpecifier)) {
			// figure out the dimensions of the movie
			// we assume that the measurment units are set to points
			try {
				var width = Math.ceil(movie.geometricBounds[3] - movie.geometricBounds[1]);
				var height = Math.ceil(movie.geometricBounds[2] - movie.geometricBounds[0]);
			} catch(x) {
				// the movie is in overset
				// we just make up some numbers so that the movie
				// shows up in the XHTML
				var width = 200;
				var height = 200;
			}
			
			if(this.swfTemplate == undefined) {
				// need to first load the SWF template
				this.loadSWFTemplate();
			}
			var swif = this.swfTemplate.replace(/\${swf}/g, fileSpecifier);
			var swif = swif.replace(/\${width}/g, width);
			var swif = swif.replace(/\${height}/g, height);
			var swif = swif.replace(/\${id}/g, this.idGenerator.newID(moviebasename));
			
			if(this.isInline()) {
				this.openCurrentPara(buffer);
			}
			buffer.insertBlob(swif);
		}
	} else {
		this.numMoviesDroppedOut++;
	}
} // XHTMLExporter.prototype.processMovie
	

//------------------------------------------------------------------------------
// XHTMLSpanHelper
// helper object that manages a <span> element
//------------------------------------------------------------------------------

function XHTMLSpanHelper(tag, cls, attr) {
	this.isopen = false;
	this.tag = tag;
	this.cls = cls;
	this.attr = attr;
	this.currentHyperlink = undefined;
}

XHTMLSpanHelper.prototype.open = function(buffer) {
	if(!this.isopen) {
		buffer.openElementInline(this.tag, this.cls, this.attr);
		this.isopen = true;
	}
}

XHTMLSpanHelper.prototype.close = function(buffer) {
	if(this.currentHyperlink != undefined) {
		buffer.closeElementInline('a');
		this.currentHyperlink = undefined;
	}
	if(this.isopen) {
		buffer.closeElementInline(this.tag);
		this.isopen = false;
	}
}


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processSpan
// Outputs a single text span. This is more complicated than one would think
// since there might be inlines, tables etc. in the text.
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processSpan = function(buffer, storyContext, rangeOffsetStart, rangeOffsetEnd, style, openSpan) {
	// figure out class and element names for the span
	var stylemapping = this.charStyleList.getClassAndTag(style);		//bottleneck
	
	// get items to export within this text range
	// this can be tables, inlines, footnotes, variables and text anchors
	var items = storyContext.children;
	while(items.length > 0 && (items[0].index < rangeOffsetStart)) {
		// remove any items before the text range
		items.shift();
	}

	if(openSpan == undefined) {
		openSpan = new XHTMLSpanHelper('span', '');
	}
	
	// count items to export
	var numitems = items.length;
	var numitemsinrange = 0;
	var i = 0;
	while(i<numitems && (items[i].index <= rangeOffsetEnd)) {
		i++;
		numitemsinrange++;
	}
	// we assume that there is text before and after each inline item
	var progresssteps = (2*numitemsinrange)+1;
	
	// get hyperlinks after the start of this text range
	var hyperlinksList = this.docContext.hyperlinks[storyContext.contextID];
	if (hyperlinksList != undefined) {
		while(hyperlinksList.length > 0 && hyperlinksList[0].end <= rangeOffsetStart) {
			hyperlinksList.shift();
		}
	}
	
	// set up the progress bar
	this.pBar.newSection(progresssteps);
	
	var hyperlink = undefined;	// keep track of current hyperlink
	var curOffsetStart = rangeOffsetStart; // keep track of start of current chunk
	var curOffsetEnd = rangeOffsetEnd + 1;	// points to the first character after the chunk
	while (curOffsetStart <= rangeOffsetEnd) {
		// check if there's a hyper link in the chunk
		if (hyperlink != undefined)	{
			if (curOffsetStart == curOffsetEnd)	{ // curOffsetEnd points to the end of the current hyperlink
				// end of a hyperlink
				hyperlinksList.shift();
				hyperlink = undefined;
			}
		}

		if (hyperlink == undefined)	{
			curOffsetEnd = rangeOffsetEnd + 1;
			
			if (hyperlinksList != undefined && hyperlinksList.length > 0) {
				if (hyperlinksList[0].start <= curOffsetStart)	{
					// inside a hyperlink
					if (hyperlinksList[0].end <= rangeOffsetEnd)
						curOffsetEnd = hyperlinksList[0].end;
					// else	curOffsetEnd = rangeOffsetEnd + 1;
					hyperlink = hyperlinksList[0];
				} else {
					// outside a hyperlink
					if (hyperlinksList[0].start <= rangeOffsetEnd)
						curOffsetEnd = hyperlinksList[0].start;
					hyperlink = undefined;
				}
			}
		}
		
		var processed = false;
		// check if there's an item in the chunk
		if (numitemsinrange > 0) {
			var item = items[0]; // since we are removing items from the list we always work with the first item
			var itemOffset = item.index;
			if (itemOffset == curOffsetStart)	{
				this.pBar.sectionStepCompleted();	// advance progress bar for any text before item
				
				// output the item
				switch(item.constructor.name) {
					case 'XHTMLTable':
						// close the current span before we process the table
						openSpan.close(buffer);
						openSpan = new XHTMLSpanHelper('span', '');
						this.closeCurrentPara(buffer);	// make sure the table is not part of a paragraph
						this.processTable(buffer, item.table);
					break;
					case 'XHTMLInline':
						openSpan.close(buffer);
						openSpan = new XHTMLSpanHelper('span', '');
						this.processContainer(buffer, item.inline);
					break;
					case 'XHTMLFootnote':
						var footnote = storyContext.addFootnote(item.footnote, this.idGenerator);
						buffer.writeAnchorInline('[' + footnote.number.toString() + ']', footnote.backlinkname, 'footnote-link', 'href="#' + footnote.name + '"');
					break;
					case 'XHTMLVariable':
						openSpan = this.outputchunk(item.text, stylemapping.cssclass, stylemapping.tag, buffer, openSpan, hyperlink);
					break;
					case 'XHTMLAnchor':
						buffer.writeAnchorInline('', items[0].name);
					break;
				}
		
				// increment pos etc.
				curOffsetStart = itemOffset + 1;
				items.shift();
				numitemsinrange--;
				this.pBar.sectionStepCompleted();
				processed = true;
			} else if (itemOffset < curOffsetEnd) {
				curOffsetEnd = itemOffset;
			}
		}
		
		if (!processed)	{
			openSpan = this.outputchunk(storyContext.storyContents.substr(curOffsetStart, curOffsetEnd - curOffsetStart), stylemapping.cssclass, stylemapping.tag, buffer, openSpan, hyperlink);
			curOffsetStart = curOffsetEnd;
		}
	}
	
	// advance progress bar for any text after the last item
	this.pBar.sectionCompleted();
	
	return openSpan;
} // XHTMLExporter.prototype.processSpan


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.outputchunk
// Used by processSpan to output actual text
// Handles hyperlinks
//------------------------------------------------------------------------------

XHTMLExporter.prototype.outputchunk = function(s, cls, tag, buffer, openSpan, hyperlink) {
	if(s.length == 0)
		return openSpan;
		
	s = this.cleantext(s);
	if (s.length == 0 || (s.length == 1 && s[0] == ' ' && !this.isInline())) {
		// don't output single trailing white space at the beginning of a paragraph
		// this has the side effect that empty parragraphs get skipped
		return openSpan;
	}
	
			
	this.openCurrentPara(buffer);
		
	if(openSpan.tag != tag || openSpan.cls != cls) {
		openSpan.close(buffer);
		openSpan = new XHTMLSpanHelper(tag, cls);
		if(tag != 'span' || cls != '') {
			openSpan.open(buffer);
		}
	} else if(openSpan.currentHyperlink != undefined && (hyperlink == undefined || hyperlink.id != openSpan.currentHyperlink.id)) {
		buffer.closeElementInline('a');
		openSpan.currentHyperlink = undefined;
	}
	
	if(hyperlink != undefined && openSpan.currentHyperlink == undefined) {
		buffer.openElementInline('a', '', 'href="' + hyperlink.url  + '"');
		openSpan.currentHyperlink = hyperlink;
	}
	
	buffer.write(s);
	
	return openSpan;
} // XHTMLExporter.prototype.outputchunk


//------------------------------------------------------------------------------
// Helper methods to manage the current story context, paragraph and open lists
//
// The open- and closeCurrentPara methods are used to
// 	1. delay opening a paragraph so that we don't end up with empty paragraphs 
// 		in case of e.g. a paragraph only consisting of a table
// 	2. temporarily close a paragraph in order to e.g. pull a 
//		table out of its paragraph 
//------------------------------------------------------------------------------

// return the current story context or undefined
XHTMLExporter.prototype.currentStoryContext = function() {
	return this.currentStoryStack.length > 0 ? this.currentStoryStack[this.currentStoryStack.length - 1] : undefined;
}

// check whether we are in a paragraph element
XHTMLExporter.prototype.isInline = function() {
	var storyContext = this.currentStoryContext();
	
	return (storyContext != undefined && storyContext.currentPara != undefined && storyContext.currentPara.isOpen);
}

// open the current paragraph
XHTMLExporter.prototype.openCurrentPara = function(buffer) {
	var storyContext = this.currentStoryContext();
	if (storyContext != undefined) {
		storyContext.openParagraph(buffer);
	}
}

// close the current paragraph
XHTMLExporter.prototype.closeCurrentPara = function(buffer) {
	var storyContext = this.currentStoryContext();
	if (storyContext != undefined) {
		storyContext.closeParagraph(buffer);
		
		// since the paragraph context is now closed
		// we can process any stories that got queued up
		storyContext.currentPara.nestedInlinesLevel++;	// prevent inline images from reopening the paragraph
		while(storyContext.inlineQueue.length > 0) {
			this.processItems(buffer, storyContext.inlineQueue.shift());
		}
		storyContext.currentPara.nestedInlinesLevel--;
	}
}


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processParagraph
//	output a single paragraph
// handles bullets and numbering
// uses the data saved in the story context to output the text style ranges
// contained in the paragraph to XHTML spans
//
//	buffer: the buffer to output to
// para: the paragraph object in question (currently only used for numbered lists)
// storyContext: the current story context
// paraOffsetStart: the text offset of the first character of the paragraph
// paraOffsetEnd: the text offset of the last character of the paragraph
// paraStyle: the paragraph style object
// paraListType: the list type of the paragraph
// startParagraphWith: optional string to start the paragraph with
// indexOfPreviousRange: the index of the text style range that was previously
// 					returned by this function
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processParagraph = function(buffer, storyContext, para, paraOffsetStart, paraOffsetEnd, paraStyle, paraListType, startParagraphWith, indexOfPreviousRange) {

	// figure out tag and class attribute
	var mapping = this.paraStyleList.getClassAndTag(paraStyle);
	var tag = mapping.tag;
	var cls = mapping.cssclass;
	
	// figure out whether the paragraph is a list item
	var isListItem = (tag == 'li' || paraListType != ListType.noList);
	var convertListToText = (paraListType == ListType.numberedList && this.options.numberedListsPolicy == XHTMLExportOptions.convertToText) || (paraListType == ListType.bulletList && (this.options.bulletedListsPolicy == XHTMLExportOptions.convertBulletsToText));
	
	if(isListItem && !convertListToText) {
		// handle bullets & numbers lists
		// the B&N list items need to wrapped in <ol> or <ul> elements
		// this section handles opening and closing these elements around
		// consecutive list items of the same type.
		// the information about the current list is kept in the story context.
		// <li> items need to stay open until it is safe to close them
		tag = 'li';				
		if(paraListType == ListType.numberedList) {
			var list = para.appliedNumberingList;
			var listmapping = this.listList.getClassAndTag(list);
			storyContext.handleNumberedListItem(buffer, para, list.id, para.numberingLevel, listmapping.cssclass, cls, this.options.numberedListsPolicy == XHTMLExportOptions.fixedListItems);
		} else {
			storyContext.handleBulletedListItem(buffer, paraStyle.id, cls);
		}
	} else {
		// the is a regular paragraph
		// correct the tag in case the user wants to convert list items into text
		if(tag == 'li') {
			tag = 'p';
		}
		// this is not a list so we make sure to close any open lists
		storyContext.closeOpenLists(buffer);
	}
		
	// Establish a paragraph context.
	// We do not open the current paragraph here since this is done
	// on an as needed-basis when actually writing out text.
	// Notice that this is done for list items as well although
	// they are treated differently in terms of when we emit
	// the open and close tags.
	var paraStart = (convertListToText ? (this.cleantext(para.bulletsAndNumberingResultText) + (startParagraphWith == undefined ? '' : startParagraphWith)) : startParagraphWith);
	storyContext.newParagraphContext(tag, cls, paraStart );
	
	// output the text style ranges of this paragraph
	with(storyContext) {
		// find the text style ranges that are in this paragraph
		var rangeStartIndex = indexOfPreviousRange;	// we pick up again where we left off during the previous call
		var lastRangeIndex = rangeIndexList.length - 1; // the index of the last range
		while(rangeStartIndex < lastRangeIndex && rangeIndexList[rangeStartIndex + 1] < paraOffsetStart) {
			rangeStartIndex++;	// find the first range that intersects with the paragraph
		}
		var rangeEndIndex = rangeStartIndex;
		while(rangeEndIndex < lastRangeIndex && rangeIndexList[rangeEndIndex + 1] <= paraOffsetEnd) {
			rangeEndIndex++;	// find the last range that intersects with the paragraph
		}
		
		// process the list of text style ranges
		this.pBar.newSection(rangeEndIndex - rangeStartIndex + 1);
		var openSpan = undefined;
		for(var i = rangeStartIndex; i <= rangeEndIndex; i++) {
			// find start and end offsets of this range
			var rangeStartOffset = rangeIndexList[i];
			var rangeEndOffset = rangeIndexList[i+1];
			if(rangeEndOffset == undefined) {
				rangeEndOffset = paraOffsetEnd;
			} else {
				rangeEndOffset--;
			}
			
			if((rangeStartOffset <= paraOffsetEnd) && (rangeEndOffset >= paraOffsetStart)) {
				// adjust range start and end offsets if necessary
				if(rangeStartOffset < paraOffsetStart) {
					rangeStartOffset = paraOffsetStart;
				}
				if(rangeEndOffset > paraOffsetEnd) {
					rangeEndOffset = paraOffsetEnd;
				}
				openSpan = this.processSpan(buffer, storyContext, rangeStartOffset, rangeEndOffset, rangeStyleList[i], openSpan);
			}
			
			this.pBar.sectionStepCompleted();
		}
		this.pBar.sectionCompleted();
		
		if(openSpan != undefined) {
			openSpan.close(buffer);
		}
	}
	
	this.closeCurrentPara(buffer);
	storyContext.deleteParagraphContext(buffer);
	
	return rangeEndIndex; // return where we left off
}  // XHTMLExporter.prototype.processParagraph


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processStoryContext
// process a series of paragraphs in the context of a story, a footnote or
// a table cell
//	uses the XHTMStoryContext object to pre-fetch all children of the story
//	(e.g. tables or inlines) as well as data about paragraphs and style ranges.
//
//	buffer: the output buffer to use
//	contextid: unique string identifying the story context
//	storyCellOrFootnote: the object representing the story context
//	tag: the XHTML element tag to use
//	cls: the CSS class name to use
//	paraCollection: the collection object representing the paragraphs to be exported
//	rangeCollection: the collection  object representing the text style ranges to be exported
// contents: the text contents of story
// start: optional parameter defining a start text offset other than 0
// end: optional parameter defining a end text offset other than end-of-story
// startFirstParagraphWith: optional string to start the paragraph with
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processStoryContext = function(buffer, contextid, storyCellOrFootnote, tag, cls, paraCollection, rangeCollection, contents, start, end, startFirstParagraphWith) {

	// this function manages two nested progress bar sections
	// outer section: 2 steps: setting up the context, generating output
	this.pBar.newSection(2);	
	
	// create a new story context and put it on the stack
	var storyContext = new XHTMLStoryContext(contextid, tag, cls);
	this.currentStoryStack.push(storyContext);
	storyContext.collectData(this.docContext, storyCellOrFootnote, paraCollection, rangeCollection, contents, this.pBar)
	storyContext.open(buffer);
	
	this.pBar.sectionStepCompleted();	// outer section: done setting up the context
	
	// if there are no start or end offsets supplied
	// we use the first and last characters of the supplied list of paragraphs
	if(start == undefined) {
		start = 0;
		if(paraCollection.length > 0) {
			start = paraCollection[0].insertionPoints[0].index;
		}
	}
	if(end == undefined) {
		end = 0;
		if(paraCollection.length > 0) {
			end = paraCollection.lastItem().insertionPoints.lastItem().index;
		}
	}
	
	// process the list of paragraphs
	// for performance reasons we use the data collected by the story context 
	//	rather than iterating over the paraCollection
	var paraCount = storyContext.paraIndexList.length;
	this.pBar.newSection(paraCount + 1); // inner section (+1 for the footnotes section)
	// this variable gets passed to and returned from processParagraph
	var indexOfPreviousRange = 0;	
	for(var i = 0; i < paraCount; i++) {
		// find start and end offsets of this paragraph
		var paraOffsetStart = storyContext.paraIndexList[i];
		var paraOffsetEnd = storyContext.paraIndexList[i+1];
		if(paraOffsetEnd == undefined) {
			paraOffsetEnd = end;
		} else {
			paraOffsetEnd--;
		}
		
		// see whether the paragraph overlaps the range defined by start and end
		if((paraOffsetStart >= start && paraOffsetStart <= end) || (paraOffsetEnd >= start && paraOffsetEnd <= end)) {
			// adjust paragraph start and end offsets if necessary
			if(paraOffsetStart < start) {
				paraOffsetStart = start;
			}
			if(paraOffsetEnd > end) {
				paraOffsetEnd = end;
			}
			// output the paragraph
			indexOfPreviousRange = this.processParagraph(buffer, storyContext, paraCollection[i], paraOffsetStart, paraOffsetEnd, storyContext.paraStyleList[i], storyContext.bulletsNumberingTypeList[i], startFirstParagraphWith, indexOfPreviousRange);
			// this was for the first paragraph only:
			startFirstParagraphWith = undefined;
		}
			
		this.pBar.sectionStepCompleted(); // inner section
	}
	
	// process any footnotes that were collected while processing the paragraphs above
	var footnotes = storyContext.footnotes;
	if(footnotes.length > 0) {
		// process the footnotes of this story
		buffer.openElementContext('div', 'footnotes');
		while(footnotes.length > 0) {
			var footnote = footnotes.shift();
			var anchor = '[' + buffer.generateAnchorString(footnote.number.toString(), footnote.name, 'footnote-anchor', 'href="#' + footnote.backlinkname + '"') + ']';
			var theFootnote = footnote.footnote;
			this.processStoryContext(buffer,theFootnote.id.toString(), theFootnote, 'div', 'footnote', theFootnote.paragraphs, theFootnote.textStyleRanges, theFootnote.contents, undefined, undefined, anchor);
		}
		buffer.closeElementContext('div');
	} 
	this.pBar.sectionStepCompleted();	// inner section: the +1 from above
	
	this.pBar.sectionCompleted();	// inner section
	
	// close the story context
	storyContext.close(buffer);
	this.currentStoryStack.pop();
	
	this.pBar.sectionStepCompleted();	// outer section: done with output
	this.pBar.sectionCompleted(); // outer section
} // XHTMLExporter.prototype.processStoryContext


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processStory
// Handles inline stories by (based on the context) either processing it right
// away or by queuing it up for later processing
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processStory = function(buffer, story, paragraphs, ranges, start, end) {
	var storyID = story.id.toString();
	
	if (!this.isInline()) {
		var cls = "story";	
		var element = "div";
			
		// we use the object style of the first text container of the story
		// as class attribute
		if(('textContainers' in story) && (story.textContainers.length > 0)) {
			var firstFrame = XHTMLUtils.getFirstPageItemOfStory(story);
			var style = firstFrame.appliedObjectStyle;
			var mapping = this.objStyleList.getClassAndTag(style);
			if(mapping.tag != '') {
				element = mapping.tag;
			}
			if(mapping.cssclass != '') {
				cls = mapping.cssclass;
			}
		}
	
		// if there hasn't been a list of paragraphs supplied
		// we use all the paragraphs of the story
		if(paragraphs == undefined) {
			paragraphs = story.paragraphs;
		}
		if(ranges == undefined) {
			ranges = story.textStyleRanges;
		}

		// output the paragraphs within a new story context
		this.processStoryContext(buffer, storyID, story, element, cls, paragraphs, ranges, story.contents, start, end);
	} else {
		this.currentStoryContext().inlineQueue.push([story]);
	}
} // XHTMLExporter.prototype.processStory


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.processTextRange
//------------------------------------------------------------------------------

XHTMLExporter.prototype.processTextRange = function(buffer, text) {
	// figure out story, start and end index
	var story = text.parent; // can be story, footnote or cell!
	var start = text.insertionPoints[0].index;
	var end = text.insertionPoints.lastItem().index - 1;
		
	// output the story
	this.processStory(buffer, story, text.paragraphs, text.textStyleRanges, start, end);
} // this.processTextRange


//------------------------------------------------------------------------------
// XHTMLProgressIterator
// Helper object to handle iterating over arrays while updating the progress bar
//------------------------------------------------------------------------------

XHTMLProgressIterator = function(list, pBar, title, fractionOfParentStep) {
	this.list = list;
	this.c = list.length;		//bottleneck
	this.i = -1;
	this.pBar = pBar;
	
	pBar.newSection(this.c, title == undefined ? '' : title, fractionOfParentStep == undefined ? 1 : fractionOfParentStep);
} // XHTMLProgressIterator


XHTMLProgressIterator.prototype.next = function() {
	this.i++;
	if(this.i >= this.c) {
		this.pBar.sectionStepCompleted();
		this.pBar.sectionCompleted();
		return null;
	} else {
		if(this.i > 0) {
			this.pBar.sectionStepCompleted();
		}
		return this.list[this.i];		//bottleneck
	}
} // XHTMLProgressIterator.prototype.next


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.filterItems
// filter out items that we can't export and stories that we have already exported
// returns filtered list
//------------------------------------------------------------------------------

XHTMLExporter.prototype.filterItems = function(items, stripTOCsAndIndexStories) {

	var newItems = [];
	
	function pushIfNew(story, item, list, stripTOCsAndIndexStories) {
		var result = false;
		if(!stripTOCsAndIndexStories || (story.storyType == StoryTypes.regularStory)) {
			var id = story.id.toString();
			if(list[id] == undefined) {
				list[id] = story;
				newItems.push(item);
				result = true;
			}
		}
		return result;
	}
	
	for (var i=0; i<items.length; i++) {
		switch(items[i].constructor.name) {
			case "Story":
				pushIfNew(items[i], items[i], this.exportedStories, stripTOCsAndIndexStories);
			break;
			case "TextFrame":
				var textPathCount = items[i].textPaths.length;
				for(var j = 0; j<textPathCount; j++) {
					var story = items[i].textPaths[j].parentStory;
					pushIfNew(story, story, this.exportedStories, stripTOCsAndIndexStories);				
				}
			// fall through
			case "TextPath":
				var story = items[i].parentStory;
				pushIfNew(story, story, this.exportedStories, stripTOCsAndIndexStories);
			break;
			case "Text":
			case "TextStyleRange":
			case "Word":
			case "Paragraph":
			case "Character":
			case "TextColumn":
			case "Line":
				pushIfNew(items[i].parentStory, items[i], this.exportedStories, stripTOCsAndIndexStories);
			break;
			case "Group":
			case "Rectangle":
			case "Polygon":
			case "Oval":
			case "GraphicLine":
				newItems.push(items[i]);
			break;
			case "PDF":
			case "Image":
			case "Movie":
			case "PICT":
			case "WMF":
			case "EPS":
			case "ImportedPage":
			case "Table":
			case "Cell":
				newItems.push(items[i]);
			break;
			case "InsertionPoint":
				pushIfNew(items[i].parentStory, items[i].parentStory, this.exportedStories, stripTOCsAndIndexStories);
			break;
		}
	}
	
	return newItems;
} // XHTMLExporter.prototype.filterItems


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.allContainersInDocument
// find all first-level page items
// doc.allPageItems() can't be used because it includes nested and inline items
//------------------------------------------------------------------------------

XHTMLExporter.prototype.allContainersInDocument = function(doc) {
	function addToList(items, list) {
		var count = items.length;
		for (var i = 0; i < count; i++)
			list.push(items[i]);
	}

	var list = [];
	var layers = doc.layers;
	var layerCount = layers.length;
	for (var i = 0; i < layerCount; i++) {
		var layer = layers[i];
		if(layer.visible) {
			addToList(layer.groups, list);
			addToList(layer.rectangles, list);
			addToList(layer.ovals, list);
			addToList(layer.polygons, list);
			addToList(layer.textFrames, list);
			addToList(layer.graphicLines, list);
		}
	}
	
	return list;
} // XHTMLExporter.prototype.allContainersInDocument


//------------------------------------------------------------------------------
// XHTMLExporter.prototype.cleantext
// Sanitize the InDesign text by removing unnecessary characters and
// converting others to their proper HTML representation
//------------------------------------------------------------------------------

XHTMLExporter.prototype.cleantext = function(s) {
	// get rid of character we don't need:
	// paragraph breaks, column break, frame break, page break (\r)
	// disc line break (\u200B)
	// page numbers, variables (\u0018)
	// section marker (\u0019)
	// discretionary hyphen (\u00AD)
	// indent to here (\u0007)
	// end nested style here (\u0003)
	// xml tag (\uFEFF)
	// inline (\uFFFC)
	// footnote number (\u0004)
	// sing glyph (\u001A)
	// table (\u0016)
	var result = s.replace(/[\r\u200B\u0018\u0019\u00AD\u0007\u0003\u0004\uFEFF\uFFFC\u001A\u0016]/g,'');
			
			
	// replace non-breaking hyphen (8209 -> \u2011) with a regular hyphen
	result = result.replace(/\u2011/g,'-');
			
			
	// replace non-standard whitespace with single spaces
	// right indent tab (\u0008)
	result = result.replace(/[\u0008]/g,' ');
			
	// replace characters with entities
	result = result.replace(/&/g,'&amp;');	// ampersand -- must be the first entity replacement
	result = result.replace(/</g,'&lt;');		// less than
	result = result.replace(/>/g,'&gt;');	// greater than
	result = result.replace(/'/g,'&apos;');	// straight apostrophe
	result = result.replace(/"/g,'&quot;');	// straight quote
	result = result.replace(/[\u00A0\u202F]/g,'&nbsp;'); // non breaking spaces	
		
	// misc
	result = result.replace(/\n/g,'<br />'); // forced line break
		
	// replace all consecutive whitespace with a single space
	// tab
	// space
	// flush-space (\u2001)
	// n-space (\u2002)
	// m-space (\u2003)
	// third-space (\u2004)
	// quarter-space (\u2005)
	// sixth-space (\u2006)
	// figure space (\u2007)
	// punctuation space (\u2008)
	// thin space (\u2009)
	// hair-space (\u200A)
	result = result.replace(/[\s]+/g,' ');
	
	return result;
} // XHTMLExporter.prototype.cleantext


//------------------------------------------------------------------------------
// XHTMLExporterIDGenerator
// We use this object to generate a unique id based on a name we pass in
//------------------------------------------------------------------------------

function XHTMLExporterIDGenerator() {
	this.ids = {};
}

XHTMLExporterIDGenerator.prototype.newID = function(name) {
	var cleanname = XHTMLUtils.cleanAttributeValue(name);
	var number = 0;
	var id = cleanname;
	while(this.ids[id] != undefined) {
		number++;
		id = cleanname + '-' + number;
	}
						
	this.ids[id] = true;
	return id;
}
