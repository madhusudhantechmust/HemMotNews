//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/XHTMLExportUI.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Display the HTML export options dialog
//  
//========================================================================================

//===========================
//  Includes
//===========================

#include "includes/ProgressBar.jsx"

//------------------------------------------------------------------------------
// Constructor
//------------------------------------------------------------------------------

function XHTMLExportDialog () {
	// options that change the behavior of the dialog
	this.enableSelectionOnly = false;
	
} // XHTMLExportDialog

// this object requires a certain version of the scripting DOM
XHTMLExportDialog.requiredDOMVersion = 6.0;

//------------------------------------------------------------------------------
// XHTMLExportDialog.prototype.doDialog
// Displays and "does" the dialog. Updates the given options object and
// returns true if the user OKs the dialog. Otherwise it returns false		
//------------------------------------------------------------------------------
	
XHTMLExportDialog.prototype.doDialog = function(options, document) {
	var scriptPrefsContext = new XHTMLUtils.prefsContext(app.scriptPreferences);
	scriptPrefsContext.setPreference('version', XHTMLExportDialog.requiredDOMVersion);
	
	var result = true;
	var win = new Window(XHTMLExportDialog.dlgResource);
	this.setUpProperties(win);
	this.finalizeDialog(win);
	this.tweakDialogLayout(win);
	this.initializeDialog(win,options, document);
	win.center();
	
	if(app.scriptPreferences.userInteractionLevel == UserInteractionLevels.interactWithAll) {
		result = (win.show() == 1);
	}
	if(result) {
		this.captureDialogResults(win, options, document)
	}
	
	scriptPrefsContext.restoreOldValues();
	
	return result;
} // XHTMLExportDialog.prototype.doDialog

// two-way mappings of InDesign's enum values for image conversion to the appropriate selection values for the dialog
XHTMLExportDialog.imageConversionMapping = {};
XHTMLExportDialog.imageConversionMapping[ImageConversion.automatic.toString()] = 0;
XHTMLExportDialog.imageConversionMapping[ImageConversion.gif.toString()] = 1;
XHTMLExportDialog.imageConversionMapping[ImageConversion.jpeg.toString()] = 2;
XHTMLExportDialog.imageConversionMapping['0'] = ImageConversion.automatic;
XHTMLExportDialog.imageConversionMapping['1'] = ImageConversion.gif;
XHTMLExportDialog.imageConversionMapping['2'] = ImageConversion.jpeg;

XHTMLExportDialog.gifPaletteMapping = {};
XHTMLExportDialog.gifPaletteMapping[GIFOptionsPalette.adaptivePalette.toString()] = 0;
XHTMLExportDialog.gifPaletteMapping[GIFOptionsPalette.webPalette.toString()] = 1;
XHTMLExportDialog.gifPaletteMapping[GIFOptionsPalette.windowsPalette.toString()] = 2;
XHTMLExportDialog.gifPaletteMapping[GIFOptionsPalette.macintoshPalette.toString()] = 3;
XHTMLExportDialog.gifPaletteMapping['0'] = GIFOptionsPalette.adaptivePalette;
XHTMLExportDialog.gifPaletteMapping['1'] = GIFOptionsPalette.webPalette;
XHTMLExportDialog.gifPaletteMapping['2'] = GIFOptionsPalette.windowsPalette;
XHTMLExportDialog.gifPaletteMapping['3'] = GIFOptionsPalette.macintoshPalette;

XHTMLExportDialog.jpegEncodingMapping = {};
XHTMLExportDialog.jpegEncodingMapping[JPEGOptionsFormat.progressiveEncoding.toString()] = 0;
XHTMLExportDialog.jpegEncodingMapping[JPEGOptionsFormat.baselineEncoding.toString()] = 1;
XHTMLExportDialog.jpegEncodingMapping['0'] = JPEGOptionsFormat.progressiveEncoding;
XHTMLExportDialog.jpegEncodingMapping['1'] = JPEGOptionsFormat.baselineEncoding;

XHTMLExportDialog.jpegQualityMapping = {};
XHTMLExportDialog.jpegQualityMapping[JPEGOptionsQuality.low.toString()] = 0;
XHTMLExportDialog.jpegQualityMapping[JPEGOptionsQuality.medium.toString()] = 1;
XHTMLExportDialog.jpegQualityMapping[JPEGOptionsQuality.high.toString()] = 2;
XHTMLExportDialog.jpegQualityMapping[JPEGOptionsQuality.maximum.toString()] = 3;
XHTMLExportDialog.jpegQualityMapping['0'] = JPEGOptionsQuality.low;
XHTMLExportDialog.jpegQualityMapping['1'] = JPEGOptionsQuality.medium;
XHTMLExportDialog.jpegQualityMapping['2'] = JPEGOptionsQuality.high;
XHTMLExportDialog.jpegQualityMapping['3'] = JPEGOptionsQuality.maximum;

//------------------------------------------------------------------------------
// END OF PUBLIC SECTION
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// XHTMLExportDialog.prototype.setUpProperties
// Creates properties for the controls of the dialog.
// Makes subsequent work with these controls easier
//------------------------------------------------------------------------------
		
XHTMLExportDialog.prototype.setUpProperties = function(win) {
	// buttons
	win.okButton = win.dialog.buttons.okButton;
	win.cancelButton = win.dialog.buttons.cancelButton;
	// navigation
	win.navList = win.dialog.mainGroup.navGroup.list;
	// panels
	win.generalPanel = win.dialog.mainGroup.panels.generalPanel;
	win.imagePanel = win.dialog.mainGroup.panels.imagePanel;
	win.advancedPanel = win.dialog.mainGroup.panels.advancedPanel;
	win.serverPathPanel = win.imagePanel.copyImagesPanels.serverPathPanel;
	win.optimizedPanel = win.imagePanel.copyImagesPanels.optimizedPanel;
	
	// general
	win.selectionOnly = win.generalPanel.scopePanel.selectionOnly;
	win.wholeDoc = win.generalPanel.scopePanel.wholeDocument;
	win.bullets = win.generalPanel.bAndNPanel.bulletsGroup.bullets;
	win.numbering = win.generalPanel.bAndNPanel.numberingGroup.numbering;
	
	// images
	win.copyImages = win.imagePanel.copyImagesGroup.copyImages;
	win.formatted = win.optimizedPanel.formatted;
	win.format = win.optimizedPanel.conversionGroup.format;
	win.gifOptions = win.optimizedPanel.gifOptions;
	win.jpegOptions = win.optimizedPanel.jpegOptions;
	win.palette = win.gifOptions.gifGroup.palette;
	win.quality = win.jpegOptions.jpegGroup.quality;
	win.interlaced = win.gifOptions.interlacedGroup.interlaced;
	win.method = win.jpegOptions.jpegMethodGroup.method;
	win.path = win.serverPathPanel.pathGroup.path;
	win.ext = win.serverPathPanel.extGroup.ext;
	
	// advanced
	win.extStyles = win.advancedPanel.cssPanel.extStylesRadio;
	win.emptyStyles = win.advancedPanel.cssPanel.emptyStylesRadio;
	win.noStyles = win.advancedPanel.cssPanel.noStylesRadio;
	win.extStyleText = win.advancedPanel.cssPanel.extStyleGroup.extStyleText;
	win.linkToJavaScript = win.advancedPanel.javaScriptPanel.linkToJavaScript;
	win.javaScriptURL = win.advancedPanel.javaScriptPanel.javaScriptURLGroup.javaScriptURL;
}

//------------------------------------------------------------------------------
// XHTMLExportDialog.prototype.finalizeDialog
// Finalizes the dialog by setting up the things that can't be done in the 
// resource string plus defining the functions for the dynamic parts of the 
// dialog
//------------------------------------------------------------------------------
		
XHTMLExportDialog.prototype.finalizeDialog = function(win) {
	// define default buttons
	win.defaultElement = win.okButton;
	win.cancelElement = win.cancelButton;
	
	// fill navigation list	(padding with spaces because the list is too tight)
	win.navList.add('item', ' ' + localize(xhtmlExportStrings.GENERAL) + '   ');
	win.navList.add('item', ' ' + localize(xhtmlExportStrings.IMAGES) + '   ');
	win.navList.add('item', ' ' + localize(xhtmlExportStrings.ADVANCED) + '   ');
	win.navList.selection = 0;	
		
	// handle switching between the panels
	win.navList.onChange = function() {
		if(this.selection == undefined) {
			// don't allow user to deselect all
			this.selection = 2;
		}
		var i = this.selection.index;
		win.generalPanel.visible = (i == 0);
		win.imagePanel.visible = (i == 1);
		win.advancedPanel.visible = (i == 2);
		if(win.imagePanel.visible) {
			win.copyImages.onChange();
		}
	}

	// fill pop-ups
	win.bullets.add('item', localize(xhtmlExportStrings.ASUNORDEREDLISTS));
	win.bullets.add('item', localize(xhtmlExportStrings.ASTEXT));
	win.bullets.selection = 0;

	win.numbering.add('item', localize(xhtmlExportStrings.ASORDEREDLISTS));
	win.numbering.add('item', localize(xhtmlExportStrings.FIXEDNUMBERS));
	win.numbering.add('item', localize(xhtmlExportStrings.ASTEXT));
	win.numbering.selection = 0;

	win.copyImages.add('item', localize(xhtmlExportStrings.ORIGS));
	win.copyImages.add('item', localize(xhtmlExportStrings.OPTORIGS));
	win.copyImages.add('item', localize(xhtmlExportStrings.SERVERPATH));
	win.copyImages.selection = 0;
	
	win.format.add('item', localize(xhtmlExportStrings.AUTO));
	win.format.add('item', localize(xhtmlExportStrings.GIF));
	win.format.add('item', localize(xhtmlExportStrings.JPEG));
	win.format.selection = 0;
	
	win.palette.add('item', localize(xhtmlExportStrings.ADAPTIVE));
	win.palette.add('item', localize(xhtmlExportStrings.WEB));
	win.palette.add('item', localize(xhtmlExportStrings.SYSWIN));
	win.palette.add('item', localize(xhtmlExportStrings.SYSMAC));
	win.palette.selection = 0;
	
	win.quality.add('item', localize(xhtmlExportStrings.LOW));
	win.quality.add('item', localize(xhtmlExportStrings.MEDIUM));
	win.quality.add('item', localize(xhtmlExportStrings.HIGH));
	win.quality.add('item', localize(xhtmlExportStrings.MAX));
	win.quality.selection = 0;
	
	win.method.add('item', localize(xhtmlExportStrings.PROGRESSIVE));
	win.method.add('item', localize(xhtmlExportStrings.BASELINE));
	win.method.selection = 0;

	// handle de-/activation of external css edit text
	win.extStyles.onClick = function() {
		if (!this.value) {
			this.parent.extStyleGroup.extStyleText.enabled = false;
		} else {
			this.parent.extStyleGroup.extStyleText.enabled = true;
		}
	}
	win.noStyles.onClick = win.emptyStyles.onClick = function() {
		this.parent.extStylesRadio.onClick();
	}
	
	// handle de-/activation of external javascript url
	win.linkToJavaScript.onClick = function() {
		if (!this.value) {
			win.javaScriptURL.enabled = false;
		} else {
			win.javaScriptURL.enabled = true;
		}
	}
		
	// handle switching between the copy images panels
	win.copyImages.onChange = function() {
		var i = this.selection.index;
		win.optimizedPanel.enabled = (i > 0);
		win.optimizedPanel.visible = (i < 2);
		win.serverPathPanel.visible = (i == 2);
	}
	
	// handle de-/activation of jpg and gif options
	win.format.onChange = function() {
		var i = this.selection.index;
		win.gifOptions.enabled = (i<2);
		win.jpegOptions.enabled = (i!=1);
	}
	
	// honor dialog options
	win.selectionOnly.enabled = this.enableSelectionOnly;
}


//------------------------------------------------------------------------------
// XHTMLExportDialog.prototype.tweakDialogLayout
// Finalizes the dialog by setting up the things that can't be done in the 
// resource string plus defining the functions for the dynamic parts of the 
// dialog
//------------------------------------------------------------------------------
		
XHTMLExportDialog.prototype.tweakDialogLayout = function(win) {
	function makeSameWidth(arrayOfItems) {
		var newSize = [0,0];
		for(var i in arrayOfItems) {
			if(arrayOfItems[i].size.width > newSize[0]) {
				newSize = arrayOfItems[i].size;
			}
		}
		for(i in arrayOfItems) {
			if(arrayOfItems[i].size.width < newSize[0]) {
				arrayOfItems[i].size = newSize;
			}
		}
	}
	win.layout.layout();
	makeSameWidth([win.bullets, win.numbering]);
	makeSameWidth([win.quality, win.method, win.palette]);
	win.layout.layout(true);
}


//------------------------------------------------------------------------------
// XHTMLExportDialog.prototype.initializeDialog
// Initialize control values in the dialog based on given options
//------------------------------------------------------------------------------
		
XHTMLExportDialog.prototype.initializeDialog = function(win, options, document) {
	if(options.styleHandling == XHTMLExportOptions.noStyles) {
		win.noStyles.notify();
	} else if (options.styleHandling == XHTMLExportOptions.emptyStyles) {
		win.emptyStyles.notify();
	} else {
		win.extStyles.notify();
	}
	win.extStyleText.text = options.styleSheet;

	if((options.scope == XHTMLExportOptions.exportSelection) && this.enableSelectionOnly) {
		win.selectionOnly.value = true;
	} else {
		win.wholeDoc.value = true;
	}
	win.numbering.selection = options.numberedListsPolicy;
	win.bullets.selection = options.bulletedListsPolicy;
		
	var  imagePrefs = document.exportForWebPreferences;
	win.copyImages.selection = options.imageHandling;
	win.formatted.value = options.formatted;
	win.format.selection = XHTMLExportDialog.imageConversionMapping[imagePrefs.imageConversion.toString()];
	win.palette.selection = XHTMLExportDialog.gifPaletteMapping[imagePrefs.gifOptionsPalette.toString()];
	win.interlaced.value = imagePrefs.gifOptionsInterlaced;
	win.quality.selection = XHTMLExportDialog.jpegQualityMapping[imagePrefs.jpegOptionsQuality.toString()];
	win.method.selection = XHTMLExportDialog.jpegEncodingMapping[imagePrefs.jpegOptionsFormat.toString()];
	win.path.text = options.serverPath;
	win.ext.text = options.imageExtension;
	
	win.linkToJavaScript.value = options.linkToJavaScript;
	win.linkToJavaScript.onClick();
	win.javaScriptURL.text = options.javaScriptURL;
} // XHTMLExportDialog.prototype.initializeDialog
	
	
//------------------------------------------------------------------------------
// XHTMLExportDialog.prototype.captureDialogResults
// Captures the results of the dialog	
//------------------------------------------------------------------------------

XHTMLExportDialog.prototype.captureDialogResults = function(win, options, document) {
	if(win.noStyles.value) {
		options.styleHandling = XHTMLExportOptions.noStyles;
	} else if (win.emptyStyles.value) {
		options.styleHandling = XHTMLExportOptions.emptyStyles;
	} else {
		options.styleHandling = XHTMLExportOptions.extStyleSheet;
		options.styleSheet = win.extStyleText.text;
	}
	
	options.linkToJavaScript = win.linkToJavaScript.value;
	options.javaScriptURL = win.javaScriptURL.text;

	if(this.enableSelectionOnly) {
		options.scope = (win.selectionOnly.value ? XHTMLExportOptions.exportSelection : XHTMLExportOptions.exportDocument);
	}
	options.numberedListsPolicy = win.numbering.selection.index;
	options.bulletedListsPolicy = win.bullets.selection.index;

	var  imagePrefs = document.exportForWebPreferences;
	options.formatted = win.formatted.value;
	imagePrefs.imageConversion = XHTMLExportDialog.imageConversionMapping[win.format.selection.index.toString()];
	imagePrefs.gifOptionsPalette = XHTMLExportDialog.gifPaletteMapping[win.palette.selection.index.toString()];
	imagePrefs.gifOptionsInterlaced = win.interlaced.value;
	
	imagePrefs.jpegOptionsQuality = XHTMLExportDialog.jpegQualityMapping[win.quality.selection.index.toString()];
	imagePrefs.jpegOptionsFormat = XHTMLExportDialog.jpegEncodingMapping[win.method.selection.index.toString()];
	
	options.serverPath = win.path.text;
	options.imageExtension = win.ext.text;
	
	options.imageHandling = win.copyImages.selection.index;
	options.resolveWithWebExportSettings(document);	// make sure that the web image export prefs are in sync with our imageHandling policy
} // XHTMLExportDialog.prototype.captureDialogResults

//------------------------------------------------------------------------------
// XHTMLAlignedLabelGroup
// Helper object to right align a list of static text labels		
//------------------------------------------------------------------------------

function XHTMLAlignedLabelGroup(labels) {
	this.labels = [];
	this.cleanLabels = [];
	for (var i in labels) {
		this.labels.push(labels[i]);
		if(XHTMLUtils.isMacintosh()) {
			var cleanLabel = labels[i].replace(/\(&.\)/,'');	// handle J KBSC
			this.cleanLabels.push(cleanLabel.replace('&',''));
		} else {
			this.cleanLabels.push(labels[i].replace('&',''));
		}
	}
}

XHTMLAlignedLabelGroup.prototype.getLabel = function(labelText) {
	var str = "labelGroup: Group { orientation: 'stack', alignChildren: ['right', 'fill'],";
	for (var i in this.labels) {
		if(this.labels[i] == labelText) {
			str += "label: StaticText { text: '" + this.labels[i] + "' },";
		} else {
			str += "label: StaticText { text: '" + this.cleanLabels[i] + "', visible: false },";
		}
	}
	return str + "},";
}


//------------------------------------------------------------------------------
// Dialog Resource
// this is the resource string that is describing the dialog in its initial form		
//------------------------------------------------------------------------------

XHTMLExportDialog.imagePanelLabelGroup = new XHTMLAlignedLabelGroup([localize(xhtmlExportStrings.PALETTE), localize(xhtmlExportStrings.QUALITY), localize(xhtmlExportStrings.FORMATMETHOD)]);
XHTMLExportDialog.serverPathLabelGroup = new XHTMLAlignedLabelGroup([localize(xhtmlExportStrings.PATH), localize(xhtmlExportStrings.EXTENSION)]);
XHTMLExportDialog.bAndNLabelGroup = new XHTMLAlignedLabelGroup([localize(xhtmlExportStrings.BULLETEDLISTS), localize(xhtmlExportStrings.NUMBEREDLISTS)]);

// used to adjust ScriptUIs auto layout to the tighter InDesign dialog spacing
XHTMLExportDialog.DROPDOWNSPACING = XHTMLUtils.isMacintosh() ? 0 : 5;
XHTMLExportDialog.CHECKBOXSPACING = 5;
XHTMLExportDialog.RADIOSPACING = 5;
XHTMLExportDialog.EDITTEXTSPACING = XHTMLUtils.isMacintosh() ? 0 : 5;

XHTMLExportDialog.dlgResource =
		"dialog { \
			text: '" + localize(xhtmlExportStrings.HTMLEXPORTOPTIONS) + "', \
			dialog: Group { orientation: 'column', alignChildren: ['fill', 'fill'], \
				mainGroup: Group { orientation: 'row', alignChildren: ['left', 'fill'], \
					navGroup: Group { orientation: 'row', alignChildren: ['left', 'fill'], margins: [0,8,0,0], \
							list: ListBox { }\
					},\
					panels: Group { orientation: 'stack', alignChildren: ['fill', 'fill'], alignment: 'fill', \
						generalPanel: Group { visible: true, \
							orientation: 'column', alignChildren: ['fill', 'top'], \
							header:Group { orientation: 'column', \
								alignment: ['fill', 'top'], spacing: 0, \
								margins: [0,11,0,2], \
								alignChildren: ['fill', 'top'], \
								title:StaticText { text: '" + localize(xhtmlExportStrings.GENERAL) + "' }, \
								line:Panel { size: [100, 0] }, \
							}, \
							scopePanel: Panel { \
								text: '" + localize(xhtmlExportStrings.SCOPE)  + "', \
								orientation: 'column', \
								spacing: " + XHTMLExportDialog.RADIOSPACING + ", \
								alignChildren: ['left', 'top'], \
								selectionOnly: RadioButton { text: '" + localize(xhtmlExportStrings.EXPORTSELECTION) + "' }, \
								wholeDocument: RadioButton { text: '" + localize(xhtmlExportStrings.EXPORTDOCUMENT) + "' }, \
					 		}, \
					 		bAndNPanel: Panel { text: '" + localize(xhtmlExportStrings.BULLETSANDNUMBERS) + "', orientation: 'column', \
					 			alignChildren: ['left', 'top'], spacing: " + XHTMLExportDialog.DROPDOWNSPACING + ", \
					 			bulletsGroup: Group {" +
					 				XHTMLExportDialog.bAndNLabelGroup.getLabel(localize(xhtmlExportStrings.BULLETEDLISTS)) +
					 				"bullets: DropDownList {} \
					 			}, \
								numberingGroup: Group {" +
					 				XHTMLExportDialog.bAndNLabelGroup.getLabel(localize(xhtmlExportStrings.NUMBEREDLISTS)) +
						 			"numbering: DropDownList {} \
					 			}, \
					 		}, \
					 	}, \
						imagePanel: Group { visible: false, orientation: 'column', alignChildren: ['fill', 'top'], \
							header:Group { orientation: 'column', \
								alignment: ['fill', 'top'], spacing: 0, \
								margins: [0,11,0,2], \
								alignChildren: ['fill', 'top'], \
								title:StaticText { text: '" + localize(xhtmlExportStrings.IMAGES) + "' }, \
								line:Panel { size: [100, 0] }, \
							}, \
							copyImagesGroup: Group { \
					 			txt: StaticText { text: '" + localize(xhtmlExportStrings.COPYIMAGES) + "' }, \
					 			copyImages: DropDownList {} \
					 		}, \
					 		copyImagesPanels: Group { orientation: 'stack', alignChildren: ['fill', 'top'], \
					 			optimizedPanel: Group { visible: true, orientation: 'column', alignChildren: ['fill', 'fill'], \
					 				spacing: 5,\
									formatted: Checkbox { text: '" + localize(xhtmlExportStrings.FORMATTED) + "' }, \
					 				conversionGroup: Group { \
										txt: StaticText { text: '" + localize(xhtmlExportStrings.CONVERSION) + "' }, \
					 					format: DropDownList {} \
					 				}, \
						 			gifOptions: Panel { text: '" + localize(xhtmlExportStrings.GIFOPTIONS) + "', orientation: 'column', \
						 				alignChildren: ['left', 'top'], spacing: " + XHTMLExportDialog.DROPDOWNSPACING + ", \
										gifGroup: Group { " +
											XHTMLExportDialog.imagePanelLabelGroup.getLabel(localize(xhtmlExportStrings.PALETTE)) +
								 			"palette: DropDownList {} \
								 		}, \
										interlacedGroup: Group { " +
											XHTMLExportDialog.imagePanelLabelGroup.getLabel('') +
											"interlaced: Checkbox { text: '" + localize(xhtmlExportStrings.INTERLACED) + "' }, \
						 				}, \
					 				}, \
					 				jpegOptions: Panel { text: '" + localize(xhtmlExportStrings.JPEGOPTIONS) + "', orientation: 'column', \
					 					alignChildren: ['left', 'top'], spacing: " + XHTMLExportDialog.DROPDOWNSPACING + ", \
										jpegGroup: Group { " +
											XHTMLExportDialog.imagePanelLabelGroup.getLabel(localize(xhtmlExportStrings.QUALITY)) +
						 					"quality: DropDownList {} \
							 			}, \
										jpegMethodGroup: Group { " +
											XHTMLExportDialog.imagePanelLabelGroup.getLabel(localize(xhtmlExportStrings.FORMATMETHOD)) +
							 				"method: DropDownList {} \
							 			} \
							 		} \
					 			}, \
						 		serverPathPanel: Group { visible: false, orientation: 'column', alignChildren: ['fill', 'fill'], \
						 			spacing: " + XHTMLExportDialog.EDITTEXTSPACING + ", \
									pathGroup: Group { " +
										XHTMLExportDialog.serverPathLabelGroup.getLabel(localize(xhtmlExportStrings.PATH)) +
						 				"path: EditText { characters: 30 } \
								 	}, \
						 			extGroup: Group { " +
										XHTMLExportDialog.serverPathLabelGroup.getLabel(localize(xhtmlExportStrings.EXTENSION)) +
										"ext: EditText { characters: 5 } \
								 	} \
						 		} \
						 	} \
						},\
						advancedPanel: Group { visible:false, orientation: 'column', alignChildren: ['fill', 'top'], \
							header:Group { orientation: 'column', \
								alignment: ['fill', 'top'], spacing: 0, \
								margins: [0,11,0,2], \
								alignChildren: ['fill', 'top'], \
								title:StaticText { text: '" + localize(xhtmlExportStrings.ADVANCED) + "' }, \
								line:Panel { size: [100, 0] }, \
							}, \
							cssPanel: Panel { text: '" + localize(xhtmlExportStrings.CSSOPTIONS) + "', orientation: 'column', alignChildren: ['fill', 'top'], \
								spacing: " + XHTMLExportDialog.RADIOSPACING + ", \
								emptyStylesRadio: RadioButton { text: '" + localize(xhtmlExportStrings.EMPTYCSS) + "' }, \
								noStylesRadio: RadioButton { text: '" + localize(xhtmlExportStrings.NOCSS) + "' }, \
								extStylesRadio: RadioButton { text: '" + localize(xhtmlExportStrings.EXTERNALCSS) + "' }, \
								extStyleGroup: Group { margins: [20, 0 , 0, 0], alignChildren: ['fill', 'top'], \
					 				extStyleText: EditText { characters: 35 } \
				 				} \
				 			}, \
						 	javaScriptPanel: Panel { text: '" + localize(xhtmlExportStrings.JAVASCRIPT) + "', orientation: 'column', alignChildren: ['fill', 'top'], \
								spacing: " + XHTMLExportDialog.RADIOSPACING + ", \
								linkToJavaScript: Checkbox { text: '" + localize(xhtmlExportStrings.LINKTOJAVASCRIPT) + "' }, \
								javaScriptURLGroup: Group { margins: [20, 0 , 0, 0], alignChildren: ['fill', 'top'], \
					 				javaScriptURL: EditText { characters: 35 } \
				 				} \
				 			} \
						} \
					}\
				},\
				buttons: Group { orientation: 'row', alignChildren: ['right', 'bottom'], \
					alignment: ['right', 'bottom'], spacing: 10, " + 
				(XHTMLUtils.isMacintosh() ?		// order of buttons is platform dependant
					"cancelButton: Button { text: '" + localize(xhtmlExportStrings.CANCEL) + "'}, \
					okButton: Button { text: '" + localize(xhtmlExportStrings.EXPORTBUTTON) + "'}" 
					:
					"okButton: Button { text: '" + localize(xhtmlExportStrings.EXPORTBUTTON) + "'}, \
					cancelButton: Button { text: '" + localize(xhtmlExportStrings.CANCEL) + "'}") +
				"},\
			} \
		}";

//------------------------------------------------------------------------------
// Test Code
//------------------------------------------------------------------------------

/*
#include "includes/XHTMLOptions.jsx"
var opts =  XHTMLExportOptions.restore(app.activeDocument);
var dialog = new XHTMLExportDialog();
dialog.enableSelectionOnly = true;
dialog.doDialog(opts, app.activeDocument);
opts.persist(app.activeDocument);
opts.bulletedListsPolicy;
*/