//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLStrings.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Defines the strings used for XHTMLExport
//  
//========================================================================================

xhtmlExportStrings = {};


//------------------------------------------------------------------------------
// The following defines the string objects
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL = {};


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME = {};
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME = {};
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME = {};
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER = {};


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

xhtmlExportStrings.FILEERROR = {};
xhtmlExportStrings.CREATEFOLDERERROR = {};
xhtmlExportStrings.DELETEFILEERROR = {};
xhtmlExportStrings.LOADSCRIPTERROR = {};
xhtmlExportStrings.ILLEGALFILENAMEERROR = {};


//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTWARNING = {};
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING = {};
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING = {};
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING = {};
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING = {};
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING = {};

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML = {};
xhtmlExportStrings.PROGRESSCANCELMAC = {};
xhtmlExportStrings.PROGRESSCANCELWIN = {};


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON = {};
xhtmlExportStrings.HTMLEXPORTOPTIONS = {};
xhtmlExportStrings.GENERAL = {};
xhtmlExportStrings.BULLETSANDNUMBERS = {};
xhtmlExportStrings.SCOPE = {};
xhtmlExportStrings.BULLETEDLISTS = {};
xhtmlExportStrings.NUMBEREDLISTS = {};
xhtmlExportStrings.ASUNORDEREDLISTS = {};
xhtmlExportStrings.ASORDEREDLISTS = {};
xhtmlExportStrings.FIXEDNUMBERS = {};
xhtmlExportStrings.ASTEXT = {};
xhtmlExportStrings.EXPORTSELECTION = {};
xhtmlExportStrings.EXPORTDOCUMENT = {};

// images
xhtmlExportStrings.IMAGES = {};
xhtmlExportStrings.COPYIMAGES = {};
xhtmlExportStrings.SERVERPATH = {};
xhtmlExportStrings.ORIGS = {};
xhtmlExportStrings.OPTORIGS = {};
xhtmlExportStrings.PATH = {};
xhtmlExportStrings.EXTENSION = {};
xhtmlExportStrings.FORMATTED = {};
xhtmlExportStrings.CONVERSION = {};
xhtmlExportStrings.AUTO = {};
xhtmlExportStrings.GIF = {};
xhtmlExportStrings.JPEG = {};
xhtmlExportStrings.GIFOPTIONS = {};
xhtmlExportStrings.PALETTE = {};
xhtmlExportStrings.ADAPTIVE = {};
xhtmlExportStrings.WEB = {};
xhtmlExportStrings.SYSWIN = {};
xhtmlExportStrings.SYSMAC = {};
xhtmlExportStrings.INTERLACED = {}; 
xhtmlExportStrings.JPEGOPTIONS = {};
xhtmlExportStrings.QUALITY = {};
xhtmlExportStrings.LOW = {};
xhtmlExportStrings.MEDIUM = {};
xhtmlExportStrings.HIGH = {};
xhtmlExportStrings.MAX = {};
xhtmlExportStrings.FORMATMETHOD = {};
xhtmlExportStrings.PROGRESSIVE = {};
xhtmlExportStrings.BASELINE = {};

// advanced
xhtmlExportStrings.ADVANCED = {};
xhtmlExportStrings.CSSOPTIONS = {};
xhtmlExportStrings.EMPTYCSS = {};
xhtmlExportStrings.NOCSS = {};
xhtmlExportStrings.EXTERNALCSS = {};
xhtmlExportStrings.JAVASCRIPT = {};
xhtmlExportStrings.LINKTOJAVASCRIPT = {};