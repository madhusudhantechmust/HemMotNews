//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLStrings-en_US.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//========================================================================================

var xhtmllocale = 'en';		// this is also the fallback for all English locales

//------------------------------------------------------------------------------
// General strings
//------------------------------------------------------------------------------

xhtmlExportStrings.CANCEL[xhtmllocale] = 'Cancel';


//------------------------------------------------------------------------------
// Menus and Actions
//------------------------------------------------------------------------------

xhtmlExportStrings.HTMLACTIONNAME[xhtmllocale] = 'XHTML / &Dreamweaver...';					//obsolete as of Basil
xhtmlExportStrings.EXPORTXHTMLSUBMENUNAME[xhtmllocale] = 'Expo&rt XHTML';					//added in Basil
xhtmlExportStrings.FORDREAMWEAVERACTIONNAME[xhtmllocale] = 'Export for Dream&weaver...';			//added in Basil
xhtmlExportStrings.EXPORTXHTMLFORDREAMWEAVER[xhtmllocale] = 'Export XHTML for Dreamweaver';	//added in Basil


//------------------------------------------------------------------------------
// Error Messages
//------------------------------------------------------------------------------

// the \n create new lines. on the mac the first line gets bolded
xhtmlExportStrings.FILEERROR[xhtmllocale] = 'Exporting “%1” as XHTML failed.\nCouldn’t create file “%2”. There might not be sufficient space available, or you may not have permission to create files in this location.';
xhtmlExportStrings.CREATEFOLDERERROR[xhtmllocale] = 'Exporting “%1” as XHTML failed.\nCouldn’t create folder “%2”. There might not be sufficient space available, or you may not have permission to create files in this location.';
xhtmlExportStrings.DELETEFILEERROR[xhtmllocale] = 'Exporting “%1” as XHTML failed.\nCouldn’t delete file “%2”. You may not have permission to delete files in this location.';
xhtmlExportStrings.LOADSCRIPTERROR[xhtmllocale] = 'Export requires missing script file.\nThe required script file “%1” could not be opened or is missing.';
xhtmlExportStrings.ILLEGALFILENAMEERROR[xhtmllocale] = 'Illegal filename.\nThe filename “%1” contains one or more of these illegal characters:\n/ \\ : * ? " < > |';

//------------------------------------------------------------------------------
// Warning Messages
//------------------------------------------------------------------------------

// this is the general warning string
xhtmlExportStrings.EXPORTWARNING[xhtmllocale] = 'The XHTML file was exported but one or more problems were detected:';

// these strings get concatenated on an as-needed-basis to the general warning string above
xhtmlExportStrings.MISSINGLINKSWARNINGSTRING[xhtmllocale] = 'Linked images: %1 missing';
xhtmlExportStrings.OUTOFDATELINKSWARNINGSTRING[xhtmllocale] = 'Linked images: %1 out of date';
xhtmlExportStrings.SKIPPEDIMAGEWARNINGSTRING[xhtmllocale] = 'Pasted images: %1 skipped (only linked images are exported)';
xhtmlExportStrings.MISSINGMOVIESWARNINGSTRING[xhtmllocale] = 'Linked movies: %1 missing';
xhtmlExportStrings.SKIPPEDMOVIESWARNINGSTRING[xhtmllocale] = 'Unsupported movies: %1 skipped (only .SWF movies are exported)';

//------------------------------------------------------------------------------
// Progress Bar
//------------------------------------------------------------------------------

xhtmlExportStrings.EXPORTTOHTML[xhtmllocale] = 'Exporting XHTML';
xhtmlExportStrings.PROGRESSCANCELMAC[xhtmllocale] = 'To cancel, press Esc or Cmd + Period.';
xhtmlExportStrings.PROGRESSCANCELWIN[xhtmllocale] = 'To cancel, press Esc.';


//------------------------------------------------------------------------------
// XHTML Export Dialog
//------------------------------------------------------------------------------

// general
xhtmlExportStrings.EXPORTBUTTON[xhtmllocale] = 'Export';
xhtmlExportStrings.HTMLEXPORTOPTIONS[xhtmllocale] = 'XHTML Export Options';
xhtmlExportStrings.GENERAL[xhtmllocale] = 'General';
xhtmlExportStrings.BULLETSANDNUMBERS[xhtmllocale] = 'Bullets and Numbers';
xhtmlExportStrings.SCOPE[xhtmllocale] = 'Export';
xhtmlExportStrings.BULLETEDLISTS[xhtmllocale] = '&Bullets:';
xhtmlExportStrings.NUMBEREDLISTS[xhtmllocale] = '&Numbers:';
xhtmlExportStrings.ASUNORDEREDLISTS[xhtmllocale] = 'Map to Unordered Lists';
xhtmlExportStrings.ASORDEREDLISTS[xhtmllocale] = 'Map to Ordered Lists';
xhtmlExportStrings.FIXEDNUMBERS[xhtmllocale] = 'Map to Static Ordered Lists';
xhtmlExportStrings.ASTEXT[xhtmllocale] = 'Convert to Text';
xhtmlExportStrings.EXPORTSELECTION[xhtmllocale] = '&Selection';
xhtmlExportStrings.EXPORTDOCUMENT[xhtmllocale] = '&Document';

// images
xhtmlExportStrings.IMAGES[xhtmllocale] = 'Images';
xhtmlExportStrings.COPYIMAGES[xhtmllocale] = '&Copy Images:';
xhtmlExportStrings.SERVERPATH[xhtmllocale] = 'Link to Server Path';
xhtmlExportStrings.ORIGS[xhtmllocale] = 'Original';
xhtmlExportStrings.OPTORIGS[xhtmllocale] = 'Optimized';
xhtmlExportStrings.PATH[xhtmllocale] = 'P&ath on Server:';
xhtmlExportStrings.EXTENSION[xhtmllocale] = 'File Ex&tension:';
xhtmlExportStrings.FORMATTED[xhtmllocale] = '&Formatted';
xhtmlExportStrings.CONVERSION[xhtmllocale] = '&Image Conversion:';
xhtmlExportStrings.AUTO[xhtmllocale] = 'Automatic';
xhtmlExportStrings.GIF[xhtmllocale] = 'GIF';
xhtmlExportStrings.JPEG[xhtmllocale] = 'JPEG';
xhtmlExportStrings.GIFOPTIONS[xhtmllocale] = 'GIF Options';
xhtmlExportStrings.PALETTE[xhtmllocale] = '&Palette:';
xhtmlExportStrings.ADAPTIVE[xhtmllocale] = 'Adaptive (no dither)';
xhtmlExportStrings.WEB[xhtmllocale] = 'Web';
xhtmlExportStrings.SYSWIN[xhtmllocale] = 'System (Win)';
xhtmlExportStrings.SYSMAC[xhtmllocale] = 'System (Mac)';
xhtmlExportStrings.INTERLACED[xhtmllocale] = 'Inter&lace';
xhtmlExportStrings.JPEGOPTIONS[xhtmllocale] = 'JPEG Options';
xhtmlExportStrings.QUALITY[xhtmllocale] = 'Image &Quality:';
xhtmlExportStrings.LOW[xhtmllocale] = 'Low';
xhtmlExportStrings.MEDIUM[xhtmllocale] = 'Medium';
xhtmlExportStrings.HIGH[xhtmllocale] = 'High';
xhtmlExportStrings.MAX[xhtmllocale] = 'Maximum';
xhtmlExportStrings.FORMATMETHOD[xhtmllocale] = 'Format &Method:';
xhtmlExportStrings.PROGRESSIVE[xhtmllocale] = 'Progressive';
xhtmlExportStrings.BASELINE[xhtmllocale] = 'Baseline';


// advanced
xhtmlExportStrings.ADVANCED[xhtmllocale] = 'Advanced';
xhtmlExportStrings.CSSOPTIONS[xhtmllocale] = 'CSS Options';
xhtmlExportStrings.EMPTYCSS[xhtmllocale] = '&Empty CSS Declarations';
xhtmlExportStrings.NOCSS[xhtmllocale] = 'N&o CSS';
xhtmlExportStrings.EXTERNALCSS[xhtmllocale] = 'E&xternal CSS:';
xhtmlExportStrings.JAVASCRIPT[xhtmllocale] = 'JavaScript Options';
xhtmlExportStrings.LINKTOJAVASCRIPT[xhtmllocale] = '&Link to External JavaScript:';