//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLUtils.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Utility functions
//  
//========================================================================================

function XHTMLUtils() {
}


//------------------------------------------------------------------------------
// XHTMLUtils.isMacintosh
//------------------------------------------------------------------------------

XHTMLUtils.isMacintosh = function () {
	return File.fs == 'Macintosh';
} // XHTMLUtils.isEmptyString


//------------------------------------------------------------------------------
// XHTMLUtils.isEmptyString
//------------------------------------------------------------------------------

XHTMLUtils.isEmptyString = function (s) {
	return (s == undefined || s == null || s == '');
} // XHTMLUtils.isEmptyString


//------------------------------------------------------------------------------
// XHTMLUtils.XHTMLUtils.nameWithoutExt
// Returns a new string with everything after and including the last dot removed
//------------------------------------------------------------------------------

XHTMLUtils.nameWithoutExt = function(s) {
	var dot = s.lastIndexOf('.');
	if(dot == -1)
		return s;
	else
		return s.substring(0,dot);
} // XHTMLUtils.nameWithoutExt


//------------------------------------------------------------------------------
// XHTMLUtils.XHTMLUtils.exgetExtension
// Returns a new string with everything after the last dot
//------------------------------------------------------------------------------

XHTMLUtils.getExtension = function(s) {
	var dot = s.lastIndexOf('.');
	if(dot == -1)
		return '';
	else
		return s.substring(dot+1);
} // XHTMLUtils.getExtension


//------------------------------------------------------------------------------
// XHTMLUtils.XHTMLUtils.isLegalFileName
//------------------------------------------------------------------------------

XHTMLUtils.isLegalFileName = function(s) {
	return (s.search(/[\/\\\:\*\?"<>\|]/) < 0);
} // XHTMLUtils.getExtension


//------------------------------------------------------------------------------
// XHTMLUtils.XHTMLUtils.isJapaneseFeatureSet
//------------------------------------------------------------------------------

XHTMLUtils.isJapaneseFeatureSet = function(){
	//return (app.featureSet == FeatureSetOptions.roman)
	return (app.featureSet == FeatureSetOptions.japanese);
} // XHTMLUtils.isJapaneseFeatureSet


//------------------------------------------------------------------------------
// XHTMLUtils.encodeUserSuppliedURL
// Only escapes if there is no % in the strings
//------------------------------------------------------------------------------

XHTMLUtils.encodeUserSuppliedURL = function(url){
	if(url.search(/%\d\d/) > -1) {
		// the string contains a %hh so we assume that it is already escaped
		return url;
	} else {
		return encodeURI(url);
	}
} // XHTMLUtils.encodeUserSuppliedURL


//------------------------------------------------------------------------------
// XHTMLUtils.getFirstPageItemOfStory/getPageItemOfStory
// Find the first/last page item a story flows through
//------------------------------------------------------------------------------

XHTMLUtils.getTextFrameOrPageItem = function(item) {
	if(item.constructor.name == "TextFrame") {
		return item;
	} else {
		return item.parent;
	}
}

XHTMLUtils.getFirstPageItemOfStory = function(story) {
	return XHTMLUtils.getTextFrameOrPageItem(story.textContainers[0]);
}

XHTMLUtils.getLastPageItemOfStory = function(story) {
	return XHTMLUtils.getTextFrameOrPageItem(story.textContainers[story.textContainers.length-1]);
}

//------------------------------------------------------------------------------
// XHTMLUtils.cleanAttributeValue
// Used to turn InDesign style names into valid attribute values
//------------------------------------------------------------------------------

XHTMLUtils.cleanAttributeValue = function(s) {
	// prepend an x if first character is not a letter of the Roman alphabet
	var result = s.toLowerCase().replace(/^([^a-zA-Z])/,'x$1');
	
	// replace any sequence of characters that are not in a-z, A-Z, 0-9 with a dash
	return result.replace(/[^a-zA-Z0-9]+/g,'-');
} // XHTMLUtils.cleanAttributeValue


//------------------------------------------------------------------------------
// XHTMLUtils.entitytizeAttributeValue
// Make sure that we don't have any illegal characters in an attribute value
//------------------------------------------------------------------------------

XHTMLUtils.entitytizeAttributeValue = function(s) {
	var result = s.replace(/&/g,'&amp;');	// ampersand -- must be the first entity replacement
	result = result.replace(/</g,'&lt;');		// less than
	result = result.replace(/>/g,'&gt;');		// greater than
	return result.replace(/"/g,'&quot;');	// straight quote
} // XHTMLUtils.entitytizeAttributeValue


//------------------------------------------------------------------------------
// XHTMLUtils.prefsContext
// Use this to change and restore preferences
//------------------------------------------------------------------------------

XHTMLUtils.prefsContext = function(prefsObject) {
	this.prefs = prefsObject;
	this.oldPropertyValues  = {};
}

XHTMLUtils.prefsContext.prototype.setPreference = function(property, value) {
	if(this.prefs[property] != value) {
		this.oldPropertyValues[property] = this.prefs[property];
		this.prefs[property] = value;
	}
}

XHTMLUtils.prefsContext.prototype.restoreOldValues = function() {
	for (var prop in this.oldPropertyValues) {
		this.prefs[prop] = this.oldPropertyValues[prop];
	}
}
//------------------------------------------------------------------------------
// XHTMLUtils.getStoryContext
// Recursively look for a valid story context (Story, Table, Footnote) and return
// a unique string identifying the context
// Notice that table cells don't have an id that is unique within the document
// so we are combining the id of the cell with the id of its table
//------------------------------------------------------------------------------

XHTMLUtils.getParentTable = function(item) {
	var type = item.constructor.name;
	
	if(type == "Table") {
		return item;
	} else {
		return XHTMLUtils.getParentTable(item.parent);
	}
}

XHTMLUtils.getStoryContext = function(item) {
	var type = item.constructor.name;
	
	if (type == "Story" || type == "Footnote") {
		return item.id.toString();
	} else if (type == "Cell") {
		return XHTMLUtils.getParentTable(item.parent).id.toString() + '-' + item.id;
	} else {
		return XHTMLUtils.getStoryContext(item.parent);
	}
} // XHTMLDocumentContext.getStoryContext

//------------------------------------------------------------------------------
// XHTMLUtils.getFullDocumentName
// returns the full name of a document, returns the doc's name instead if it 
//	can't get the full name (e.g. converted document, untitled document)
//------------------------------------------------------------------------------

XHTMLUtils.getFullDocumentName = function(doc) {
	var name = '';
	try {
		name = doc.fullName.toString();
	} catch (x) {
		try {
			name = doc.name;
		} catch (x) {
			name = doc.toSpecifier();
		}
	}
	return name;
} // XHTMLDocumentContext.getStoryContext

//------------------------------------------------------------------------------
// XHTMLError
//------------------------------------------------------------------------------

function XHTMLError(s) {
	this.errorString = localize.apply(undefined, arguments);
} // XHTMLError

/*
alert(app.scriptPreferences.version);
var test = new XHTMLScriptPrefsContext();
test.setScriptPref('version', 3.0);
alert(app.scriptPreferences.version);
test.restoreScriptPrefs();
alert(app.scriptPreferences.version);
*/