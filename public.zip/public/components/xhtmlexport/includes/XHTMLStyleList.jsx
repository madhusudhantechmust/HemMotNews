//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLStyleList.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Keeps track of all styles, their css class and tag equivalents
//  Resolves naming conflicts
//  
//  Constructor
//  
//========================================================================================

function XHTMLStyleList(styleConverter) {

	// we store the uid keys as properties on objects in order to benefit from 
	// JavaScript's built-in hashing functionality for properties
		
	// for each style id id2name contains a property that returns the 
	// css class name 
	this.id2name = {};
	
	// name2tag contains all CSS class names tracked by this list
	// we use it to make sure that we don't use the
	// same css class name for different styles
	this.name2tag = {};
	
	// the converter function
	this.converter = styleConverter;
	
}
	
//------------------------------------------------------------------------------
// XHTMLStyleList.prototype.reserveClass
// Marks a class as being reserved
//------------------------------------------------------------------------------

XHTMLStyleList.prototype.reserveClass = function(cls) {
	this.name2tag[cls] = 'reserved';
} // XHTMLStyleList.prototype.getClassAndTag


//------------------------------------------------------------------------------
// XHTMLStyleList.prototype.getClassAndTag
// Returns an object for the given style that contains two properties:
//	tag
//	cssclass
//------------------------------------------------------------------------------

XHTMLStyleList.getID = function(style) {
	// try to get the style from the specifier string in order to improve performance
	var specID = style.toSpecifier().match(/-(style|list)\[@id=([\d]+)/);
	
	if(specID == null) {
		alert('Couldn\'t resolve "' + style.toSpecifier() + '"');
		return style.id.toString();
	} else {
		return specID[2];
	}
}

XHTMLStyleList.prototype.getClassAndTag = function(style) {
	// determine the property name for the uid of the style
	if(style == null) {
		var id = '0';
	} else {
		var id = XHTMLStyleList.getID(style);
		//var id = style.id.toString();
	}
				
	var cls = this.id2name[id];
	if(cls == undefined) {
		return this.addStyle(id, style);
	} else {
		return {tag: this.name2tag[cls], cssclass: cls};
	}
} // XHTMLStyleList.prototype.getClassAndTag

//------------------------------------------------------------------------------
// XHTMLStyleList.paraStyleConverter
// Class method that converts paragraph styles to ccs classes
//------------------------------------------------------------------------------

XHTMLStyleList.paraStyleConverter = function(style) {
	var result = {tag: 'p', cssclass: ''};
		
	var name = XHTMLStyleList.getFullStyleName(style);
	if(name[0] != '[') {
		result.cssclass = XHTMLUtils.cleanAttributeValue(name);
	}
		
	return result;
} // XHTMLStyleList.paraStyleConverter
	

//------------------------------------------------------------------------------
// XHTMLStyleList.objStyleConverter
// Class method that converts object styles to ccs classes
//------------------------------------------------------------------------------
	
XHTMLStyleList.objStyleConverter = function(style) {
	var result = {tag: 'div', cssclass: ''};
		
	var name = (style == null ? '[None]' : style.name);
	if(name[0] != '[') {
		result.cssclass = XHTMLUtils.cleanAttributeValue(name);
	}
		
	return result;
} // XHTMLStyleList.objStyleConverter
	

//------------------------------------------------------------------------------
// XHTMLStyleList.listConverter
// Class method that converts lists to ccs classes
//------------------------------------------------------------------------------
	
XHTMLStyleList.listConverter = function(list) {
	var result = {tag: 'ol', cssclass: ''};
		
	var name = (list == null ? '[None]' : list.name);
	if(name[0] != '[') {
		result.cssclass = XHTMLUtils.cleanAttributeValue(name);
	}
		
	return result;
} // XHTMLStyleList.listConverter

	

//------------------------------------------------------------------------------
// XHTMLStyleList.charStyleConverter
// Class method that converts character styles to ccs classes
//------------------------------------------------------------------------------
	
XHTMLStyleList.charStyleConverter = function(style) {
	var result = {tag: 'span', cssclass: ''};
		
	var name = XHTMLStyleList.getFullStyleName(style);
	if(name[0] != '[') {
		result.cssclass = XHTMLUtils.cleanAttributeValue(name);
	}
		
	return result;
} // XHTMLStyleList.charStyleConverter	
		
//------------------------------------------------------------------------------
// XHTMLStyleList.tableStyleConverter
// Class method that converts table styles to ccs classes
//------------------------------------------------------------------------------
	
XHTMLStyleList.tableStyleConverter = function(style) {
	var result = {tag: 'table', cssclass: ''};
		
	var name = XHTMLStyleList.getFullStyleName(style);
	if(name[0] != '[') {
		result.cssclass = XHTMLUtils.cleanAttributeValue(name);
	}
		
	return result;
} // XHTMLStyleList.tableStyleConverter	
		
//------------------------------------------------------------------------------
// XHTMLStyleList.cellStyleConverter
// Class method that converts table styles to ccs classes
//------------------------------------------------------------------------------
	
XHTMLStyleList.cellStyleConverter = function(style) {
	var result = {tag: 'td', cssclass: ''};
		
	var name = XHTMLStyleList.getFullStyleName(style);
	if(name[0] != '[') {
		result.cssclass = XHTMLUtils.cleanAttributeValue(name);
	}
		
	return result;
} // XHTMLStyleList.cellStyleConverter	
		
//------------------------------------------------------------------------------
// END OF PUBLIC SECTION
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// XHTMLStyleList.prototype.addStyle
//------------------------------------------------------------------------------
		
XHTMLStyleList.prototype.addStyle = function(id, style) {
	var conversion = this.converter(style);
	var cls = conversion.cssclass;
	
	// check whether name is already used and resolve conflicts
	if(cls != '' && this.name2tag[cls] != undefined) {
		conversion.cssclass = this.resolveNameConflict(cls);
	}
	// create a property that contains the css class name
	this.id2name[id] = conversion.cssclass;
	// add the css class name to the names object
	this.name2tag[conversion.cssclass] = conversion.tag;
	return conversion;
} // XHTMLStyleList.prototype.addStyle


//------------------------------------------------------------------------------
// XHTMLStyleList.prototype.resolveNameConflict
//------------------------------------------------------------------------------
		
XHTMLStyleList.prototype.resolveNameConflict = function(cssClass) {
	var i = 1;
	var done = false;
	var endsWithDash = cssClass[cssClass.length-1] == '-';
	while(!done) {
		var newname = cssClass + (endsWithDash ? '' : '-') + (++i);
		done = (this.name2tag[newname] == undefined);
	}
	return newname;
} // XHTMLStyleList.prototype.resolveNameConflict


//------------------------------------------------------------------------------
// XHTMLStyleList.getFullStyleName
// helper method to recursively determine the full name of a style within a style set
//------------------------------------------------------------------------------

XHTMLStyleList.getFullStyleName = function(styleOrParent) {
	if (styleOrParent == null) {
		return '[None]';
	}
	var kind = styleOrParent.constructor.name;
	if(kind == 'Document' || kind == 'Application') {
		return '';
	} else {
		var parentname = XHTMLStyleList.getFullStyleName(styleOrParent.parent);
		if (parentname == '') {
			return styleOrParent.name;
		} else {
			return parentname + '-' + styleOrParent.name;	// concat with dash
		}
	}
} // XHTMLStyleList.getFullStyleName
	