//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLDocumentContext.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose:
//  Keeps track of the context of the current document
//  
//  constructor
//  
//========================================================================================

function XHTMLDocumentContext(doc, docid, idGenerator, suppressCrossDocLinks) {
	this.doc = doc;
	this.docid = docid;
	
	// the hyperlinks and text anchors for the current documents
	this.hyperlinks = {};
	this.anchors = {};
	
	// initialize context based on doc
	this.scanForHyperlinksAndAnchors(idGenerator, suppressCrossDocLinks);
} // XHTMLStoryContext


//------------------------------------------------------------------------------
// Helper objects
//------------------------------------------------------------------------------

function XHTMLHyperlink(url, start, end, id, doc) {
	this.url = url;
	this.start = start;
	this.end = end;
	this.id = id;
	this.doc = doc;		// the full name of document of the destination 
							// (undefined in case of a web hyperlink 
							// or an intra-document hyperlink)
}

function XHTMLAnchor(name, index) {
	this.name = name;
	this.index = index;
}


//------------------------------------------------------------------------------
// End of public section
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Compare methods to sort lists
//------------------------------------------------------------------------------

XHTMLDocumentContext.compareHyperlinks = function(a,b) {
	return a.start - b.start;
} // XHTMLDocumentContext.compareHyperlinks

XHTMLDocumentContext.compareAnchors = function(a,b) {
	return a.index - b.index;
} // XHTMLDocumentContext.compareHyperlinks
//------------------------------------------------------------------------------
// Compare methods to sort lists
//------------------------------------------------------------------------------

XHTMLDocumentContext.prototype.scanForHyperlinksAndAnchors = function(idGenerator, suppressCrossDocLinks) {
	var anchorSuffix  = "-anchor";
	var thisDocFullName = XHTMLUtils.getFullDocumentName(this.doc);
	
	// first collect all hyperlink text anchors and x-ref paragraph destination anchors
	for (var destType = 0; destType < 2; destType++) {
		var anchors = ((destType == 0) ? this.doc.hyperlinkTextDestinations : this.doc.paragraphDestinations);
		var count = anchors.length;
		for (var i = 0; i<count; i++) {
			var anchor = anchors[i];
			var name = anchor.name;
			var id = idGenerator.newID(XHTMLUtils.cleanAttributeValue(name + anchorSuffix));
			var destText = anchor.destinationText;
			var story = XHTMLUtils.getStoryContext(destText);
			var index = destText.insertionPoints[0].index;
			var newAnchor = new XHTMLAnchor(id, index);
			if(this.anchors[story] != undefined)
				this.anchors[story].push(newAnchor);
			else
				this.anchors[story] = [newAnchor];
		}
	}
	
	// now collect all hyperlinks
	var hyperlinks = this.doc.hyperlinks;
	count = hyperlinks.length;
	for (i = 0; i<count; i++) {
		var link = hyperlinks[i];
		var source = link.source;
		if (source.constructor.name == 'HyperlinkTextSource' || source.constructor.name == 'CrossReferenceSource') {
			// we only support text-based hyperlinks
			try {	// guard against missing destination documents
				var destination = link.destination;
				if(destination != null && destination != undefined) {
					var url = '';
					var destDoc = undefined;
					switch (destination.constructor.name) {
						case 'HyperlinkTextDestination':
						case 'ParagraphDestination':
							destDoc = XHTMLUtils.getFullDocumentName(destination.parent);
							var isLocalAnchor = (destDoc == thisDocFullName);
							if(!suppressCrossDocLinks || isLocalAnchor) {
								var name = XHTMLUtils.cleanAttributeValue(destination.name + anchorSuffix);
								url = "#" + encodeURIComponent(name);
								if (isLocalAnchor) {
									destDoc = undefined; // intra document hyperlink
								}
							}
						break;
						case 'HyperlinkURLDestination':
							url = XHTMLUtils.encodeUserSuppliedURL(destination.destinationURL);
						break
					}
					if (url != '') {
						// add hyperlink to list of hyperlinks
						var story = XHTMLUtils.getStoryContext(source.sourceText);
						var start = source.sourceText.insertionPoints[0].index;
						var end = source.sourceText.insertionPoints.lastItem().index;
						var id = source.id;
						var newHyperlink = new XHTMLHyperlink(url, start, end, id, destDoc);
						if(this.hyperlinks[story] != undefined)
							this.hyperlinks[story].push(newHyperlink);
						else
							this.hyperlinks[story] = [newHyperlink];
					}
				}
			} catch(x) {
				// hyperlinks to missing documents drop out silently
			}
		}
	}
	
	// sort the lists
	for (var property in this.anchors) {
		this.anchors[property].sort(XHTMLDocumentContext.compareAnchors);
	}
	for (var property in this.hyperlinks) {
		this.hyperlinks[property].sort(XHTMLDocumentContext.compareHyperlinks);
	}
} // XHTMLDocumentContext.prototype.scanHyperlinks