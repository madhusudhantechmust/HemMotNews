//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLItemSorter.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Order items to be exported to XHTML
//  
//========================================================================================

function XHTMLItemSorter() {
}

//------------------------------------------------------------------------------
// XHTMLItemSorter.sortLeftToRight
// Sorts according to the following order
// 		1. Spread number, ascending
// 		2. Page number, ascending
//		3. Left X-coordinate, ascending
// 		4. Top Y-coordinate, ascending
//------------------------------------------------------------------------------

XHTMLItemSorter.sortLeftToRight = function(items, removePasteboardItems) {
	XHTMLItemSorter.sort(items, removePasteboardItems, XHTMLItemSorter.compareL2R);
} // XHTMLItemSorter.sortLeftToRight


//------------------------------------------------------------------------------
// XHTMLItemSorter.sortVertically
// Sorts according to the following order
// 		1. Spread number, ascending
// 		2. Page number, ascending
// 		3. Top Y-coordinate, ascending
//		4. Right X-coordinate, descending
//------------------------------------------------------------------------------

XHTMLItemSorter.sortVertically = function(items, removePasteboardItems) {
	XHTMLItemSorter.sort(items, removePasteboardItems, XHTMLItemSorter.compareVertically);
} // XHTMLItemSorter.sortVertically



//------------------------------------------------------------------------------
// END OF PUBLIC SECTION
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// XHTMLItemSorter.sort
//------------------------------------------------------------------------------

XHTMLItemSorter.sort = function(items, removePasteboardItems, compareFunction) {
	XHTMLItemSorter.wrap(items);
	
	if(removePasteboardItems) {
		var count = items.length;
		for (var i = 0; i < count; i++) {
			if(items[i].page == Infinity) {
				items[i] = undefined;
			}
		}
	}
	
	// sort sorts undefined items to the end
	items.sort(compareFunction);
	
	if(removePasteboardItems) {
		while(items.length > 0 && items[items.length-1] == undefined) {
			items.pop();
		}
	}
	
	XHTMLItemSorter.unwrap(items);
} // XHTMLItemSorter.sortLeftToRight

//------------------------------------------------------------------------------
// XHTMLItemSorter.getSpreadFromPageItem
// recursively examine the parent in the hierarchy to find the spread
//------------------------------------------------------------------------------

XHTMLItemSorter.getPageAndSpreadFromPageItem = function(item) {
	var type = item.constructor.name;
	
	switch(type) {
		case 'Spread':
		case 'MasterSpread':
			return { spread : item.index };
		break;
		case 'Page':
			var result = XHTMLItemSorter.getPageAndSpreadFromPageItem(item.parent);
			result.page = item.index;
			return result;
		break;
		case 'Character': // this is an inline
			if(item.parentTextFrames.length == 0)	{	// overset
				// let's take the spread of the last text frame of the parent story
				if(item.parent.textContainers.length == 0 )	{
					return XHTMLItemSorter.getPageAndSpreadFromPageItem(XHTMLUtils.getLastPageItemOfStory(item.parent.parent));
				} else {
					return XHTMLItemSorter.getPageAndSpreadFromPageItem(XHTMLUtils.getLastPageItemOfStory(item.parent));
				}
			} else {
				return XHTMLItemSorter.getPageAndSpreadFromPageItem(item.parentTextFrames[0]);
			}
		break;
		default:
			return XHTMLItemSorter.getPageAndSpreadFromPageItem(item.parent);
		break;
	}
} // XHTMLItemSorter.getPageAndSpreadFromPageItem


//------------------------------------------------------------------------------
// XHTMLItemSorter.compareL2R
// Sorts according to the following order
// 		1. Spread number, ascending
// 		2. Page number, ascending
//		3. Left X-coordinate, ascending
// 		4. Top Y-coordinate, ascending
//------------------------------------------------------------------------------

XHTMLItemSorter.compareL2R = function(a,b) {
	if(a == undefined) {
		return 1;
	}
	if(b == undefined) {
		return -1;
	}
	if(a.spread == b.spread) {
		if(a.page == b.page) {
			if(Math.abs(a.x - b.x) < 1) {	// everyting within 1 point is considering the same
				return a.y - b.y;
			} else {
				return a.x - b.x;
			}
		} else {
			return a.page - b.page;
		}
	} else {
		return a.spread - b.spread;
	}
} // XHTMLItemSorter.compareL2R


//------------------------------------------------------------------------------
// XHTMLItemSorter.compareVertically
// Sorts according to the following order
// 		1. Spread number, ascending
// 		2. Page number, ascending
// 		3. Top Y-coordinate, ascending
//		4. Right X-coordinate, descending
//------------------------------------------------------------------------------

XHTMLItemSorter.compareVertically = function(a,b) {
	if(a == undefined) {
		return 1;
	}
	if(b == undefined) {
		return -1;
	}
	if(a.spread == b.spread) {
		if(a.page == b.page) {
			if(Math.abs(a.y - b.y) < 1) { // everyting within 1 point is considering the same
				return b.x2 - a.x2;
			} else {
				return a.y - b.y;
			}
		} else {
			return a.page - b.page;
		}
	} else {
		return a.spread - b.spread;
	}
} // XHTMLItemSorter.compareVertically


//------------------------------------------------------------------------------
// XHTMLItemSorter.wrap
//------------------------------------------------------------------------------

XHTMLItemSorter.wrap = function(items) {
	for (var i=0; i<items.length; i++) {
		items[i] = new XHTMLItemSorterWrapper(items[i]);
	}
} // XHTMLItemSorter.wrap


//------------------------------------------------------------------------------
// XHTMLItemSorter.unwrap
//------------------------------------------------------------------------------

XHTMLItemSorter.unwrap = function(items) {
	for (var i=0; i<items.length; i++) {
		items[i] = items[i].item;
	}
} // XHTMLItemSorter.unwrap


//------------------------------------------------------------------------------
// XHTMLItemSorterWrapper
// helper object that wraps an item and caches the attributes that determine the 
// sort order as a performance optimization
//------------------------------------------------------------------------------

function XHTMLItemSorterWrapper(item) {
	this.item = item;
	var pageItem = item;
	
	switch (item.constructor.name) {
		case "InsertionPoint":
		case "Text":
		case "TextStyleRange":
		case "TextColumn":
		case "Word":
		case "Paragraph":
		case "Line":
		case "TextPath":
			// the first text frame of the parent story determines
			// where we put these
			pageItem = XHTMLUtils.getFirstPageItemOfStory(item.parentStory);
		break;
		case 'Story':
			// ditto
			pageItem = XHTMLUtils.getFirstPageItemOfStory(item);
		break;
		case "PDF":
		case "Image":
		case "Word":
		case "PICT":
		case "EPS":
		case "WMF":
		case "ImportedPage":
		case "Table":
			pageItem = item.parent;
		break;
		case "Cell":
			pageItem = item.parent.parent;
		break;
	}
		
	var pageAndSpread = XHTMLItemSorter.getPageAndSpreadFromPageItem(pageItem);
	this.spread = pageAndSpread.spread;
	this.page = pageAndSpread.page;
	if(this.page == undefined) {
		this.page = Infinity;
	}
	
	try {
		var bounds = pageItem.visibleBounds;
		this.x = bounds[1];
		this.y = bounds[0];
		this.x2 = bounds[3];	// use the rightmost x-coordinate
	} catch(x) {
		// likely something in overset text
		this.x = Infinity;
		this.y = Infinity;
		this.x2 = 0;
	}
} // XHTMLItemSorterWrapper


//------------------------------------------------------------------------------
// Test Code
//------------------------------------------------------------------------------

/*
//var list = app.activeDocument.allPageItems
var list = app.selection
var count = list.length;
for(var i = 0; i < count; i++) {
	list[i] = list[i].parentStory;
}
XHTMLItemSorter.sortLeftToRight(list, true);
//XHTMLItemSorter.sortVertically(list, true);
var count = list.length;
for(var i = 0; i < count; i++) {
	$.writeln(list[i].contents);
}
*/