//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/SimpleObjectStore.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: 
//  Serialize and deserialize javascript objects without
//  having to eval() stored scripts.
//  
//  Uses ExtendScript's built-in E4X support.
//  
//  Currently limited to strings, booleans and numbers
//  NO SUPPORT FOR OBJECTS AND ARRAYS!
//  
//  SOS Namespace
//  
//========================================================================================

function SOS() {
}


//------------------------------------------------------------------------------
// SOS.serialize
// Returns a string representing the values of the properties of the given obj
//------------------------------------------------------------------------------

SOS.serialize = function(obj) {
	var x = new XML('<' + obj.constructor.name + '/>');
	for (var property in obj) {
		// get the property value
		var value = obj[property];
		switch (typeof value) {
			case 'string':
				x[property] = value;
			break;
			case 'number':
			case 'boolean':
				x[property] = value.toString()
			break;
		}
	}
	return x.toXMLString();
} // SOS.serialize


//------------------------------------------------------------------------------
// SOS.deserialize
// Restores the properties of the given obj with the values previously
// encoded into s by SOS.serialize
// Only sets properties that already exist in obj.
//------------------------------------------------------------------------------

SOS.deserialize = function(s, obj) {
	var success = true;
	try {
		var x = new XML(s);
		if (x.localName() != obj.constructor.name) {
			return false;
		}
		for (var property in obj) {
			// get the property value
			try {
				if(x[property].childIndex() >= 0) {
					var value = x[property].toString();
					switch (typeof obj[property]) {
						case 'string':
							obj[property] = value;
						break;
						case 'number':
							obj[property] = Number(value);
							break;
						case 'boolean':
							obj[property] = !(value == 'false');
						break;
					}
				}
			} catch(e) {
				success = false;
			}
		}
	} catch (e) {
		success = false;
	}
	return success;
} // SOS.deserialize



//------------------------------------------------------------------------------
// END OF PUBLIC SECTION
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Test code
//------------------------------------------------------------------------------

/*
function Foo() {
	this.bar = "\tte\\st\nfoo";
	this.falseval = false;
	this.trueval = true;
	this.val = 475.56;
}

var foo = new Foo();
foo.bar = 'changed';
foo.falseval = true;
foo.trueval = false;
foo.val = 23.5;
var store = SOS.serialize(foo);

var newfoo = new Foo();
SOS.deserialize(store, newfoo);

newfoo.toSource() + "\n" + foo.toSource();
*/