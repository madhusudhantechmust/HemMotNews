//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLStoryContext.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose:
//  Keeps track of the context of the current story (either a real story, a table
//  cell or a footnote, its current paragraph and lists, as well as its
//  tables, inlines, footnotes, variables and text anchors
//  
//  constructor
//  story can be a real story, a tabel cell or a footnote
//  
//========================================================================================

function XHTMLStoryContext(id, tag, cls) {
	// uniquely identifies this story context
	this.contextID = id;
	
	// element tag and class
	// leaving them undefined will keep the context
	// from outputting an element
	this.storytag = tag;
	this.storyclass = cls;
	
	// whether the story is open yet
	this.storyIsOpen = false;
	
	// current paragraph
	this.currentPara = undefined;	
	
	// either contains current bulleted list or a 
	// stack of numbered lists of same list kind in
	// ascending order of levels
	this.currentList = [];			
	
	// postponed inline stories							
	this.inlineQueue = [];			
	
	// the tables, inlines, etc of the story
	this.children = [];				
	
	// keep track of all footnotes that we encounter while
	// processing this story context so we can create the
	// footnote section at the end of the story
	this.footnotecount = 0;
	this.footnotes = [];
} // XHTMLStoryContext

//------------------------------------------------------------------------------
// XHTMLStoryContext.prototype.addFootnote
// Adds a footnote to the list of this stories footnotes
// Returns the footnote helper object
//------------------------------------------------------------------------------

function XHTMLFootnoteHelper(footnote, number, name, backlinkname) {
	this.footnote = footnote;
	this.number = number;
	this.name = name;
	this.backlinkname = backlinkname;
}

XHTMLStoryContext.prototype.addFootnote = function(footnote, idGenerator) {
	this.footnotecount ++;
	var name = idGenerator.newID("footnote-" + this.contextID + "-" + this.footnotecount);
	var newfootnote = new XHTMLFootnoteHelper(footnote, this.footnotecount, name, idGenerator.newID(name + "-backlink"));
	this.footnotes.push(newfootnote);
	return newfootnote;
}  // XHTMLStoryContext.prototype.addFootnote

//------------------------------------------------------------------------------
// Helper Objects
// These objects are used to collect, sort, and store all the children
// of the story context
//------------------------------------------------------------------------------

function XHTMLTable(table, index) {
	this.table = table;
	this.index = index;
}

function XHTMLInline(inline, index) {
	this.inline = inline;
	this.index = index;
}

function XHTMLFootnote(footnote, index) {
	this.footnote = footnote;
	this.index = index;
}

function XHTMLVariable(variable, index) {
	this.text = variable.resultText;
	this.index = index;
}

// used to sort the children
XHTMLVariable.compareIndex = function(a,b) {
	return a.index - b.index;
}


//------------------------------------------------------------------------------
// collectChildren()
// finds all tables, inlines, footnotes, text anchors and variables of the story
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.collectData = function(docContext, story, paraCollection, rangeCollection, contents, pBar) {
	pBar.newSection(13);		// need to be as granular as possible since each DOM call below can take a while
	if(story.constructor.name == 'Footnote') {
		story = story.texts[0];
	}

	// tables
	if("tables" in story) {	 // check whether this kind of story context has this property
		var list = story.tables;
		var count = list.length;
		for (var i=0; i<count; i++) {
			this.children.push(new XHTMLTable(list[i], list[i].storyOffset.index));
		}
	}
	pBar.sectionStepCompleted();
	
	// inlines
	if("pageItems" in story) {	 // check whether this kind of story context has this property
		var list = story.pageItems;
		var count = list.length;
		for (var i=0; i<count; i++) {
			this.children.push(new XHTMLInline(list[i].getElements()[0], list[i].parent.index));
		}
	}
	pBar.sectionStepCompleted();
	
	// footnotes
	if("footnotes" in story) {	 // check whether this kind of story context has this property
		var list = story.footnotes;
		var count = list.length;
		for (var i=0; i<count; i++) {
			this.children.push(new XHTMLFootnote(list[i], list[i].storyOffset.index));
		}
	}
	pBar.sectionStepCompleted();
	
	// variables
	if("textVariableInstances" in story) {	 // check whether this kind of story context has this property
		var list = story.textVariableInstances;
		var count = list.length;
		for (var i=0; i<count; i++) {
			this.children.push(new XHTMLVariable(list[i], list[i].storyOffset.index));
		}
	}
	pBar.sectionStepCompleted();
	
	// text anchors
	if(docContext.anchors[this.contextID] != undefined) {
		var list = docContext.anchors[this.contextID];
		var count = list.length;
		for (var i=0; i<count; i++) {
			this.children.push(list[i]);
		}
	}
	pBar.sectionStepCompleted();
	
	// sort the resulting array by text index
	this.children.sort(XHTMLVariable.compareIndex);
	pBar.sectionStepCompleted();
	
		// get story data
	this.storyContents= contents;
	
	// get paragraph data
	var paraList = paraCollection.everyItem();
	pBar.sectionStepCompleted();
	this.bulletsNumberingTypeList = paraList.bulletsAndNumberingListType;
	pBar.sectionStepCompleted();
	this.paraStyleList = paraList.appliedParagraphStyle;
	pBar.sectionStepCompleted();
	this.paraIndexList =  paraList.index;
	pBar.sectionStepCompleted();
	
	// get text style range data
	var rangeList = rangeCollection.everyItem();
	pBar.sectionStepCompleted();
	this.rangeStyleList = rangeList.appliedCharacterStyle;
	pBar.sectionStepCompleted();
	this.rangeIndexList = rangeList.index;
	pBar.sectionStepCompleted();
	
	pBar.sectionCompleted();
}


//------------------------------------------------------------------------------
// open the story context
// i.e. write out the open tag
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.open = function(buffer) {	
	if(!this.storyIsOpen) {
		if(!XHTMLUtils.isEmptyString(this.storytag)) {
			buffer.openElementContext(this.storytag, this.storyclass);
		}
		this.storyIsOpen = true;
	} else {
		debugger;	// opening a story context twice?
	}
}


//------------------------------------------------------------------------------
// writes out the closing tag for the story element
// does nothing if not open
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.close = function(buffer) {
	// close any open lists
	this.closeOpenLists(buffer);

	if(this.storyIsOpen) {
		if(!XHTMLUtils.isEmptyString(this.storytag)) {
			buffer.closeElementContext(this.storytag);
		}
		this.storyIsOpen = false;
	} else {
		debugger;	// closing a story context twice?
	}		
}




//------------------------------------------------------------------------------
// constructor of paragraph context
//------------------------------------------------------------------------------

function XHTMLParagraphContext(tag, cls, startParagraphWith) {
	this.paratag = tag;
	this.paraclass = cls;
	this.isOpen = false;
	this.nestedInlinesLevel = 0;
	this.startParagraphWith = startParagraphWith;
} // XHTMLParagraphContext


//------------------------------------------------------------------------------
// register a new paragraph context
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.newParagraphContext = function(tag, cls, startParagraphWith) {
	if(this.currentPara != undefined)
		debugger; // nested paragraph?
	
	this.currentPara = new XHTMLParagraphContext(tag, cls, startParagraphWith);
}


//------------------------------------------------------------------------------
// deregister a new paragraph context
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.deleteParagraphContext = function(buffer) {
	if(this.currentPara == undefined)
		debugger;
	if(this.currentPara.nestedInlinesLevel > 0)
		debugger;
	
	if(this.currentPara.isOpen) {
		this.closeParagraph(buffer);
	}
	
	this.currentPara = undefined;
}


//------------------------------------------------------------------------------
// writes out the open tag for the paragraph element
// does nothing if already open
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.openParagraph = function(buffer) {
	if(this.currentPara == undefined)
		debugger;
	if(this.currentPara.nestedInlinesLevel > 0)
		debugger;
		
	if(this.currentPara.isOpen) {
		return;
	}
	
	// see note below on the handling of list elements
	if(this.currentPara.paratag != 'li') {
		buffer.openElement(this.currentPara.paratag, this.currentPara.paraclass);
	}
	if(this.currentPara.startParagraphWith != undefined) {
		buffer.write(this.currentPara.startParagraphWith);
	}
	this.currentPara.isOpen = true;
}
	
			
//------------------------------------------------------------------------------
// writes out the closing tag for the paragraph element
// does nothing if not open
//------------------------------------------------------------------------------
XHTMLStoryContext.prototype.closeParagraph = function(buffer) {	
	if(this.currentPara.nestedInlinesLevel > 0)
		debugger;
	if(!this.currentPara.isOpen) {
		return;
	}
	
	// see note below on the handling of list elements
	if(this.currentPara.paratag != 'li') {
		buffer.closeElement(this.currentPara.paratag);
	}
	this.currentPara.isOpen = false;
}



//------------------------------------------------------------------------------
// Handling of list elements
//
// We try to group list elements within <ol> and <ul> elements. Adjacent bulleted
// paragraphs get joined into the same <ul> if the have the same paragraph style.
// Adjacent numbered lists get joined into the same <ol> if the share the same
// list.
//
// Nested lists in HTML are very different from their counterparts in InDesign.
//
// HTML requires you to explicitly start and end a list whereas in InDesign
// a list item is nothing but a paragraph with some special properties.
// Where InDesign uses the level attribute HTML supports real nested lists.
// Furthermore in HTML nested lists need to be part of a <li> element, they
// can't be a direct child of another list.
//
// We only support nested lists for numbered lists since only those have the
// level attrubute. Furthermore we do not try to exactly match the number of 
// levels with nesting. I.e. if the InDesign text goes from level 3 to 5 we
// do not insert an artificial nested list for the missing 4th level.
//
// In order to support nesting of numbered lists we need to treat list items
// different from other paragraphs. Thus we do not emit open or close tags
// when openParagraph or closeParagraph is called, we rather open the <li>
// when we encounter the list item paragraph and keep it open until we 
// encounter the next paragraph that is not a child of the <li>.
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// constructor of list contexts
//------------------------------------------------------------------------------

function XHTMLBulletedListContext(style, listclass, cls) {
	this.listtype = 'ul';
	this.style =  style;
	this.cls = cls;
} // XHTMLBulletedListContext

function XHTMLNumberedListContext(list, level, cls) {
	this.listtype = 'ol';
	this.list =  list;
	this.cls = cls;
	this.level = level;
} // XHTMLNumberedListContext


//------------------------------------------------------------------------------
// close any open list
// downToLevel is optional
// returns the level of the top-most list or 0 if there is no more list
//------------------------------------------------------------------------------

XHTMLStoryContext.prototype.closeOpenLists = function(buffer, downToLevel) {
	if(downToLevel == undefined) {
		downToLevel = 0;
	}
	var numLists = this.currentList.length;
	var curLevel = (numLists > 0 ? (this.currentList[numLists-1].level == undefined ? 1 : this.currentList[numLists-1].level) : 0);
	while(numLists > 0 && curLevel > downToLevel) {
		var oldlist = this.currentList.pop();
		buffer.closeElement('li');
		if(this.currentList.length == 0) {
			// different formatting for outermost list
			buffer.closeElementContext(oldlist.listtype);
		} else {
			buffer.closeElementContextInline(oldlist.listtype);
		}
		numLists = this.currentList.length;
		curLevel = (numLists > 0 ? (this.currentList[numLists-1].level == undefined ? 1 : this.currentList[numLists-1].level) : 0);
	}
	return curLevel;
}

//------------------------------------------------------------------------------
// handle a new bulletted list item
//------------------------------------------------------------------------------

XHTMLStoryContext.prototype.handleBulletedListItem = function(buffer, style, cls) {
	if(this.currentPara != undefined)
		debugger; // nested paragraph?
	
	var numLists = this.currentList.length;
	if(numLists != 0) {
		currList = this.currentList[numLists-1];
		if(currList.listtype == 'ul') {
			buffer.closeElement('li');
			buffer.openElement('li', cls);
			return;
		} else {
			// we can safely close all open lists since we do not support
			// nested bulleted lists
			this.closeOpenLists(buffer);
		}
	}
	var newlist = new XHTMLBulletedListContext(style, cls);
	buffer.openElementContext(newlist.listtype, newlist.cls);
	buffer.openElement('li', cls);
	this.currentList.push(newlist);
}


//------------------------------------------------------------------------------
// handle a new numbered list item
//------------------------------------------------------------------------------

XHTMLStoryContext.prototype.handleNumberedListItem = function(buffer, para, list, level, listcls, itemcls, fixedNumber) {
	if(this.currentPara != undefined)
		debugger; // nested paragraph?
	
	if(fixedNumber) {
		var num = para.numberingResultNumber;
	}
	
	var numLists = this.currentList.length;
	if(numLists != 0) {
		currList = this.currentList[numLists-1];
		if(currList.listtype == 'ol' && currList.list == list) {
			// close all lists of higher level
			var curLevel = this.closeOpenLists(buffer, level);
			
			if(curLevel == level) {
				// we do not have to start a new list context since
				// we are alreay at the right level
				buffer.closeElement('li');
				buffer.openElement('li', itemcls, fixedNumber ? 'value="' + num + '"' : '');
				return;
			}
		} else {
			// we can safely close all open lists since we do not support
			// nested numbered lists of different list kinds
			this.closeOpenLists(buffer);
		}
	}
	var newlist = new XHTMLNumberedListContext(list, level, listcls);
	if(this.currentList == 0) {
		// different formatting for outermost list
		buffer.openElementContext(newlist.listtype, newlist.cls);
	} else {
		buffer.openElementContextInline(newlist.listtype, newlist.cls);
	}
	buffer.openElement('li', itemcls, fixedNumber ? 'value="' + num + '"' : '');
	this.currentList.push(newlist);
}