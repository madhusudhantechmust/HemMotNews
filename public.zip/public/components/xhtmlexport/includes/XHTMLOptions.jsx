//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLOptions.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Object that holds and persists the options used by XHTMLExport
//  Notice that this doesn't contain any image conversion settings
//  XHTMLExporter uses the exportForWebPreferences of the document
//  
//========================================================================================

//===========================
//  Includes
//===========================

#include "includes/SimpleObjectStore.jsx"

//------------------------------------------------------------------------------
// Constants
//------------------------------------------------------------------------------

XHTMLExportOptions.labelKey = 'XHTMLExportOptions';

//Enum values for XHTMLExportOptions.version
XHTMLExportOptions.currVersion = 5.0;

// Enum values for XHTMLExportOptions.scope
XHTMLExportOptions.exportSelection = 0;
XHTMLExportOptions.exportDocument = 1;

// Enum values for XHTMLExportOptions.bulletedListsPolicy
XHTMLExportOptions.regularUnorderedListItems = 0;
XHTMLExportOptions.convertBulletsToText = 1;

// Enum values for XHTMLExportOptions.numberedListsPolicy
XHTMLExportOptions.regularOrderedListItems = 0;
XHTMLExportOptions.fixedListItems = 1;
XHTMLExportOptions.convertToText = 2;

// Enum values for XHTMLExportOptions.styleHandling
XHTMLExportOptions.emptyStyles = 0;
XHTMLExportOptions.noStyles = 1;
XHTMLExportOptions.extStyleSheet = 2;

// Enum values for XHTMLExportOptions.imageHandling
XHTMLExportOptions.copyOriginal = 0;
XHTMLExportOptions.copyOptimized = 1;
XHTMLExportOptions.linkToServerPath = 2;


//------------------------------------------------------------------------------
// Constructor
//------------------------------------------------------------------------------

function XHTMLExportOptions () {
	
	// version number to enable format conversion
	this.version = XHTMLExportOptions.currVersion;
	
	// these options are honored by XHTMLExport only
	this.scope = XHTMLExportOptions.exportSelection;
	this.lastOutputPath = '';
	this.lastOutputFileName = '';
			
	// handling of lists
	this.numberedListsPolicy = XHTMLExportOptions.regularOrderedListItems;
	this.bulletedListsPolicy = XHTMLExportOptions.regularOrderedListItems;
	
	//style handling
	this.styleHandling = XHTMLExportOptions.emptyStyles;
	this.styleSheet = "";
	
	// javascript
	this.linkToJavaScript = false;
	this.javaScriptURL = '';
	
	// images
	this.imageHandling = XHTMLExportOptions.copyOptimized;
	this.formatted = false;
	this.serverPath = '';
	this.imageExtension = '.jpg';
} // XHTMLExportOptions


//------------------------------------------------------------------------------
// XHTMLExportOptions.restore
// Class method that constructs and returns a new XHTMLExportOptions object based 
// on the data persisted in source
//------------------------------------------------------------------------------

XHTMLExportOptions.restore = function(source) {
	var newOptions = new XHTMLExportOptions();
	try {
		var sos = source.extractLabel(XHTMLExportOptions.labelKey);
		if (!XHTMLUtils.isEmptyString(sos)) {
			SOS.deserialize(sos, newOptions);
			if (newOptions.version > XHTMLExportOptions.currVersion) {
				// saved options are from a newer version
				// create new options to be on the safe side
				newOptions = new XHTMLExportOptions();
			} else if (newOptions.version < XHTMLExportOptions.currVersion) {
				// handle conversion from old versions here
				newOptions = new XHTMLExportOptions();
			}
		}
	}
	catch(e) {
		newOptions = new XHTMLExportOptions();
	}
	return newOptions;
} // XHTMLExportOptions.restore


//------------------------------------------------------------------------------
// XHTMLExportOptions.prototype.persist
// Persists the object to the given target
//------------------------------------------------------------------------------

XHTMLExportOptions.prototype.persist = function(target) {
	var oldData = target.extractLabel(XHTMLExportOptions.labelKey);
	var newData = SOS.serialize(this);
	if(newData != oldData) {
		target.insertLabel(XHTMLExportOptions.labelKey, newData);
	}
} // XHTMLExportOptions.prototype.persist


//------------------------------------------------------------------------------
// End of Public Section
//------------------------------------------------------------------------------

XHTMLExportOptions.setIfDifferent = function(prefs, property, value) {
	if(prefs[property] != value) {
		prefs[property] = value;
	}
}

XHTMLExportOptions.prototype.resolveWithWebExportSettings = function(document) {
	var  prefs = document.exportForWebPreferences;
	switch(this.imageHandling) {
		case XHTMLExportOptions.copyOriginal:
			XHTMLExportOptions.setIfDifferent(prefs, 'copyOriginalImages', true);
			XHTMLExportOptions.setIfDifferent(prefs, 'copyFormattedImages', false);
			XHTMLExportOptions.setIfDifferent(prefs, 'copyOptimizedImages', false);
		break;
		case XHTMLExportOptions.copyOptimized:
			XHTMLExportOptions.setIfDifferent(prefs, 'copyOriginalImages', false);
			XHTMLExportOptions.setIfDifferent(prefs, 'copyFormattedImages', this.formatted);
			XHTMLExportOptions.setIfDifferent(prefs, 'copyOptimizedImages', !this.formatted);
		break;
		case XHTMLExportOptions.linkToServerPath:
			XHTMLExportOptions.setIfDifferent(prefs, 'copyOriginalImages', false);
			XHTMLExportOptions.setIfDifferent(prefs, 'copyFormattedImages', false);
			XHTMLExportOptions.setIfDifferent(prefs, 'copyOptimizedImages', false);
		break;
	}
} // XHTMLExportOptions.prototype.persist