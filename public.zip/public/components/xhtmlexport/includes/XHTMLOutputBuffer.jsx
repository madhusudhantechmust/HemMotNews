//========================================================================================
//  
//  $File: //depot/indesign_6.0/highprofile/source/public/components/xhtmlexport/includes/XHTMLOutputBuffer.jsx $
//  
//  Owner: Roey Horns
//  
//  $Author: pmbuilder $
//  
//  $DateTime: 2008/08/18 15:33:07 $
//  
//  $Revision: #1 $
//  
//  $Change: 643572 $
//  
//  Copyright 1997-2008 Adobe Systems Incorporated. All rights reserved.
//  
//  NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance 
//  with the terms of the Adobe license agreement accompanying it.  If you have received
//  this file from a source other than Adobe, then your use, modification, or 
//  distribution of it requires the prior written permission of Adobe.
//  
//  
//  Purpose: Buffer and format the XHTML output
//  
//  Include libraries
//  
//  #include "XHTMLUtils.jsx"
//  
//  Constructor
//  
//========================================================================================

function XHTMLOutputBuffer(classRegistry) {

		this.currentbuffer = 0
		this.outputbuffers = ['']
		
		this.level = 0;
		this.pretty = true;
		this.outpath = '';
		this.suppressClassAttributes = false;
		this.suppressAnchorNames = false;
		this.classes = classRegistry;
		this.newline = true;	// keep trach whether we still have to indent this line
} // XHTMLOutputBuffer


//------------------------------------------------------------------------------
// open and close an element context
// i.e. open and close tags have their own lines and create an indented context
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.openElementContext = function(tag, cls, attr) {
	this.registerClass(tag, cls);
	this.writeln(this.openElementString(tag, cls, attr));
	this.indent();
}

XHTMLOutputBuffer.prototype.closeElementContext = function(tag) {
	this.unindent();
	this.writeln(this.closeElementString(tag));
}

//------------------------------------------------------------------------------
// open and close an element context inline
// e.g. start a new <ol> within a <li>
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.openElementContextInline = function(tag, cls, attr) {
	this.registerClass(tag, cls);
	this.endln();
	this.indent();
	this.writeln(this.openElementString(tag, cls, attr));
	this.indent();
}

XHTMLOutputBuffer.prototype.closeElementContextInline = function(tag) {
	this.unindent();
	this.writeln(this.closeElementString(tag));
	this.unindent();
}


//------------------------------------------------------------------------------
// open and close an element on its own line
// i.e. the open tag creates a new line, the close tag doesn't
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.openElement = function(tag, cls, attr) {
	this.registerClass(tag, cls);
	this.write(this.openElementString(tag, cls, attr));
}

XHTMLOutputBuffer.prototype.closeElement = function(tag) {
	this.write(this.closeElementString(tag));
	this.endln();
}


//------------------------------------------------------------------------------
// open and close an element inline
// i.e. no new lines
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.openElementInline = function(tag, cls, attr) {
	this.registerClass(tag, cls);
	this.write(this.openElementString(tag, cls, attr));
}

XHTMLOutputBuffer.prototype.closeElementInline = function(tag) {
	this.write(this.closeElementString(tag));
}


//------------------------------------------------------------------------------	
// write out a whole element inline
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.writeElementInline = function(data, tag, cls, attr) {
	this.registerClass(tag, cls);
	if(XHTMLUtils.isEmptyString(data)) {
		this.write(this.emptyElementString(tag, cls, attr));
	} else {
		this.openElementInline(tag, cls, attr);
		this.write(data);
		this.closeElementInline(tag);
	}
}


//------------------------------------------------------------------------------	
// write out an anchor inline
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.writeAnchorInline = function(data, id, cls, attr) {
	this.write(this.generateAnchorString(data, id, cls, attr));
}


//------------------------------------------------------------------------------	
// write a whole element in its own line
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.writeElement = function(data, tag, cls, attr) {
	this.registerClass(tag, cls);
	if(XHTMLUtils.isEmptyString(data)) {
		this.writeln(this.emptyElementString(tag, cls, attr));
	} else {
		this.write(this.openElementString(tag, cls, attr));
		this.write(data);
		this.closeElementInline(tag);
		this.endln();
	}
}



//------------------------------------------------------------------------------	
// generate and return the string representing an anchor
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.generateAnchorString = function(data, id, cls, attr) {
	var tag = 'a';
	this.registerClass(tag, cls);
	if(XHTMLUtils.isEmptyString(attr)) {
		attr = '';
	} else {
		attr += ' ';
	}
	attr += 'id="' + id + '"';
	if(!this.suppressAnchorNames) {
		attr += ' name="' + id + '"';
	}
	if(XHTMLUtils.isEmptyString(data)) {
		return this.emptyElementString(tag, cls, attr);
	} else {
		return this.openElementString(tag, cls, attr) + data + this.closeElementString(tag);
	}
}

//------------------------------------------------------------------------------	
// insert a multiline string
//------------------------------------------------------------------------------

XHTMLOutputBuffer.prototype.insertBlob = function(blob) {
	this.startln();
	var lines = blob.split('\n');
	for(var i in lines) {
		if(lines[i].length > 0) {
			this.writeln(lines[i]);
		}
	}
}
	


//------------------------------------------------------------------------------
// END OF PUBLIC FUNCTIONS
//------------------------------------------------------------------------------

	
// keep track of all classes used
XHTMLOutputBuffer.prototype.registerClass = function(tag, cls) {
	if(!this.suppressClassAttributes) {
		if(this.classes != undefined && cls != undefined && cls != '') {
			var clstag = tag + '.' + cls;
			if(this.classes[clstag] == undefined) {
					this.classes[clstag] = true;
			}
		}
	}
}
	
XHTMLOutputBuffer.prototype.indent = function() {
	this.level++;
}
	
XHTMLOutputBuffer.prototype.unindent = function() {
	this.level--;
}
	
XHTMLOutputBuffer.prototype.startln = function() {
	var tabs = "";
	if(this.pretty) {
		for (var i = 0; i < this.level; i++)
			tabs += "\t";
	}
	this.outputbuffers[this.currentbuffer] += tabs;
	this.newline = false;
}
	
XHTMLOutputBuffer.prototype.endln = function() {
	this.outputbuffers[this.currentbuffer] += "\n";
	this.newline = true;
}
	
XHTMLOutputBuffer.prototype.write = function(s) {
	if(this.newline) {
		this.startln();
	}
	this.outputbuffers[this.currentbuffer] += s;
	this.checkBuffers();
}
	
XHTMLOutputBuffer.prototype.writeln = function(s) {
	if(this.newline) {
		this.startln();
	}
	this.outputbuffers[this.currentbuffer] +=  s + "\n";
	this.newline = true;
	this.checkBuffers();
}
	
XHTMLOutputBuffer.prototype.checkBuffers = function() {
	// we don't want each buffer grow too big as concatenating really big
	// strings tend to be slow
	if( this.outputbuffers[this.currentbuffer].length > 2000 ) {
		this.outputbuffers.push('');
		this.currentbuffer++;
	}
}
	
XHTMLOutputBuffer.prototype.getbuffers = function() {
	return this.outputbuffers;
}
	
XHTMLOutputBuffer.prototype.emptyElementString = function(tag, cls, attr) {
	return '<' + tag + (this.suppressClassAttributes || XHTMLUtils.isEmptyString(cls)?'':' class="'+cls+'"') + (XHTMLUtils.isEmptyString(attr)?'':' ' + attr) + ' />';
}
	
XHTMLOutputBuffer.prototype.openElementString = function(tag, cls, attr) {
	return '<' + tag + (this.suppressClassAttributes || XHTMLUtils.isEmptyString(cls)?'':' class="'+cls+'"') + (XHTMLUtils.isEmptyString(attr)?'':' ' + attr) + '>';
}
	
XHTMLOutputBuffer.prototype.closeElementString = function(tag) {
	return '</' + tag + '>';
}


//------------------------------------------------------------------------------	
// test
//------------------------------------------------------------------------------
/*
var classes = {};
var buffer = new XHTMLOutputBuffer(classes);

for(var i = 0; i < 1000; i++) {
	buffer.openElementContext('test', 'test', 'test="test"');
	buffer.openElementContextInline('test', 'test', 'test="test"');
	buffer.openElement('test', 'test', 'test="test"');
	buffer.writeElementInline('This is some test text', 'test', 'test', 'test="test"');
	buffer.writeElement('This is some test text', 'test', 'test', 'test="test"');
	buffer.closeElement('test');
	buffer.closeElementContextInline('test');
	buffer.closeElementContext('test');
}
buffer.outputbuffers.length
*/